#pragma once
#include <string>
#include "graphdb/common/error.h"
namespace graphdb::graph {
// A source tag, not a query phase: CSV/type readers keep their existing Error
// behavior. Only the Cypher parser maps it to a parse-stage diagnostic.
class UnicodeEscapeError : public Error {
 public:
  using Error::Error;
};
std::string DecodeStringLiteral(const std::string &text);
}  // namespace graphdb::graph
