#pragma once

#include <cstddef>
#include <cstdint>
#include <optional>
#include <stdexcept>
#include <string>

namespace graphdb::graph {
// DiagnosticError carries structured fields; Error messages are never parsed.
class Error : public std::runtime_error {
 public:
  using std::runtime_error::runtime_error;
};
// Runtime failures retain machine-readable kinds across language boundaries;
// bindings must not classify errors by their human-readable messages.
class CancelledError : public Error {
 public:
  explicit CancelledError(const char *message = "execution cancelled") : Error(message) {}
};
class AdmissionTimeoutError : public Error {
 public:
  AdmissionTimeoutError() : Error("transaction admission timed out") {}
};
enum class ResourceKind { ResultRows, ValueRead, ValueDepth, ValueNodes };
class ResourceLimitError : public Error {
 public:
  ResourceLimitError(ResourceKind resource, uint64_t limit)
      : Error(resource == ResourceKind::ResultRows ? "result budget exceeded"
                                                  : "resource budget exceeded"),
        resource(resource), limit(limit) {}
  const ResourceKind resource;
  const uint64_t limit;
};
enum class ErrorCode {
  InvalidArgumentType,
  IntegerOverflow,
  FloatingPointOverflow,
  ColumnNameConflict,
  AmbiguousAggregationExpression,
  UnexpectedSyntax,
  InvalidNumberLiteral,
  InvalidUnicodeLiteral,
  UndefinedVariable,
  NoVariablesInScope,
  NestedAggregation,
  UnknownFunction,
  NonConstantExpression
};
enum class ErrorCategory { Binder, Conversion, OutOfRange, Parser };
enum class ErrorStage { Bind, Execute, Parse };
struct SourceLocation {
  size_t line;
  size_t column;
};
const char *ErrorCodeName(ErrorCode code);
const char *ErrorCategoryName(ErrorCategory category);
const char *ErrorStageName(ErrorStage stage);
class DiagnosticError final : public Error {
 public:
  DiagnosticError(ErrorCode code, ErrorCategory category, ErrorStage stage,
                  std::string message,
                  std::optional<SourceLocation> location = {});
  const ErrorCode code;
  const ErrorCategory category;
  const ErrorStage stage;
  const std::optional<SourceLocation> location;
};
}  // namespace graphdb::graph
