#include "graphdb/common/string_literal.h"
#include <algorithm>
#include <cctype>
#include "graphdb/common/types.h"
namespace graphdb::graph {
void Utf8(std::string &out, uint32_t cp) {
  if (cp > 0x10ffff || (cp >= 0xd800 && cp <= 0xdfff))
    throw UnicodeEscapeError("invalid Unicode escape");
  if (cp < 0x80)
    out += static_cast<char>(cp);
  else if (cp < 0x800) {
    out += static_cast<char>(0xc0 | (cp >> 6));
    out += static_cast<char>(0x80 | (cp & 63));
  } else if (cp < 0x10000) {
    out += static_cast<char>(0xe0 | (cp >> 12));
    out += static_cast<char>(0x80 | ((cp >> 6) & 63));
    out += static_cast<char>(0x80 | (cp & 63));
  } else {
    out += static_cast<char>(0xf0 | (cp >> 18));
    out += static_cast<char>(0x80 | ((cp >> 12) & 63));
    out += static_cast<char>(0x80 | ((cp >> 6) & 63));
    out += static_cast<char>(0x80 | (cp & 63));
  }
}
std::string DecodeStringLiteral(const std::string &text) {
  if (text.size() < 2 || (text[0] != '\'' && text[0] != '"') ||
      text.back() != text[0])
    throw Error("invalid string literal");
  std::string out;
  for (size_t i = 1; i + 1 < text.size(); ++i) {
    char c = text[i];
    if (c != '\\') {
      if (c == text.front()) throw Error("unescaped string quote");
      out += c;
      continue;
    }
    if (i + 1 >= text.size() - 1) throw Error("incomplete string escape");
    c = text.at(++i);
    switch (c) {
      case '\\':
      case '\'':
      case '"':
        out += c;
        break;
      case 'n':
      case 'N':
        out += '\n';
        break;
      case 'r':
      case 'R':
        out += '\r';
        break;
      case 't':
      case 'T':
        out += '\t';
        break;
      case 'b':
      case 'B':
        out += '\b';
        break;
      case 'f':
      case 'F':
        out += '\f';
        break;
      case 'x':
      case 'X':
      case 'u':
      case 'U': {
        size_t count = (c == 'x' || c == 'X') ? 2 : 4;
        // Kuzu accepts both 4- and 8-hex escapes. Prefer 8 only for U.
        if (c == 'U' && i + 8 < text.size() - 1 &&
            std::all_of(text.begin() + i + 1, text.begin() + i + 9,
                        [](unsigned char h) { return std::isxdigit(h); }))
          count = 8;
        if (i + count >= text.size() - 1)
          throw UnicodeEscapeError("incomplete Unicode escape");
        if (!std::all_of(text.begin() + i + 1, text.begin() + i + 1 + count,
                         [](unsigned char h) { return std::isxdigit(h); }))
          throw UnicodeEscapeError("invalid Unicode escape");
        Utf8(out, static_cast<uint32_t>(
                      std::stoul(text.substr(i + 1, count), nullptr, 16)));
        i += count;
        break;
      }
      default:
        throw Error("invalid string escape");
    }
  }
  return out;
}

}  // namespace graphdb::graph
