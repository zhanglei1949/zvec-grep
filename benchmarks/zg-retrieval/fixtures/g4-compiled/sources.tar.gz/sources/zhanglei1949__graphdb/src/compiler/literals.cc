#include <cmath>
#include <cstdlib>
#include "graphdb/common/string_literal.h"
#include "frontend.h"
namespace graphdb::graph {
namespace {
std::string Upper(std::string s) {
  for (char &c : s)
    c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
  return s;
}
[[noreturn]] void Unsupported(const std::string &feature) {
  throw Error("unsupported lowering: " + feature + " (parsed by Kuzu)");
}
Id IntegerLiteral(const std::string &text,
                  std::optional<SourceLocation> location = {}) {
  const bool negative = !text.empty() && text.front() == '-';
  size_t pos = negative ? 1 : 0;
  unsigned base = 10;
  if (text.size() > pos + 2 && text[pos] == '0') {
    if (text[pos + 1] == 'x') base = 16;
    if (text[pos + 1] == 'o') base = 8;
    if (base != 10) pos += 2;
  }
  if (pos == text.size()) throw Error("invalid integer literal");
  const auto limit = static_cast<uint64_t>(INT64_MAX) + negative;
  uint64_t magnitude = 0;
  for (; pos < text.size(); ++pos) {
    const auto c = text[pos];
    const unsigned digit = c >= '0' && c <= '9'   ? c - '0'
                           : c >= 'a' && c <= 'f' ? c - 'a' + 10
                           : c >= 'A' && c <= 'F' ? c - 'A' + 10
                                                  : base;
    if (digit >= base) throw Error("invalid integer literal");
    if (magnitude > (limit - digit) / base)
      throw DiagnosticError(ErrorCode::IntegerOverflow,
                            ErrorCategory::OutOfRange, ErrorStage::Bind,
                            "integer literal out of range", location);
    magnitude = magnitude * base + digit;
  }
  // Neither cast 2^63 to signed nor negate INT64_MIN.
  return negative && magnitude ? -static_cast<Id>(magnitude - 1) - 1
                               : static_cast<Id>(magnitude);
}
const Syntax &Peel(const Syntax &n) {
  // Preserve semantic leaves; other one-child rules are precedence wrappers.
  if (n.rule == "oC_Parameter" || n.rule == "oC_Variable" ||
      n.rule == "oC_Literal" || n.rule == "oC_FunctionInvocation" ||
      n.rule == "oC_NumberLiteral")
    return n;
  return n.children.size() == 1 ? Peel(n.children.front()) : n;
}
}  // namespace
Value ReadScalarLiteral(const Syntax &input) {
  const auto &n = Peel(input);
  const auto text = n.text, upper = Upper(text);
  if (n.rule == "oC_Literal") {
    if (upper == "NULL") return {};
    if (upper == "TRUE" || upper == "FALSE") return upper == "TRUE";
    if (text.size() >= 2 && (text.front() == '\'' || text.front() == '"'))
      return DecodeStringLiteral(text);
    if (auto *number = n.Find("oC_NumberLiteral"))
      return ReadScalarLiteral(*number);
  }
  if (n.rule == "oC_NumberLiteral" ||
      (n.rule == "oC_UnaryAddSubtractOrFactorialExpression" &&
       n.children.size() == 2 && n.Has("-"))) {
    // The grammar has already validated the number; require full conversion.
    try {
      size_t used = 0;
      // Hex digits E/e aren't floating-point exponents. Classify by the
      // grammar leaf, including a unary negative integer's NumberLiteral.
      const auto &number = n.rule == "oC_NumberLiteral"
                               ? n
                               : n.Need("oC_PropertyOrLabelsExpression")
                                     .Need("oC_Atom")
                                     .Need("oC_Literal")
                                     .Need("oC_NumberLiteral");
      if (number.Find("oC_IntegerLiteral"))
        return IntegerLiteral(text, n.location);
      auto value = std::stod(text, &used);
      if (used != text.size() || !std::isfinite(value))
        throw Error("invalid floating literal");
      return value;
    } catch (const std::logic_error &) {
      // stod reports underflow as out_of_range too. Leave it unclassified
      // rather than labeling a tiny finite value as overflow.
      if (std::isinf(std::strtod(text.c_str(), nullptr)))
        throw DiagnosticError(ErrorCode::FloatingPointOverflow,
                              ErrorCategory::OutOfRange, ErrorStage::Bind,
                              "numeric literal out of range", n.location);
      throw Error("numeric literal out of range");
    }
  }
  Unsupported("scalar expression " + n.text);
}
Value Scalar(const Syntax &input, const Parameters &parameters) {
  return EvaluateValue(LowerValueExpression(input), parameters);
}

}  // namespace graphdb::graph
