#include "graphdb/common/error.h"
#include <utility>

namespace graphdb::graph {
const char *ErrorCodeName(ErrorCode code) {
  switch (code) {
    case ErrorCode::InvalidArgumentType:
      return "INVALID_ARGUMENT_TYPE";
    case ErrorCode::IntegerOverflow:
      return "INTEGER_OVERFLOW";
    case ErrorCode::FloatingPointOverflow:
      return "FLOATING_POINT_OVERFLOW";
    case ErrorCode::ColumnNameConflict:
      return "COLUMN_NAME_CONFLICT";
    case ErrorCode::AmbiguousAggregationExpression:
      return "AMBIGUOUS_AGGREGATION_EXPRESSION";
    case ErrorCode::UnexpectedSyntax:
      return "UNEXPECTED_SYNTAX";
    case ErrorCode::InvalidNumberLiteral:
      return "INVALID_NUMBER_LITERAL";
    case ErrorCode::InvalidUnicodeLiteral:
      return "INVALID_UNICODE_LITERAL";
    case ErrorCode::UndefinedVariable:
      return "UNDEFINED_VARIABLE";
    case ErrorCode::NoVariablesInScope:
      return "NO_VARIABLES_IN_SCOPE";
    case ErrorCode::NestedAggregation:
      return "NESTED_AGGREGATION";
    case ErrorCode::UnknownFunction:
      return "UNKNOWN_FUNCTION";
    case ErrorCode::NonConstantExpression:
      return "NON_CONSTANT_EXPRESSION";
  }
  throw std::logic_error("invalid diagnostic code");
}
const char *ErrorCategoryName(ErrorCategory category) {
  switch (category) {
    case ErrorCategory::Binder:
      return "binder";
    case ErrorCategory::Conversion:
      return "conversion";
    case ErrorCategory::OutOfRange:
      return "out_of_range";
    case ErrorCategory::Parser:
      return "parser";
  }
  throw std::logic_error("invalid diagnostic category");
}
const char *ErrorStageName(ErrorStage stage) {
  switch (stage) {
    case ErrorStage::Bind:
      return "bind";
    case ErrorStage::Execute:
      return "execute";
    case ErrorStage::Parse:
      return "parse";
  }
  throw std::logic_error("invalid diagnostic stage");
}
DiagnosticError::DiagnosticError(ErrorCode code, ErrorCategory category,
                                 ErrorStage stage, std::string message,
                                 std::optional<SourceLocation> location)
    : Error(std::move(message)),
      code(code),
      category(category),
      stage(stage),
      location(location) {
  (void)ErrorCodeName(code);
  (void)ErrorCategoryName(category);
  (void)ErrorStageName(stage);
  if (location && (!location->line || !location->column))
    throw std::logic_error("diagnostic location is one-based");
}
}  // namespace graphdb::graph
