# 迁入验收

日期：2026 年 10 月 21 日。目标目录：`zvec-grep/knowledge/`。

本次迁入设计文档、Python 源码、测试、示例和 Spike，保持 Python 独立运行。没有接入 zvec-grep 的 TypeScript/Rust 搜索流程，没有改写 SDK 业务逻辑，没有迁移旧数据库。

## 内容核对

- 写入前重新核对原项目 85 个来源文件及目标文件摘要，目标仓库当时没有其他未提交修改。
- 原项目 85 个来源文件在验收后仍与迁移前摘要一致；22 个 SDK 文件逐字节保留。
- 81 个映射文件原样保留；`README.md` 增加迁入入口，`bootstrap.py` 适配宿主子目录，`.gitignore` 清理原有末尾空行，原 `.gitmodules` 转换为宿主根 6 个带 `knowledge-` 前缀的固定 gitlink。
- 原有 4 份根设计/计划文档、历史报告和历史 `RESULTS.json` 保持原摘要。新增来源清单、迁移说明、验收结果及 4 项依赖注册测试。
- 原生依赖源码未重复复制，6 个 gitlink 已登记但未初始化。新虚拟环境独立创建，5 个原生 wheel 和 7 份构建记录按摘要复用，共约 17 MiB；原生库未重编译，环境准备全程离线。
- 宿主现有文件仅修改 `docs/README.md` 的开发入口、ESLint/Prettier 对 `knowledge/` 的排除；没有改动 TypeScript/Rust 运行时代码、Cargo 文件或 npm 依赖。

完整映射见 [来源清单](source-manifest.json)，结构化结论见 [results.json](results.json)。

## 实际执行

| 检查 | 结果 |
| --- | --- |
| 独立环境及导入路径 | Python 3.13.3；SDK、graphdb、zvec 均从新目录环境加载 |
| 原生来源 | graphdb/zvec 的 wheel 摘要和构建变体与原回执一致 |
| 全量单元/真实底座集成 | 138 项通过，失败 0，错误 0，跳过 0；原有 134 项加 4 项迁移测试 |
| Phase 2 摄入示例 | 通过，重复摄入、修订和只读重开保持原行为 |
| Phase 3 构建示例 | 通过，失败保留旧发布、显式重试和重开核对正常 |
| Phase 3 前置探针 | 通过，真实 graphdb 只读事务、双 zvec collection、UTF-8 原文映射及重开核对 |
| SDK 崩溃核对 | 5 个自有子进程实际 SIGKILL 场景通过，随后显式重开核对 |
| Ruff / pip check | lint、格式及依赖一致性检查通过 |
| 宿主 ESLint 配置语法 | `node --check eslint.config.js` 通过 |
| 文档链接与源文件摘要 | 非依赖的本地引用可解析；3 个固定依赖源码链接待子模块初始化 |

原生探针细节见 [phase3-gate.json](phase3-gate.json)，SDK 崩溃证据见 [sdk-crash.json](sdk-crash.json)，链接和摘要检查见 [link-audit.json](link-audit.json)。日志和临时试验库位于忽略的 `.artifacts/migration/`。

5 个 SIGKILL 场景分别为提交前、提交后确认前、提供者结果未保存、collection 创建后登记前、索引合并返回后图发布前。它们覆盖 SDK 边界，不代表原生任意 WAL/合并 syscall 内部中断或断电。

## 边界

- 两套 C++ 原生故障测试保留历史报告，本次未在新目录重跑；其构建缓存包含旧路径，没有复制。
- 宿主未安装 `node_modules`，未执行完整 npm 检查；本次只验证修改的 ESLint 配置语法。Rust 源码未改，未重跑 Rust 全量检查。
- 本次未重新做规模或检索质量测量，不改变历史性能结论。
- 旧目录保留。没有提交、推送或修改远端。仅为固定依赖登记暂存 `.gitmodules` 和 6 个 gitlink，其他迁入文件保留为工作区改动。
- 仓库合并没有实现运行时共享索引。后续从本目录开展共享存储与 Rust 接入 Spike。
