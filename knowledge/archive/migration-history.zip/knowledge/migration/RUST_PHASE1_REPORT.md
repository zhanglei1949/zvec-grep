# Rust 重写第一阶段验收

> 本页保留初始 R0 验证记录。之后的 API 精简、共享存储工具和回归结果见 [清理报告](RUST_CONSOLIDATION_REPORT.md)；本页的 29 项计数与源码摘要对应当时版本。

日期：2026-10-22。范围：不依赖 graphdb Rust binding 的组件阶段（R0）。本轮没有实现或修改 graphdb 上游 binding，不声明完成 Phase 1–3 的 Rust 行为等价。

## 交付

- 新增 [zg-knowledge](../../rust/crates/zg-knowledge/README.md)：自有记录类型、不可变快照、可替换处理契约、CommonMark 结构与分段、测试/预计算向量、任务执行与准入、候选投影及纯工作流状态规则。
- 复用 workspace 的 `zvec-rust=0.7.2` 与构建辅助包。该 crate 没有 graphdb、Tree-sitter、模型运行时或 KG 专属 zvec 源码依赖，且没有加入现有 zg 的运行依赖图。
- 提供 [组件示例](../../rust/crates/zg-knowledge/examples/components.rs)，执行快照→分段→测试向量→候选写入→关闭重开；输出明确包含 `published=false search_ready=false graph_backend=not_configured`。
- 定义内部 GraphStore 契约并交付 [上游 binding 接入要求](../GRAPHDB_RUST_BINDING_REQUIREMENTS.md)。测试替身只用于接口/状态检查，不是生产后端。
- 更新 README、总体设计、项目边界、交付计划和迁入说明，将旧 Python 结果与 Rust 交付分开。

## 实测

| 验证 | 结果 |
| --- | --- |
| Rust crate 测试 | 29 通过，0 失败，0 忽略；含真实 zvec 测试 |
| Python 基线回归 | 138 通过，0 跳过；SDK、测试、示例和 Spike 源码按迁入清单核对未变 |
| zg 相关存储回归 | 77 通过，2 项原有忽略，364 项按 `storage::` 过滤 |
| Clippy | `--all-targets -- -D warnings` 通过 |
| Rust 格式 | crate 级格式检查通过 |
| 组件示例 | 1 份快照、1 个分段、1 条候选写入并重开读取 |
| 依赖图 | 当前 zg 依赖图无 zg-knowledge；KG 使用同一 workspace zvec 绑定 |

zg 的两项既有忽略分别是手工缓存性能比较，以及 macOS 原生 `array_take` 缺失导致的 fetch/upsert 问题。本轮没有将忽略项计为通过，也没有修改宿主存储代码。KG 已有 ID 的写入先读取核对，相同内容直接复用，内容不同拒绝；重复写入和补写均有真实测试。

本机使用 Rust 1.98.0、macOS arm64，编译并发 14，复用宿主已有原生库。原生库摘要和本轮源码摘要见 [机器记录](rust-phase1-validation.json)。Rust 绑定包版本不等于已确认的 C++ 源码提交；这里没有据绑定版本推断底层源码身份。

原生故障与适配检查分别记录：

- 缺失必需向量字段的 upsert 在调用层失败；不将这个实验描述成逐项部分成功。
- 同批 duplicate/new insert 实际返回一项失败和一项成功，用于核对 native item status 与稳定 ID 的对应。
- 缺失投影通过稳定 ID 补齐，已有匹配记录直接复用，已有不同内容拒绝覆盖。
- 实际执行 FTS、向量召回和标量过滤，并验证文本/向量索引重开。
- 测试中只读打开、读取、关闭前后的文件内容哈希一致；不据此扩展为所有 native 打开方式或平台的保证。
- 状态列表缺失/计数错误、取消、预算和提交结果标记在适配或纯状态层验证；没有宣称这些测试覆盖真实 graphdb 提交或恢复。

## 复现

在 `rust/` 下，准备 workspace 原生库后执行：

```bash
cargo test --locked -p zg-knowledge -j 14
cargo run --locked -p zg-knowledge --example components -j 14
cargo clippy --locked -p zg-knowledge --all-targets -j 14 -- -D warnings
cargo fmt -p zg-knowledge -- --check
cargo test --locked --release -p zg-engine storage:: -j 14
```

本机运行使用标准 `ZVEC_LIB_DIR` 指向已有 `rust/target/release`，并在依赖获取后使用 `--offline`。初始 crates.io 索引访问失败；新增解析器包随后经静态下载、断点续传并按 Cargo.lock SHA-256 校验，最终编译和测试均实际执行。没有通过替换解析器或跳过原生测试绕过依赖问题。

## 剩余门槛

[138 项迁移矩阵](rust-test-matrix.json) 覆盖原测试清单：78 项等待 graphdb 接入，38 项关联组件测试，6 项部分关联组件测试，10 项保留历史 Python/Spike 语境，6 项为语言机制差异。组件关联不代表每个原测试的全部变体已经等价；矩阵所有条目均未标记 Phase 1–3 完整等价。

上游 binding 就绪后，仍需接通并验证真实来源/修订/回执、短事务原子发布、新只读确认、竞争、取消、提交结果未知及进程终止后的核对。也未重跑原定规模性能门，不复用旧 Go 结论。

Python 基线、其固定源码登记和运行入口按计划保留，最终切换门通过后再删除。当前只是统一 Rust 依赖，KG 与 zg 尚未共享同一 collection 或消除正文/向量数据冗余；旧库迁移、公开检索、真实抽取及其他平台不在本轮验收中。未提交、推送或修改原独立仓库。
