# Frozen Python baseline restoration

Extract this archive into a separate directory. It restores `knowledge/` source,
tests, Spike scripts and build configuration. It does not contain a virtualenv,
native source checkouts, or native wheels.

Native wheels/receipts are retained separately by the host under
`knowledge/.artifacts/spike-0/`; copy that directory to the restored tree at the
same relative path. Their SHA-256 values are in `archive-manifest.json`.
The archived baseline metadata records six gitlink pins and the original host
.gitmodules. Do not overwrite another project's .gitmodules when restoring.

For the retained macOS arm64 CPython 3.13 wheels, create a CPython 3.13 virtualenv,
install the wheel files by explicit local path (not package name; provenance
uses the wheel digest), install numpy==2.2.6, markdown-it-py==4.0.0, mdurl==0.1.2,
setuptools==80.9.0 and wheel==0.45.1, then install the local project using
`pip install --no-build-isolation --no-deps -e .` from restored knowledge/.
Pure Python packages may require the package index or a separately prepared
wheel cache. Existing build/patch instructions are under spikes/spike_0/.
Rebuilding native sources requires source checkouts and their build tools.

Run from restored knowledge/:
    .venv/bin/python -m unittest discover -s tests -t . -v
    .venv/bin/python -m examples.phase2_ingest
    .venv/bin/python -m examples.phase3_build

The retirement check restores source in a temporary directory and runs its
138 tests with the existing frozen interpreter/environment before removing
that environment. This validates restored source and native integration;
it is not a fresh-machine or offline-environment rebuild test.
