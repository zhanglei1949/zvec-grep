# Python 基线迁入记录

2026-10-22 后续：Rust 重写第一阶段在 `rust/crates/zg-knowledge/` 进行，见 [组件说明](../rust/crates/zg-knowledge/README.md) 和 [本轮验证报告](migration/RUST_CONSOLIDATION_REPORT.md)。本文件及 `source-manifest.json` 继续记录迁入当时的状态，不覆盖历史摘要。Python SDK、测试与源码构建入口冻结保留，待上游 graphdb binding 接入并通过 Rust 行为等价验收后再移除。

本次将 z-knowledge-graph 的设计、Python SDK、测试、示例和 Spike 迁入 zvec-grep 的 `knowledge/`，保留 Phase 1–3 行为。Rust 改写、共享存储和搜索主流程接入另行实施。

## 内容与依赖

- `zknowledge/`、原有 `tests/`、`examples/`、设计文档和历史实验报告保持相对结构；新增迁移适配测试。
- `spikes/spike_0/bootstrap.py` 支持独立仓库和宿主子目录，依赖在宿主根 `.gitmodules` 中登记为 `knowledge-*`，gitlink 固定到原提交。未初始化的依赖目录可按原锁文件准备。
- 已有原生 wheel 和构建回执按 SHA-256 核对后复制到忽略的 `.artifacts/spike-0/`，供本机重建环境使用。它们不是 Git 仓库中的分发产物。
- 原目录、数据库、虚拟环境、原生构建缓存和模型缓存保留在原处；新环境独立创建。原生源码没有复制，依赖 gitlink 已登记，需要构建时显式初始化。
- 历史 `RESULTS.json` 和报告保留原文及原摘要，记录的是原路径的执行；本次迁入后的验证单独记录，不改写历史证据。

文件来源及迁入后的对应摘要见 [迁移清单](migration/source-manifest.json)。原 `.gitmodules` 的依赖条目转换为宿主根路径，不在本目录创建嵌套 Git 仓库。

## 运行

本次已在本目录重建 `.venv`，复用固定原生 wheel 和本地包缓存。日常操作：

```bash
cd knowledge
.venv/bin/python -m examples.phase2_ingest
.venv/bin/python -m examples.phase3_build
.venv/bin/python -m unittest discover -s tests -t . -v
.venv/bin/python -m spikes.phase3.gate --output .artifacts/migration/phase3-gate.json
.venv/bin/ruff check zknowledge tests spikes examples
.venv/bin/ruff format --check zknowledge tests spikes examples
```

在其他机器或新克隆中，先按 [Spike-0](spikes/spike_0/README.md) 准备原生源码、构建工具、wheel 和回执，再安装本目录：

```bash
python3 -m venv .venv
.venv/bin/python spikes/spike_0/bootstrap.py --jobs 14
.venv/bin/python -m pip install -r spikes/spike_0/requirements.lock
.venv/bin/python spikes/spike_0/build.py --help
```

`build.py` 按原 Spike-0 说明选择依赖及构建变体；本次没有重新编译。安装原生 wheel 后，执行 `.venv/bin/python -m pip install -e .` 安装 SDK 与固定的纯 Python 依赖。不同平台需要各自的 wheel，不能使用本机 macOS arm64 构建代替。

原生测试构建缓存包含旧路径，本次没有搬入。运行 `spikes.validation.native` 前需按原构建流程重新准备缓存；Python 集成测试通过后不自动等同于这两套 C++ 原生故障测试已在新目录重跑。

## 验证

已完成迁入验收：138 项测试零跳过通过，两个示例、真实底座探针及 5 个 SDK 崩溃核对通过，原验收报告及结果见 [历史归档](archive/migration-history.zip) 中的 `knowledge/migration/VALIDATION.md`。本次使用独立临时数据库，不修改原数据库或 zvec-grep 的索引。尚未接入搜索主流程，因此仓库合并本身不改变索引存储数量。
