"""Unit tests for the KB manifest and store-ownership checks (section 8.2)."""

from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from zknowledge import manifest as M
from zknowledge.errors import (
    IdentityMismatchError,
    IncompatibleFormatError,
    IncompleteInitError,
)


class TestManifest(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)

    def tearDown(self):
        self._tmp.cleanup()

    def _write_markers(self, manifest):
        (self.root / "stores").mkdir(parents=True, exist_ok=True)
        for ref in manifest.stores:
            M.write_store_marker(self.root, ref, manifest)

    def test_new_manifest_not_ready_with_stable_ids(self):
        m = M.new_manifest()
        self.assertFalse(m.ready)
        self.assertEqual(m.format_version, M.FORMAT_VERSION)
        self.assertEqual(m.storage_generation, 0)
        kinds = {ref.kind for ref in m.stores}
        self.assertEqual(kinds, set(M.STORE_KINDS))
        ids = [ref.store_id for ref in m.stores]
        self.assertEqual(len(set(ids)), len(ids))  # unique store ids

    def test_roundtrip_and_mark_ready(self):
        m = M.new_manifest()
        M.write_manifest(self.root, m)
        loaded = M.read_manifest(self.root)
        self.assertEqual(loaded.kb_id, m.kb_id)
        self.assertFalse(loaded.ready)
        M.mark_ready(self.root, loaded)
        self.assertTrue(M.read_manifest(self.root).ready)

    def test_incompatible_format_rejected(self):
        m = M.new_manifest()
        M.write_manifest(self.root, m)
        path = M.manifest_path(self.root)
        data = json.loads(path.read_text())
        data["format_version"] = 99
        path.write_text(json.dumps(data))
        with self.assertRaises(IncompatibleFormatError):
            M.read_manifest(self.root)

    def test_missing_manifest_is_incomplete_init(self):
        with self.assertRaises(IncompleteInitError):
            M.read_manifest(self.root)

    def test_ownership_valid_then_tampered(self):
        m = M.new_manifest()
        M.write_manifest(self.root, m)
        self._write_markers(m)
        M.validate_store_ownership(self.root, m)  # no raise
        marker = M.read_store_marker(self.root, "index")
        marker["kb_id"] = "some-other-kb"
        (self.root / "stores" / "index.json").write_text(json.dumps(marker))
        with self.assertRaises(IdentityMismatchError):
            M.validate_store_ownership(self.root, m)

    def test_missing_marker_is_identity_mismatch(self):
        m = M.new_manifest()
        M.write_manifest(self.root, m)
        (self.root / "stores").mkdir(parents=True, exist_ok=True)
        with self.assertRaises(IdentityMismatchError):
            M.validate_store_ownership(self.root, m)

    def test_update_store_state_preserves_identity(self):
        m = M.new_manifest()
        M.write_manifest(self.root, m)
        self._write_markers(m)
        M.update_store_state(self.root, "index", collection_created=True)
        marker = M.read_store_marker(self.root, "index")
        self.assertTrue(marker["state"]["collection_created"])
        self.assertEqual(marker["kb_id"], m.kb_id)
        M.validate_store_ownership(self.root, m)  # still valid


if __name__ == "__main__":
    unittest.main()
