import unittest
from dataclasses import replace

from zknowledge import (
    EmbeddedVector,
    EmbeddingSpace,
    PrecomputedEmbeddings,
    SyntheticEmbeddingProvider,
)
from zknowledge.document_processing import ParseContext, ProcessingBudget
from zknowledge.embedding import (
    EmbeddingDescriptor,
    EmbeddingInput,
    embed_batch,
    validate_vector,
)
from zknowledge.errors import InvalidInputError, ProviderError


class TestEmbeddingContract(unittest.TestCase):
    def setUp(self):
        self.space = EmbeddingSpace("local/test", "weights-1", 3)
        self.inputs = (EmbeddingInput("u", "digest", "text"),)
        self.context = ParseContext(ProcessingBudget(1000, 100))

    def test_precomputed_freezes_input_and_manifest(self):
        values = [EmbeddedVector("u", "digest", [1, 0, 0])]
        p = PrecomputedEmbeddings(self.space, values)
        values.clear()
        self.assertEqual(
            embed_batch(p, self.inputs, self.context)[0].vector, (1.0, 0.0, 0.0)
        )
        self.assertIn("manifest_digest", p.describe().configuration)
        self.assertEqual(p.frozen_manifest()["space"]["version"], "weights-1")

    def test_wrong_digest_missing_duplicate_and_count_rejected(self):
        p = PrecomputedEmbeddings(
            self.space, (EmbeddedVector("u", "other", (1, 0, 0)),)
        )
        with self.assertRaises(ProviderError):
            embed_batch(p, self.inputs, self.context)
        with self.assertRaises(ProviderError):
            embed_batch(
                PrecomputedEmbeddings(self.space, ()), self.inputs, self.context
            )
        with self.assertRaises(InvalidInputError):
            PrecomputedEmbeddings(self.space, (p.values[0], p.values[0]))

    def test_space_change_includes_semantics_beyond_dimension(self):
        for space in [
            replace(self.space, version="weights-2"),
            replace(self.space, metric="ip"),
            replace(self.space, quantization="q4"),
            replace(self.space, query_encoding="instruction-v2"),
        ]:
            self.assertNotEqual(space.id, self.space.id)

    def test_invalid_numeric_output(self):
        for vector in [
            (1, 0),
            (float("nan"), 0, 0),
            (float("inf"), 0, 0),
            (0, 0, 0),
            (2, 0, 0),
            (True, 0, 0),
            (1e100, 0, 0),
        ]:
            with self.assertRaises(ProviderError):
                validate_vector(vector, self.space)

    def test_credentials_cannot_enter_descriptor(self):
        with self.assertRaises(InvalidInputError):
            EmbeddingDescriptor("x", "1", self.space, {"api_key": "secret"})

    def test_provider_result_identity_and_unexpected_failure(self):
        parent = self

        class Bad:
            def describe(self):
                return EmbeddingDescriptor("bad", "1", parent.space)

            def embed(self, items, context):
                return (EmbeddedVector("wrong", "digest", (1, 0, 0)),)

        with self.assertRaises(ProviderError):
            embed_batch(Bad(), self.inputs, self.context)

    def test_synthetic_explicit_test_identity(self):
        p = SyntheticEmbeddingProvider(3)
        self.assertIn("test", p.describe().space.model)
        self.assertEqual(
            embed_batch(p, self.inputs, self.context),
            embed_batch(p, self.inputs, self.context),
        )
