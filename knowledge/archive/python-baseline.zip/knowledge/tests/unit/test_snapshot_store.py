"""Unit tests for the immutable content-addressed snapshot store (section 4.1)."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from zknowledge.adapters.snapshot_store import SnapshotStore
from zknowledge.errors import StorageError


class TestSnapshotStore(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.store = SnapshotStore(Path(self._tmp.name))

    def tearDown(self):
        self._tmp.cleanup()

    def test_put_get_content_addressed_and_dedup(self):
        data = "你好 hello".encode("utf-8")
        sid = self.store.put(data, encoding="utf-8")
        self.assertEqual(len(sid), 64)
        self.assertTrue(self.store.exists(sid))
        self.assertEqual(self.store.get(sid), data)
        self.assertEqual(self.store.encoding(sid), "utf-8")
        # identical bytes -> identical id, immutable (no rewrite)
        self.assertEqual(self.store.put(data), sid)

    def test_read_range_left_closed_right_open(self):
        sid = self.store.put(b"0123456789")
        self.assertEqual(self.store.read_range(sid, 2, 5), b"234")
        self.assertEqual(self.store.read_range(sid, 0, 0), b"")
        with self.assertRaises(StorageError):
            self.store.read_range(sid, 8, 100)

    def test_invalid_range_rejected(self):
        sid = self.store.put(b"x")
        with self.assertRaises(StorageError):
            self.store.read_range(sid, 5, 1)
        with self.assertRaises(StorageError):
            self.store.read_range(sid, -1, 1)

    def test_invalid_and_missing_id(self):
        with self.assertRaises(StorageError):
            self.store.get("not-a-valid-id")
        with self.assertRaises(StorageError):
            self.store.get("0" * 64)

    def test_non_bytes_rejected(self):
        with self.assertRaises(StorageError):
            self.store.put("text not bytes")  # type: ignore[arg-type]


class TestSnapshotIntegrity(unittest.TestCase):
    def test_concurrent_instances_same_content_and_no_temporary_leaks(self):
        from concurrent.futures import ThreadPoolExecutor

        with tempfile.TemporaryDirectory() as d:
            stores = [SnapshotStore(Path(d)) for _ in range(4)]
            data = "中文\r\n".encode() * 100
            with ThreadPoolExecutor(max_workers=8) as pool:
                ids = list(pool.map(lambda n: stores[n % 4].put(data), range(32)))
            self.assertEqual(len(set(ids)), 1)
            self.assertEqual(stores[0].get(ids[0]), data)
            self.assertEqual(
                len(list(Path(d).rglob("*"))), 3
            )  # fanout, bytes, metadata

    def test_corrupt_bytes_metadata_and_encoding_conflict(self):
        import json

        with tempfile.TemporaryDirectory() as d:
            store = SnapshotStore(Path(d))
            sid = store.put(b"abc")
            with self.assertRaises(StorageError):
                store.put(b"abc", "latin-1")
            self.assertEqual(store.get(sid), b"abc")
            store._blob_path(sid).write_bytes(b"xyz")
            with self.assertRaises(StorageError):
                store.get(sid)
            with self.assertRaises(StorageError):
                store.put(b"abc")
            store._blob_path(sid).write_bytes(b"abc")
            meta = store._meta_path(sid)
            original = meta.read_bytes()
            value = json.loads(original)
            value["byte_length"] = 1
            meta.write_text(json.dumps(value))
            with self.assertRaises(StorageError):
                store.get(sid)
            meta.unlink()
            with self.assertRaises(StorageError):
                store.get(sid)
            # An explicit put can complete an orphaned installation; get cannot.
            self.assertEqual(store.put(b"abc"), sid)

    def test_interrupted_metadata_installation_is_not_readable_success(self):
        from unittest.mock import patch

        from zknowledge.adapters import snapshot_store as module

        with tempfile.TemporaryDirectory() as d:
            store = SnapshotStore(Path(d))
            original = module.atomic_bytes

            def fail(path, data):
                if path.name.endswith(".meta.json"):
                    raise OSError("injected failure")
                original(path, data)

            with patch.object(module, "atomic_bytes", fail):
                with self.assertRaises(StorageError):
                    store.put(b"content")
            import hashlib

            sid = hashlib.sha256(b"content").hexdigest()
            with self.assertRaises(StorageError):
                store.get(sid)
            self.assertEqual(store.put(b"content"), sid)
            self.assertEqual(store.get(sid), b"content")


if __name__ == "__main__":
    unittest.main()
