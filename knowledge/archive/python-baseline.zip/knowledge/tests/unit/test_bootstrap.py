"""Pinned dependency registration in standalone and nested project layouts."""

from __future__ import annotations

import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from spikes.spike_0 import bootstrap


def git(root, *args):
    return subprocess.check_output(
        ["git", *args], cwd=root, text=True, stderr=subprocess.STDOUT
    ).strip()


class TestBootstrapLayout(unittest.TestCase):
    def setUp(self):
        isolated_git = patch.dict(
            os.environ,
            {
                "GIT_CONFIG_GLOBAL": os.devnull,
                "GIT_CONFIG_NOSYSTEM": "1",
                "GIT_CONFIG_COUNT": "1",
                "GIT_CONFIG_KEY_0": "core.hooksPath",
                "GIT_CONFIG_VALUE_0": os.devnull,
            },
        )
        isolated_git.start()
        self.addCleanup(isolated_git.stop)
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.directory = Path(self.tmp.name).resolve()
        self.mirrors = self.directory / "mirrors"
        upstream = self.mirrors / "probe"
        upstream.mkdir(parents=True)
        git(upstream, "init", "--quiet")
        (upstream / "fixture.txt").write_text("pinned fixture\n")
        git(upstream, "add", "fixture.txt")
        git(
            upstream,
            "-c",
            "user.name=Migration Test",
            "-c",
            "user.email=migration-test@example.invalid",
            "-c",
            "commit.gpgsign=false",
            "commit",
            "--quiet",
            "-m",
            "fixture",
        )
        self.dep = {
            "name": "probe",
            "path": "thirdparty/probe",
            "url": upstream.as_uri(),
            "commit": git(upstream, "rev-parse", "HEAD"),
        }
        self.host = self.directory / "host"
        self.host.mkdir()
        git(self.host, "init", "--quiet")

    def prepare(self, root):
        root.mkdir(parents=True, exist_ok=True)
        with patch.object(bootstrap, "ROOT", root):
            bootstrap.prepare(self.dep, self.mirrors, 1)

    def test_standalone_layout_preserves_original_module_name(self):
        self.prepare(self.host)
        self.assertEqual(
            git(self.host, "config", "-f", ".gitmodules", "submodule.probe.path"),
            "thirdparty/probe",
        )
        self.assertTrue(
            git(self.host, "ls-files", "--stage", "thirdparty/probe").startswith(
                "160000 " + self.dep["commit"]
            )
        )

    def test_nested_layout_is_idempotent_and_rejects_pin_mismatch(self):
        root = self.host / "knowledge"
        self.prepare(root)
        self.prepare(root)
        self.assertEqual(
            git(
                self.host,
                "config",
                "-f",
                ".gitmodules",
                "submodule.knowledge-probe.path",
            ),
            "knowledge/thirdparty/probe",
        )
        before = git(self.host, "ls-files", "--stage")
        with patch.object(bootstrap, "ROOT", root):
            with self.assertRaisesRegex(RuntimeError, "gitlink disagrees"):
                bootstrap.register_source({**self.dep, "commit": "1" * 40})
        self.assertEqual(git(self.host, "ls-files", "--stage"), before)
        self.assertFalse((root / ".gitmodules").exists())

    def test_registered_empty_checkout_can_be_prepared_from_local_mirror(self):
        root = self.host / "knowledge"
        target = root / self.dep["path"]
        target.mkdir(parents=True)
        for key, value in (
            ("path", "knowledge/thirdparty/probe"),
            ("url", self.dep["url"]),
        ):
            git(
                self.host,
                "config",
                "-f",
                ".gitmodules",
                "submodule.knowledge-probe." + key,
                value,
            )
        git(
            self.host,
            "update-index",
            "--add",
            "--cacheinfo",
            "160000," + self.dep["commit"] + ",knowledge/thirdparty/probe",
        )
        self.prepare(root)
        self.assertEqual(git(target, "rev-parse", "HEAD"), self.dep["commit"])
        self.assertTrue((target / ".git").is_file())

    def test_non_git_dependency_directory_is_preserved(self):
        root = self.host / "knowledge"
        target = root / self.dep["path"]
        target.mkdir(parents=True)
        marker = target / "caller.txt"
        marker.write_text("keep me\n")
        with self.assertRaisesRegex(RuntimeError, "Refusing non-Git directory"):
            self.prepare(root)
        self.assertEqual(marker.read_text(), "keep me\n")
        self.assertFalse((self.host / ".gitmodules").exists())
