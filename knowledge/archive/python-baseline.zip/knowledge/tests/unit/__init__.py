"""Unit tests: pure logic, no native bases required (adapters are stubbed)."""
