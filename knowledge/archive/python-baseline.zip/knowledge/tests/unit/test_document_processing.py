"""Synthetic providers prove the contract, not Markdown/model capabilities."""

from __future__ import annotations

import hashlib
import threading
import time
import unittest
from dataclasses import replace

from zknowledge import CaptureConfig
from zknowledge.document_processing import (
    CandidateAssertion,
    CandidateEntity,
    Diagnostic,
    DocumentBlock,
    DocumentParser,
    DocumentUnit,
    EvidenceCandidate,
    ExtractionContext,
    ExtractionResult,
    ExtractorDescriptor,
    KnowledgeExtractor,
    ParseContext,
    ParsedDocument,
    ParserDescriptor,
    ProcessingBudget,
    Qualifier,
    SourceSnapshot,
    SourceSpan,
    TypedValue,
    capture_fingerprint,
    extract_knowledge,
    parse_document,
    processing_fingerprint,
)
from zknowledge.errors import InvalidInputError, OperationCancelledError, ProviderError


def span(snapshot, start=0, end=None):
    return SourceSpan(
        snapshot.revision_id,
        snapshot.snapshot_id,
        start,
        len(snapshot.data) if end is None else end,
    )


class WholeDocumentParser:
    def describe(self):
        return ParserDescriptor("test.whole", "1")

    def parse(self, snapshot, context):
        return ParsedDocument(
            snapshot.revision_id, (DocumentBlock("root", "document", span(snapshot)),)
        )


class NestedParser:
    def describe(self):
        return ParserDescriptor("test.nested", "1")

    def parse(self, snapshot, context):
        return ParsedDocument(
            snapshot.revision_id,
            (
                DocumentBlock("root", "document", span(snapshot)),
                DocumentBlock("body", "paragraph", span(snapshot), "root"),
            ),
        )


class RelationExtractor:
    def describe(self):
        return ExtractorDescriptor("test.relation", "1")

    def extract(self, units, context):
        snapshot = units[0].snapshot
        return ExtractionResult(
            entities=(
                CandidateEntity("s", "Atlas", "Software"),
                CandidateEntity("o", "全文检索", "Capability"),
            ),
            assertions=(
                CandidateAssertion(
                    "a",
                    "s",
                    "supports",
                    object_id="o",
                    qualifiers=(Qualifier("version", TypedValue("version", "2.0")),),
                    evidence=(
                        EvidenceCandidate(span(snapshot), snapshot.data.decode()),
                    ),
                ),
            ),
        )


class EmptyExtractor:
    def describe(self):
        return ExtractorDescriptor("test.empty", "2")

    def extract(self, units, context):
        return ExtractionResult()


class TestProcessingContracts(unittest.TestCase):
    def setUp(self):
        data = "Atlas 2.0 支持全文检索。".encode()
        self.snapshot = SourceSnapshot(
            "source", "revision", hashlib.sha256(data).hexdigest(), data
        )
        self.unit = DocumentUnit("u", self.snapshot, (span(self.snapshot),))
        self.budget = ProcessingBudget(1000, 100)
        self.context = ExtractionContext(
            self.budget,
            allowed_entity_types=("Software", "Capability"),
            allowed_predicates=("supports",),
        )

    def test_two_parsers_and_two_extractors_same_protocol(self):
        for parser in (WholeDocumentParser(), NestedParser()):
            self.assertIsInstance(parser, DocumentParser)
            parsed = parse_document(parser, self.snapshot, ParseContext(self.budget))
            self.assertEqual(parsed.revision_id, self.snapshot.revision_id)
        for extractor in (RelationExtractor(), EmptyExtractor()):
            self.assertIsInstance(extractor, KnowledgeExtractor)
            result = extract_knowledge(extractor, (self.unit,), self.context)
            self.assertIsInstance(result, ExtractionResult)
        assertion = extract_knowledge(
            RelationExtractor(), (self.unit,), self.context
        ).assertions[0]
        self.assertEqual(assertion.qualifiers[0].value.value, "2.0")
        self.assertEqual(assertion.evidence[0].quote, self.snapshot.data.decode())

    def test_stage_fingerprints_stable_isolated_and_dependency_sensitive(self):
        a = ParserDescriptor("p", "1", configuration={"b": 2, "a": 1})
        b = ParserDescriptor("p", "1", configuration={"a": 1, "b": 2})
        parse = processing_fingerprint("parse", a)
        self.assertEqual(parse, processing_fingerprint("parse", b))
        capture = capture_fingerprint(CaptureConfig())
        segment = processing_fingerprint("segment", a, (parse,))
        old_extract = processing_fingerprint(
            "extract", ExtractorDescriptor("e", "1"), (segment,)
        )
        new_extract = processing_fingerprint(
            "extract", ExtractorDescriptor("e", "2"), (segment,)
        )
        self.assertNotEqual(old_extract, new_extract)
        self.assertEqual(capture, capture_fingerprint(CaptureConfig()))
        self.assertEqual(segment, processing_fingerprint("segment", a, (parse,)))
        new_parse = processing_fingerprint("parse", replace(a, version="2"))
        self.assertNotEqual(segment, processing_fingerprint("segment", a, (new_parse,)))
        with self.assertRaises(TypeError):
            a.configuration["a"] = 9
        with self.assertRaises(InvalidInputError):
            ParserDescriptor("p", "1", configuration={"api_key": "hidden"})
        ParserDescriptor("p", "1", configuration={"max_tokens": 100})

    def test_snapshot_digest_utf8_and_byte_bounds(self):
        self.assertNotIn("Atlas", repr(self.snapshot))
        with self.assertRaises(InvalidInputError):
            self.snapshot.read(0, 10000)
        with self.assertRaises(InvalidInputError):
            replace(self.snapshot, data=b"different")
        with self.assertRaises(InvalidInputError):
            replace(self.snapshot, encoding="latin1")

    def test_parser_positions_tree_types_and_status(self):
        base = WholeDocumentParser()
        good = base.parse(self.snapshot, ParseContext(self.budget))
        cases = (
            {"foreign": "AST"},
            replace(good, revision_id="other"),
            replace(
                good,
                blocks=(
                    replace(
                        good.blocks[0], span=replace(span(self.snapshot), end=10000)
                    ),
                ),
            ),
            replace(good, blocks=(replace(good.blocks[0], parent_id="missing"),)),
            replace(good, blocks=(replace(good.blocks[0], parent_id="root"),)),
            replace(good, blocks=good.blocks * 2),
            replace(good, status="truncated"),
            replace(
                good,
                blocks=(
                    replace(
                        good.blocks[0], span=replace(span(self.snapshot), start=11)
                    ),
                ),
            ),
        )
        from unittest.mock import patch

        for result in cases:
            with (
                self.subTest(result=type(result)),
                patch.object(base, "parse", return_value=result),
            ):
                with self.assertRaises(ProviderError):
                    parse_document(base, self.snapshot, ParseContext(self.budget))
        with patch.object(
            base,
            "parse",
            return_value=replace(
                good,
                status="truncated",
                diagnostics=(Diagnostic("limit", "output truncated"),),
            ),
        ):
            self.assertEqual(
                parse_document(base, self.snapshot, ParseContext(self.budget)).status,
                "truncated",
            )
        with patch.object(
            base,
            "describe",
            return_value=ParserDescriptor("p", "1", supported_formats=("other",)),
        ):
            with self.assertRaises(ProviderError):
                parse_document(base, self.snapshot, ParseContext(self.budget))

    def test_cancel_deadline_and_input_output_budgets(self):
        cancelled = threading.Event()
        cancelled.set()
        with self.assertRaises(OperationCancelledError):
            parse_document(
                WholeDocumentParser(),
                self.snapshot,
                ParseContext(self.budget, cancelled),
            )
        with self.assertRaises(ProviderError):
            parse_document(
                WholeDocumentParser(),
                self.snapshot,
                ParseContext(self.budget, deadline=time.monotonic() - 1),
            )
        for budget in (ProcessingBudget(1, 100), ProcessingBudget(1000, 0)):
            with self.assertRaises(ProviderError):
                parse_document(
                    WholeDocumentParser(), self.snapshot, ParseContext(budget)
                )
            with self.assertRaises(ProviderError):
                extract_knowledge(
                    RelationExtractor(),
                    (self.unit,),
                    replace(self.context, budget=budget),
                )

    def test_extraction_evidence_types_schema_and_qualifiers(self):
        extractor = RelationExtractor()
        good = extractor.extract((self.unit,), self.context)
        assertion = good.assertions[0]
        cases = (
            {"foreign": "model response"},
            replace(good, entities=good.entities * 2),
            replace(good, assertions=(replace(assertion, subject_id="missing"),)),
            replace(good, assertions=(replace(assertion, predicate="undeclared"),)),
            replace(good, assertions=(replace(assertion, polarity="maybe"),)),
            replace(good, assertions=(replace(assertion, evidence=()),)),
            replace(
                good,
                assertions=(replace(assertion, qualifiers=assertion.qualifiers * 2),),
            ),
            replace(
                good,
                assertions=(
                    replace(
                        assertion,
                        evidence=(
                            EvidenceCandidate(span(self.snapshot), "fabricated"),
                        ),
                    ),
                ),
            ),
            replace(
                good,
                assertions=(
                    replace(
                        assertion,
                        evidence=(
                            EvidenceCandidate(
                                replace(span(self.snapshot), revision_id="other"),
                                self.snapshot.data.decode(),
                            ),
                        ),
                    ),
                ),
            ),
        )
        from unittest.mock import patch

        for result in cases:
            with (
                self.subTest(result=type(result)),
                patch.object(extractor, "extract", return_value=result),
            ):
                with self.assertRaises(ProviderError):
                    extract_knowledge(extractor, (self.unit,), self.context)
        smaller = replace(self.unit, spans=(span(self.snapshot, 0, 5),))
        with self.assertRaises(ProviderError):
            extract_knowledge(extractor, (smaller,), self.context)

    def test_provider_exception_is_not_empty_success_or_raw_content(self):
        from unittest.mock import patch

        with patch.object(
            RelationExtractor, "extract", side_effect=RuntimeError("PRIVATE_CONTENT")
        ):
            with self.assertRaises(ProviderError) as error:
                extract_knowledge(RelationExtractor(), (self.unit,), self.context)
        self.assertNotIn("PRIVATE_CONTENT", str(error.exception.to_dict()))
