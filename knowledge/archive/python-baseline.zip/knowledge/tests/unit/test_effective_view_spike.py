"""Semantic reference fixtures; no claim that the experimental model is M1."""

from __future__ import annotations

import unittest

from spikes.spike_2.effective_view import evaluate, fixture, scoped


class TestEffectiveViewReference(unittest.TestCase):
    def test_qualified_claims_coexist_and_conflict_is_not_last_write_wins(self):
        view = evaluate(list(fixture("e0")))
        self.assertIn("p", view["selected"])
        self.assertIn("n1", view["selected"])
        self.assertEqual(view["disputed"], ["f", "t"])

    def test_shared_support_deletion_and_dependency_invalidation(self):
        view = evaluate(
            list(fixture("e0", {"A": True, "B": False, "correction": False}))
        )
        self.assertIn("p", view["selected"])
        self.assertNotIn("i", view["selected"])
        self.assertEqual(view["derived"], [])
        self.assertEqual(view["origins"]["p"], ["A"])

    def test_manual_replacement_revoke_retains_original(self):
        rows = list(fixture("e0", {"A": True, "B": True, "correction": True}))
        view = evaluate(rows)
        self.assertNotIn("p", view["selected"])
        self.assertIn("r", view["selected"])
        self.assertTrue(any(x["id"] == "p" and x["kind"] == "claim" for x in rows))
        restored = evaluate(list(fixture("e0")))
        self.assertIn("p", restored["selected"])
        self.assertNotIn("r", restored["selected"])

    def test_scope_preserves_global_dispute_and_required_manual_metadata(self):
        view = evaluate(list(fixture("e0")))
        result = scoped(view, ("A",))
        self.assertEqual(result["disputed"], ["t"])
        self.assertNotIn("t", result["selected"])
        self.assertEqual(result["citations"]["p"], ["A"])
        self.assertEqual(result["derived"], [])
        view = evaluate(list(fixture("e0", {"A": True, "B": True, "correction": True})))
        result = scoped(view, ("A",))
        self.assertIn("r", result["selected"])
        self.assertEqual(result["manual_metadata"], ["replace"])

    def test_independent_manual_support_survives_both_source_deletions(self):
        view = evaluate(
            list(fixture("e0", {"A": False, "B": False, "correction": True}))
        )
        self.assertEqual(view["selected"], ["r"])
        self.assertEqual(view["origins"]["r"], ["manual"])


class TestScaleFixturePartition(unittest.TestCase):
    def test_current_old_and_candidate_partitions_have_no_duplicates_or_dangling_edges(
        self,
    ):
        from spikes.spike_1.scale import edges, rows
        from spikes.validation.common import profile

        p = profile()
        n = 10
        base = list(rows(n, p, revisions=[0, 2]))
        candidate = list(rows(n, p, revisions=[1], include_base=False))
        combined = list(rows(n, p))
        self.assertEqual(len(base) + len(candidate), len(combined))
        ids = {row[0] for row in combined}
        self.assertEqual(len(ids), len(combined))
        self.assertFalse({row[0] for row in base} & {row[0] for row in candidate})
        for source, target, _ in edges(n, p):
            self.assertIn(source, ids)
            self.assertIn(target, ids)
        self.assertTrue(
            all(
                len(row[5].encode()) == p["chunk_bytes"]
                for row in combined
                if row[1] == "chunk"
            )
        )
