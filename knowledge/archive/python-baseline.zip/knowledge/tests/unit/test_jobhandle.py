"""Unit tests for the worker pool / JobHandle state machine (section 2.4/5.4)."""

from __future__ import annotations

import threading
import time
import unittest

from zknowledge.config import AdmissionConfig, TimeoutConfig
from zknowledge.errors import RecoveryRequiredError, StorageError
from zknowledge.execution import JobStatus, WorkerPool


def _pool() -> WorkerPool:
    return WorkerPool(
        AdmissionConfig(max_slots=2, max_queue=8, candidate_space_bytes=1000),
        TimeoutConfig(admission_wait_seconds=1.0, job_wait_seconds=2.0),
    )


class TestWorkerPool(unittest.TestCase):
    def test_completed_job_returns_result(self):
        pool = _pool()
        try:
            handle = pool.submit(lambda cancel: 42)
            snap = handle.wait(timeout=2)
            self.assertEqual(snap.status, JobStatus.COMPLETED)
            self.assertEqual(snap.result, 42)
        finally:
            pool.shutdown(drain=True)

    def test_known_error_marks_failed_with_code(self):
        pool = _pool()
        try:

            def boom(cancel):
                raise StorageError("nope")

            snap = pool.submit(boom).wait(timeout=2)
            self.assertEqual(snap.status, JobStatus.FAILED)
            self.assertEqual(snap.error["code"], "storage_error")
        finally:
            pool.shutdown(drain=True)

    def test_recovery_required_error_maps_status(self):
        pool = _pool()
        try:

            def unknown(cancel):
                raise RecoveryRequiredError("commit outcome unknown")

            snap = pool.submit(unknown).wait(timeout=2)
            self.assertEqual(snap.status, JobStatus.RECOVERY_REQUIRED)
        finally:
            pool.shutdown(drain=True)

    def test_admission_rejection_fails_job(self):
        pool = _pool()
        try:
            # cost over the total candidate-space budget -> non-retryable reject
            snap = pool.submit(lambda cancel: 1, cost_bytes=5000).wait(timeout=2)
            self.assertEqual(snap.status, JobStatus.FAILED)
            self.assertEqual(snap.phase, "admission")
        finally:
            pool.shutdown(drain=True)

    def test_cooperative_cancel(self):
        pool = _pool()
        try:
            started = threading.Event()

            def spin(cancel):
                started.set()
                while not cancel.is_set():
                    time.sleep(0.01)
                return "stopped"

            handle = pool.submit(spin)
            self.assertTrue(started.wait(timeout=2))
            requested = handle.cancel()
            self.assertIn(
                requested,
                {JobStatus.CANCEL_REQUESTED, JobStatus.CANCELLED},
            )
            snap = handle.wait(timeout=2)
            self.assertEqual(snap.status, JobStatus.CANCELLED)
        finally:
            pool.shutdown(drain=True)

    def test_wait_timeout_does_not_change_execution(self):
        pool = _pool()
        try:
            release = threading.Event()

            def block(cancel):
                release.wait(timeout=5)
                return "done"

            handle = pool.submit(block)
            snap = handle.wait(timeout=0.05)  # gives up waiting only
            self.assertEqual(snap.status, JobStatus.RUNNING)
            release.set()
            snap2 = handle.wait(timeout=2)
            self.assertEqual(snap2.status, JobStatus.COMPLETED)
        finally:
            pool.shutdown(drain=True)

    def test_shutdown_drains(self):
        pool = _pool()
        handle = pool.submit(lambda cancel: "ok")
        pool.shutdown(drain=True)
        self.assertEqual(handle.get().status, JobStatus.COMPLETED)


class TestWorkerQueueBound(unittest.TestCase):
    def test_executor_backlog_is_bounded_before_worker_admission(self):
        pool = WorkerPool(AdmissionConfig(max_slots=1, max_queue=1), TimeoutConfig())
        entered, release = threading.Event(), threading.Event()

        def slow(cancel):
            entered.set()
            release.wait(5)
            return "ok"

        try:
            first = pool.submit(slow)
            self.assertTrue(entered.wait(2))
            second = pool.submit(lambda cancel: "queued")
            third = pool.submit(lambda cancel: "rejected")
            self.assertEqual(third.get().status, JobStatus.FAILED)
            self.assertEqual(third.get().error["code"], "resource_exhausted")
            release.set()
            self.assertEqual(first.wait(2).status, JobStatus.COMPLETED)
            self.assertEqual(second.wait(2).status, JobStatus.COMPLETED)
        finally:
            release.set()
            pool.shutdown()


if __name__ == "__main__":
    unittest.main()
