"""Unit tests for admission control / backpressure (section 5.8)."""

from __future__ import annotations

import unittest

from zknowledge.config import AdmissionConfig
from zknowledge.errors import ResourceExhaustedError
from zknowledge.execution import AdmissionController


class TestAdmissionController(unittest.TestCase):
    def test_actual_cost_upgrade_respects_other_workers_and_releases_full_cost(self):
        controller = AdmissionController(
            AdmissionConfig(max_slots=2, candidate_space_bytes=100)
        )
        a, b = controller.acquire(20), controller.acquire(50)
        with self.assertRaises(ResourceExhaustedError):
            a.grow_to(60)
        self.assertEqual(controller.stats["reserved_bytes"], 70)
        b.release()
        a.grow_to(60)
        self.assertEqual(controller.stats["reserved_bytes"], 60)
        a.release()
        self.assertEqual(controller.stats["reserved_bytes"], 0)

    def test_slot_limit_then_release(self):
        ctrl = AdmissionController(
            AdmissionConfig(max_slots=2, max_queue=8, candidate_space_bytes=1000)
        )
        lease1 = ctrl.acquire(timeout=1)
        lease2 = ctrl.acquire(timeout=1)
        self.assertEqual(ctrl.stats["running"], 2)
        with self.assertRaises(ResourceExhaustedError):
            ctrl.acquire(timeout=0.05)  # no slot, wait times out
        lease1.release()
        lease3 = ctrl.acquire(timeout=1)  # a slot freed
        self.assertEqual(ctrl.stats["running"], 2)
        lease2.release()
        lease3.release()
        self.assertEqual(ctrl.stats["running"], 0)

    def test_candidate_space_budget(self):
        ctrl = AdmissionController(
            AdmissionConfig(max_slots=4, max_queue=8, candidate_space_bytes=100)
        )
        lease = ctrl.acquire(cost_bytes=80, timeout=1)
        self.assertEqual(ctrl.stats["reserved_bytes"], 80)
        with self.assertRaises(ResourceExhaustedError):
            ctrl.acquire(cost_bytes=50, timeout=0.05)  # 80 + 50 > 100
        lease.release()
        self.assertEqual(ctrl.stats["reserved_bytes"], 0)

    def test_request_over_total_budget_is_non_retryable(self):
        ctrl = AdmissionController(
            AdmissionConfig(max_slots=4, max_queue=8, candidate_space_bytes=100)
        )
        with self.assertRaises(ResourceExhaustedError) as ctx:
            ctrl.acquire(cost_bytes=101, timeout=1)
        self.assertFalse(ctx.exception.retryable)

    def test_queue_full_rejects_waiter(self):
        # max_queue=0 forbids waiting; the fast path still admits when a slot
        # is free, so the first acquire succeeds and the second is rejected.
        ctrl = AdmissionController(
            AdmissionConfig(max_slots=1, max_queue=0, candidate_space_bytes=1000)
        )
        lease = ctrl.acquire(timeout=1)
        self.assertEqual(ctrl.stats["running"], 1)
        with self.assertRaises(ResourceExhaustedError):
            ctrl.acquire(timeout=0.05)
        lease.release()

    def test_lease_context_manager_releases_once(self):
        ctrl = AdmissionController(
            AdmissionConfig(max_slots=1, max_queue=4, candidate_space_bytes=1000)
        )
        with ctrl.acquire(cost_bytes=10, timeout=1) as lease:
            self.assertEqual(ctrl.stats["running"], 1)
            lease.release()  # idempotent
            lease.release()
        self.assertEqual(ctrl.stats["running"], 0)
        self.assertEqual(ctrl.stats["reserved_bytes"], 0)


if __name__ == "__main__":
    unittest.main()
