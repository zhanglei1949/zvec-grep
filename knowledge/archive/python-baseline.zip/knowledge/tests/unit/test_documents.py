from __future__ import annotations

import hashlib
import threading
import unittest
from dataclasses import replace

from zknowledge import (
    MarkdownParser,
    PlainTextParser,
    SectionSegmenter,
    prepare_document,
)
from zknowledge.document_processing import (
    ParseContext,
    ProcessingBudget,
    SourceSnapshot,
    parse_document,
)
from zknowledge.documents import segment_document
from zknowledge.errors import InvalidInputError, OperationCancelledError, ProviderError


def snapshot(data):
    return SourceSnapshot("s", "r", hashlib.sha256(data).hexdigest(), data)


def context(limit=1000):
    return ParseContext(ProcessingBudget(1 << 20, limit))


class TestDocumentBuildProcessing(unittest.TestCase):
    def test_markdown_structure_uses_raw_crlf_bom_offsets(self):
        s = snapshot(
            "\ufeff前言\r\n\r\n# 一级\r\n正文\r\n\r\n## 二级\r\n尾部\r\n".encode()
        )
        parsed = parse_document(MarkdownParser(), s, context())
        sections = [b for b in parsed.blocks if b.kind == "section"]
        self.assertEqual(len(sections), 2)
        self.assertEqual(
            s.read(sections[0].span.start, sections[0].span.end),
            "# 一级\r\n正文\r\n\r\n## 二级\r\n尾部\r\n".encode(),
        )
        self.assertEqual(sections[1].parent_id, sections[0].local_id)
        units = prepare_document(s, context=context())
        self.assertEqual(b"".join(u.read(s) for u in units), s.data)

    def test_fenced_fake_heading_not_section_and_setext_is_section(self):
        s = snapshot(b"A\n===\n\n```python\n# fake\n```\n\n# B\n")
        parsed = parse_document(MarkdownParser(), s, context())
        sections = [b for b in parsed.blocks if b.kind == "section"]
        self.assertEqual([b.span.start for b in sections], [0, s.data.index(b"# B")])
        self.assertTrue(any(b.kind == "fence" for b in parsed.blocks))

    def test_plaintext_does_not_invent_markdown_sections(self):
        s = snapshot(b"# literal\n\n## more")
        self.assertEqual(len(parse_document(PlainTextParser(), s, context()).blocks), 1)

    def test_long_unicode_and_unbroken_code_preserve_coverage(self):
        s = snapshot(("# 中文\n```\n" + "数据" * 100 + "\n```\n").encode())
        units = prepare_document(s, segmenter=SectionSegmenter(19), context=context())
        self.assertGreater(len(units), 10)
        self.assertTrue(all(len(u.read(s)) <= 19 for u in units))
        self.assertEqual(b"".join(u.read(s) for u in units), s.data)

    def test_overlap_policy_and_stable_segment_ids(self):
        s = snapshot(("数据" * 25).encode())
        first = prepare_document(
            s, segmenter=SectionSegmenter(20, 4), context=context()
        )
        second = prepare_document(
            s, segmenter=SectionSegmenter(20, 4), context=context()
        )
        self.assertEqual(first, second)
        covered = 0
        for unit in first:
            self.assertLessEqual(unit.start, covered)
            self.assertLessEqual(covered - unit.start, 4)
            covered = unit.end
        self.assertEqual(covered, len(s.data))

    def test_empty_and_headings_only(self):
        self.assertEqual(prepare_document(snapshot(b""), context=context()), ())
        self.assertTrue(prepare_document(snapshot(b"# H\n"), context=context()))

    def test_parser_and_segmenter_fingerprints_are_separate(self):
        s = snapshot(b"# H\nsome content\n")
        a = prepare_document(s, context=context())
        b = prepare_document(s, segmenter=SectionSegmenter(8), context=context())
        c = prepare_document(s, parser=PlainTextParser(), context=context())
        self.assertNotEqual([u.id for u in a], [u.id for u in b])
        self.assertNotEqual(a[0].processing_fingerprint, c[0].processing_fingerprint)

    def test_bad_segment_coverage_or_digest_rejected(self):
        s = snapshot(b"abcdef")
        valid = prepare_document(s, context=context())[0]
        for bad in [replace(valid, start=1), replace(valid, content_digest="bad")]:

            class Broken:
                def describe(self):
                    return SectionSegmenter().describe()

                def segment(self, *args):
                    return (bad,)

            with self.assertRaises(ProviderError):
                segment_document(
                    Broken(),
                    parse_document(MarkdownParser(), s, context()),
                    s,
                    context(),
                )

    def test_budget_cancel_and_incomplete_parse(self):
        s = snapshot(b"# H\n\ntext\n")
        with self.assertRaises(ProviderError):
            parse_document(MarkdownParser(), s, context(1))
        event = threading.Event()
        event.set()
        with self.assertRaises(OperationCancelledError):
            prepare_document(s, context=ParseContext(ProcessingBudget(100, 100), event))
        parsed = replace(
            parse_document(MarkdownParser(), s, context()), status="partial"
        )
        with self.assertRaises(ProviderError):
            segment_document(SectionSegmenter(), parsed, s, context())
        with self.assertRaises(InvalidInputError):
            SectionSegmenter(3)
