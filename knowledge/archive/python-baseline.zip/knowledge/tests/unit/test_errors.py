"""Unit tests for the error model (design section 7.4, Phase 1 subset)."""

from __future__ import annotations

import unittest

from zknowledge.errors import (
    ErrorStage,
    IncompatibleFormatError,
    KnowledgeGraphError,
    OccupiedError,
    RecoveryRequiredError,
    ResourceExhaustedError,
    StorageError,
)


class TestErrorModel(unittest.TestCase):
    def test_base_defaults_and_dict(self):
        err = KnowledgeGraphError("boom")
        self.assertEqual(err.code, "knowledge_graph_error")
        self.assertEqual(err.stage, ErrorStage.UNKNOWN)
        self.assertFalse(err.retryable)
        payload = err.to_dict()
        self.assertEqual(payload["code"], "knowledge_graph_error")
        self.assertEqual(payload["stage"], "unknown")
        self.assertEqual(payload["message"], "boom")
        self.assertIn("retryable", payload)

    def test_subclass_classification(self):
        self.assertEqual(OccupiedError("x").code, "occupied")
        self.assertEqual(OccupiedError("x").stage, ErrorStage.OPEN)
        self.assertTrue(OccupiedError("x").retryable)
        self.assertEqual(RecoveryRequiredError("x").stage, ErrorStage.PUBLISH)
        self.assertEqual(ResourceExhaustedError("x").stage, ErrorStage.ADMISSION)
        self.assertTrue(ResourceExhaustedError("x").retryable)
        self.assertEqual(IncompatibleFormatError("x").code, "incompatible_format")
        self.assertFalse(IncompatibleFormatError("x").retryable)

    def test_cause_and_explicit_override(self):
        cause = ValueError("inner")
        err = StorageError(
            "outer", stage=ErrorStage.GRAPH_WRITE, cause=cause, retryable=False
        )
        self.assertIs(err.__cause__, cause)
        self.assertFalse(err.retryable)
        self.assertEqual(err.to_dict()["stage"], "graph_write")

    def test_storage_error_default_stage_is_unknown(self):
        self.assertEqual(StorageError("x").stage, ErrorStage.UNKNOWN)

    def test_all_share_base(self):
        for cls in (
            StorageError,
            IncompatibleFormatError,
            OccupiedError,
            RecoveryRequiredError,
            ResourceExhaustedError,
        ):
            self.assertTrue(issubclass(cls, KnowledgeGraphError))


if __name__ == "__main__":
    unittest.main()
