"""Unit tests for GraphStoreAdapter error mapping, using a stub base module.

These do not require the real graphdb: the adapter maps ``CommitOutcomeUnknown``
to ``RecoveryRequiredError`` (design sections 5.5 / 7.4) and everything else to
``StorageError``. The stub stands in for the lazily imported native module.
"""

from __future__ import annotations

import unittest

from zknowledge.adapters.graph_store import GraphStoreAdapter
from zknowledge.errors import RecoveryRequiredError, StorageError


class _FakeGraphDb:
    class CommitOutcomeUnknown(Exception):
        pass


class TestGraphStoreErrorMapping(unittest.TestCase):
    def setUp(self):
        self.adapter = GraphStoreAdapter("/tmp/zkg-unused-graph")
        self.adapter._graphdb = _FakeGraphDb

    def test_commit_outcome_unknown_maps_to_recovery_required(self):
        exc = _FakeGraphDb.CommitOutcomeUnknown("unknown")
        mapped = self.adapter._map(exc)
        self.assertIsInstance(mapped, RecoveryRequiredError)
        self.assertIs(mapped.__cause__, exc)
        self.assertEqual(mapped.to_dict()["code"], "recovery_required")

    def test_generic_error_maps_to_storage_error(self):
        mapped = self.adapter._map(RuntimeError("boom"))
        self.assertIsInstance(mapped, StorageError)
        self.assertNotIsInstance(mapped, RecoveryRequiredError)

    def test_write_txn_rejected_on_read_only(self):
        read_only = GraphStoreAdapter("/tmp/zkg-unused-graph", read_only=True)
        with self.assertRaises(StorageError):
            read_only.write_txn(lambda conn: None)

    def test_capabilities_report_no_vector_or_fulltext(self):
        # graphdb carries neither channel; zvec does (design section 8).
        caps = self.adapter.capabilities()
        self.assertFalse(caps["vector"])
        self.assertFalse(caps["fulltext"])


if __name__ == "__main__":
    unittest.main()
