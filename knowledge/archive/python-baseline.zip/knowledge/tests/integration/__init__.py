"""Integration tests: real graphdb + zvec, guarded by Spike-0 provenance.

These reuse the wheels built by ``spikes/spike_0/build.py`` (never rebuild). If
the bases are missing or the installed wheels do not match the Spike-0
receipts, the tests skip with a clear hint instead of failing.
"""

from __future__ import annotations

import unittest

from zknowledge import preflight

_IMPORT_ERROR = preflight.base_import_error()
_PROVENANCE = preflight.check_base_provenance()

if _IMPORT_ERROR is not None:
    _REASON = f"graphdb/zvec import failed: {_IMPORT_ERROR}"
elif not _PROVENANCE.ok:
    _REASON = (
        "Spike-0 provenance mismatch: "
        f"{_PROVENANCE.reason()}; reuse .artifacts/spike-0/wheels or run "
        "spikes/spike_0/build.py"
    )
else:
    _REASON = "bases ready"

_BASES_READY = _IMPORT_ERROR is None and _PROVENANCE.ok

requires_bases = unittest.skipUnless(_BASES_READY, _REASON)
