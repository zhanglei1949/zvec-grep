"""Regression gates for actual base contracts, isolated with hard timeouts."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from spikes.validation.run import execute
from tests.integration import requires_bases


@requires_bases
class TestBaseSpikeContracts(unittest.TestCase):
    def test_graph_visibility_atomicity_and_open_matrix(self):
        with tempfile.TemporaryDirectory() as d:
            result = execute("graph-contracts", Path(d), 15)
            self.assertTrue(result["passed"], result)

    def test_native_read_pin_release(self):
        with tempfile.TemporaryDirectory() as d:
            result = execute("graph-held-reader", Path(d), 5)
            self.assertTrue(result["passed"], result)

    def test_zvec_partial_write_refill_and_reopen(self):
        with tempfile.TemporaryDirectory() as d:
            result = execute("search-contracts", Path(d), 15)
            self.assertTrue(result["passed"], result)
