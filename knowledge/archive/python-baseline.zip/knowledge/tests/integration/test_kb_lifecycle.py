"""Integration tests for the KnowledgeBase lifecycle (acceptance A01/A24/A25).

Real graphdb + zvec, reusing the Spike-0 wheels. Covers create/open/close/
reopen, non-empty refusal, single-writer occupancy, read-only open, format and
identity rejection, incomplete init, and the no-raw-Cypher surface guarantee.
"""

from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from zknowledge import KnowledgeBase
from zknowledge import manifest as M
from zknowledge.errors import (
    IdentityMismatchError,
    IncompatibleFormatError,
    IncompleteInitError,
    KnowledgeGraphError,
    OccupiedError,
    StorageError,
)

from . import requires_bases


@requires_bases
class TestKbLifecycle(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name) / "kb"

    def tearDown(self):
        self._tmp.cleanup()

    def test_create_open_close_reopen(self):
        kb = KnowledgeBase.create(self.root)
        kb_id = kb.manifest.kb_id
        self.assertTrue(kb.manifest.ready)
        self.assertTrue(kb.health()["graph"]["healthy"])
        self.assertEqual(kb.health()["index"]["state"], "not_created")
        kb.close()
        self.assertTrue(kb.closed)
        with KnowledgeBase.open(self.root) as kb2:
            self.assertEqual(kb2.manifest.kb_id, kb_id)

    def test_create_refuses_non_empty(self):
        self.root.mkdir(parents=True)
        (self.root / "existing.txt").write_text("x")
        with self.assertRaises(KnowledgeGraphError):
            KnowledgeBase.create(self.root)

    def test_second_writable_open_is_occupied(self):
        kb = KnowledgeBase.create(self.root)
        try:
            self.assertTrue((self.root / "lock").exists())
            with self.assertRaises(OccupiedError):
                KnowledgeBase.open(self.root)
        finally:
            kb.close()
        self.assertFalse((self.root / "lock").exists())
        kb2 = KnowledgeBase.open(self.root)  # lock released -> succeeds
        kb2.close()

    def test_readonly_open_no_lock(self):
        kb = KnowledgeBase.create(self.root)
        kb.close()
        ro = KnowledgeBase.open(self.root, read_only=True)
        try:
            self.assertFalse((self.root / "lock").exists())
            self.assertTrue(ro.read_only)
            with self.assertRaises(StorageError):
                ro.submit(lambda cancel: None)
        finally:
            ro.close()

    def test_incompatible_format_rejected(self):
        kb = KnowledgeBase.create(self.root)
        kb.close()
        path = M.manifest_path(self.root)
        data = json.loads(path.read_text())
        data["format_version"] = 99
        path.write_text(json.dumps(data))
        with self.assertRaises(IncompatibleFormatError):
            KnowledgeBase.open(self.root)

    def test_mixed_store_rejected(self):
        kb = KnowledgeBase.create(self.root)
        kb.close()
        marker = M.read_store_marker(self.root, "graphdb")
        marker["kb_id"] = "foreign-kb"
        (self.root / "stores" / "graphdb.json").write_text(json.dumps(marker))
        with self.assertRaises(IdentityMismatchError):
            KnowledgeBase.open(self.root)

    def test_incomplete_init_rejected(self):
        kb = KnowledgeBase.create(self.root)
        kb.close()
        m = M.read_manifest(self.root)
        M.write_manifest(self.root, m.with_ready(False))
        with self.assertRaises(IncompleteInitError):
            KnowledgeBase.open(self.root)

    def test_no_public_raw_cypher_or_connection(self):
        kb = KnowledgeBase.create(self.root)
        try:
            for name in ("execute", "cypher", "connect", "connection", "cursor"):
                self.assertFalse(hasattr(kb, name), f"public {name} leaked")
            self.assertTrue(hasattr(kb, "_graph"))  # adapter stays private
        finally:
            kb.close()

    def test_capabilities_and_admission_visible(self):
        kb = KnowledgeBase.create(self.root)
        try:
            caps = kb.capabilities()
            self.assertFalse(caps["graph"]["vector"])
            self.assertFalse(caps["graph"]["fulltext"])
            self.assertTrue(caps["index"]["vector"])
            self.assertFalse(caps["embedding"]["configured"])
            self.assertIn("max_slots", kb.admission_stats())
        finally:
            kb.close()


if __name__ == "__main__":
    unittest.main()
