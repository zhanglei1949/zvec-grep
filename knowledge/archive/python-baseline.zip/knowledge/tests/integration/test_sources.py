"""Real pinned graphdb source lifecycle; injection boundaries labelled in tests."""

from __future__ import annotations

import codecs
import json
import tempfile
import threading
import unittest
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch

from tests.integration import requires_bases
from zknowledge import (
    CaptureConfig,
    DocumentInput,
    InputExcludedError,
    InvalidInputError,
    JobStatus,
    KnowledgeBase,
    KnowledgeBaseConfig,
    SourceConflictError,
    SourceSpec,
    StorageError,
)
from zknowledge.config import InputPolicy
from zknowledge.errors import IncompatibleFormatError, RecoveryRequiredError


@requires_bases
class TestSources(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / "kb"
        self.kb = KnowledgeBase.create(self.root)
        self.source = self.kb.sources.register(SourceSpec("manual", "manual.md"))

    def tearDown(self):
        self.kb.close()
        self.tmp.cleanup()

    def ingest(self, data=b"# hello", **kwargs):
        job = self.kb.ingest_documents(
            self.source.id, DocumentInput.from_bytes(data), **kwargs
        )
        result = job.wait(5)
        self.assertEqual(result.status, JobStatus.COMPLETED, result.error)
        return result.result

    def reopen(self, readonly=False):
        self.kb.close()
        self.kb = KnowledgeBase.open(self.root, read_only=readonly)

    def test_receipt_and_record_carry_digest_and_snapshot_separately(self):
        # content_digest and snapshot_id are distinct fields. Phase 2 makes them
        # equal (whole-document sha256), but the receipt, the ingestion record,
        # _confirm and Ingestions.snapshot must each reference the right one, so
        # multi-file manifests or normalized digests later do not silently break.
        result = self.ingest(b"# hello", operation_id="op-digest")
        self.assertTrue(result.content_digest)
        self.assertTrue(result.snapshot_id)
        revision = self.kb.sources.revision(result.revision_id)
        self.assertEqual(result.content_digest, revision.content_digest)
        self.assertEqual(result.snapshot_id, revision.snapshot_id)
        record = self.kb.ingestions.get("op-digest")
        self.assertEqual(record.snapshot_id, result.snapshot_id)
        self.assertEqual(record.content_digest, result.content_digest)
        frozen = self.kb.ingestions.snapshot("op-digest")
        self.assertEqual(frozen.snapshot_id, result.snapshot_id)
        self.assertEqual(frozen.read(), b"# hello")

    def test_register_identity_conflict_and_pagination(self):
        again = self.kb.sources.register(SourceSpec("manual", "manual.md"))
        self.assertEqual(again.id, self.source.id)
        for spec in (
            SourceSpec("manual", "moved.md"),
            SourceSpec("manual", "manual.md", "other"),
        ):
            with self.assertRaises(SourceConflictError):
                self.kb.sources.register(spec)
        other = self.kb.sources.register(SourceSpec("other"))
        first = self.kb.sources.list(limit=1)
        second = self.kb.sources.list(limit=1, cursor=first.next_cursor)
        self.assertEqual(
            {first.items[0].id, second.items[0].id}, {self.source.id, other.id}
        )
        self.assertIsNone(second.next_cursor)
        with self.assertRaises(InvalidInputError):
            self.kb.sources.list(limit=1001)

    def test_revisions_reselection_and_processing_change(self):
        a = self.ingest(b"A", operation_id="a")
        duplicate = self.ingest(b"A")
        self.assertEqual(duplicate.outcome, "unchanged")
        self.assertEqual(self.kb.sources.get(self.source.id).latest_ingestion_id, "a")
        b = self.ingest(b"B")
        back = self.ingest(b"A")
        self.assertEqual(back.revision_id, a.revision_id)
        self.assertEqual(back.reason, "reselected_revision")
        self.assertNotEqual(b.revision_id, a.revision_id)
        new_processing = self.ingest(b"A", capture=CaptureConfig("2"))
        self.assertEqual(new_processing.revision_id, a.revision_id)
        self.assertNotEqual(new_processing.content_unit_id, a.content_unit_id)
        self.assertEqual(new_processing.reason, "processing_changed")
        self.assertEqual(len(self.kb.sources.revisions(self.source.id).items), 2)
        self.assertEqual(self.kb.sources.read_content_unit(b.content_unit_id), b"B")
        self.assertFalse(a.search_ready)
        # Same op recovers its original receipt even after later source selections.
        replay = self.ingest(b"A", operation_id="a")
        self.assertEqual(replay, a)
        self.assertNotEqual(
            self.kb.sources.get(self.source.id).latest_ingestion_id, "a"
        )
        mismatch = self.kb.ingest_documents(
            self.source.id, DocumentInput.from_bytes(b"C"), operation_id="a"
        ).wait(5)
        self.assertEqual(mismatch.error["code"], "source_conflict")

    def test_shared_bytes_independent_sources_and_relationships(self):
        a = self.ingest()
        other = self.kb.sources.register(SourceSpec("other"))
        job = self.kb.ingest_documents(other.id, DocumentInput.from_bytes(b"# hello"))
        b = job.wait(5).result
        self.assertEqual(a.snapshot_id, b.snapshot_id)
        self.assertNotEqual(a.revision_id, b.revision_id)
        self.assertEqual(
            self.kb._graph.read(
                "MATCH (:KGSource)-[:KG_HAS_REVISION]->(:KGRevision) RETURN count(*)"
            )[0][0],
            2,
        )
        self.assertEqual(
            self.kb._graph.read(
                "MATCH (:KGRevision)-[:KG_HAS_UNIT]->(:KGContentUnit) RETURN count(*)"
            )[0][0],
            2,
        )

    def test_original_utf8_crlf_bom_empty_and_readonly_reopen(self):
        data = codecs.BOM_UTF8 + "# 中文\r\n正文\r\n".encode()
        result = self.ingest(data, operation_id="utf8")
        empty = self.ingest(b"")
        self.reopen(readonly=True)
        self.assertEqual(
            self.kb.sources.read_content_unit(result.content_unit_id), data
        )
        self.assertEqual(self.kb.sources.read_content_unit(empty.content_unit_id), b"")
        revision = self.kb.sources.revision(result.revision_id)
        self.assertTrue(revision.has_bom)
        self.assertEqual(revision.byte_length, len(data))
        self.assertEqual(self.kb.sources.snapshot(revision.id).data, data)
        self.assertEqual(self.kb.ingestions.get("utf8").result, result)
        for action in (
            lambda: self.kb.sources.register(SourceSpec("forbidden")),
            lambda: self.kb.ingest_documents(
                self.source.id, DocumentInput.from_bytes(b"x")
            ),
            lambda: self.kb.ingestions.reconcile("utf8"),
        ):
            with self.assertRaises(StorageError):
                action()

    def test_path_capture_and_exclusions_before_read(self):
        parent = Path(self.tmp.name)
        path = parent / "ok.md"
        path.write_bytes(b"original\r\n")
        result = self.kb.ingest_documents(
            self.source.id, DocumentInput.from_path(path)
        ).wait(5)
        self.assertEqual(result.status, JobStatus.COMPLETED)
        path.write_bytes(b"changed")
        self.assertEqual(
            self.kb.sources.read_content_unit(result.result.content_unit_id),
            b"original\r\n",
        )
        for name in (
            ".env",
            ".env.local",
            "private.key",
            "cert.pem",
            "credentials.json",
        ):
            secret = parent / name
            secret.write_bytes(b"SECRET_MARKER")
            with patch.object(
                Path, "open", side_effect=AssertionError("must not read")
            ):
                with self.assertRaises(InputExcludedError) as error:
                    self.kb.ingest_documents(
                        self.source.id, DocumentInput.from_path(secret)
                    )
            self.assertNotIn("SECRET_MARKER", str(error.exception.to_dict()))
        link = parent / "safe.md"
        link.symlink_to(parent / ".env")
        with self.assertRaises(InputExcludedError):
            self.kb.ingest_documents(self.source.id, DocumentInput.from_path(link))
        self.assertEqual(len(list((self.root / "snapshots").rglob("*.meta.json"))), 1)

    def test_invalid_utf8_and_failed_same_input_retry(self):
        bad = self.kb.ingest_documents(
            self.source.id, DocumentInput.from_bytes(b"\xff"), operation_id="bad"
        ).wait(5)
        self.assertEqual(bad.status, JobStatus.FAILED)
        self.assertEqual(bad.error["code"], "invalid_input")
        self.assertEqual(self.kb.sources.revisions(self.source.id).items, ())
        original = self.kb._graph.write_txn

        def rollback(fn):
            if fn.__name__ != "commit":
                return original(fn)

            def inject(conn):
                fn(conn)
                raise RuntimeError("injected rollback after business writes")

            return original(inject)

        with patch.object(self.kb._graph, "write_txn", rollback):
            failed = self.kb.ingest_documents(
                self.source.id, DocumentInput.from_bytes(b"A"), operation_id="retry"
            ).wait(5)
        self.assertEqual(failed.status, JobStatus.FAILED)
        old_attempt = self.kb.ingestions.get("retry").attempt_id
        self.assertEqual(self.kb.sources.revisions(self.source.id).items, ())
        self.assertEqual(self.kb.sources.get(self.source.id).latest_ingestion_id, "")
        self.assertTrue(
            list((self.root / "snapshots").rglob("*.meta.json"))
        )  # orphan retained
        retried = self.ingest(b"A", operation_id="retry")
        self.assertEqual(retried.outcome, "captured")
        self.assertNotEqual(retried.attempt_id, old_attempt)

    def test_concurrent_source_update_conflict_and_same_input(self):
        for second, expected in ((b"B", JobStatus.FAILED), (b"A", JobStatus.COMPLETED)):
            # Separate source per competition: both calls capture the same baseline.
            source = self.kb.sources.register(SourceSpec("race" + str(second)))
            barrier = threading.Barrier(2)
            original = self.kb.sources._read_input

            def read(*args):
                data = original(*args)
                barrier.wait(timeout=5)
                return data

            with patch.object(self.kb.sources, "_read_input", read):
                a = self.kb.ingest_documents(source.id, DocumentInput.from_bytes(b"A"))
                b = self.kb.ingest_documents(
                    source.id, DocumentInput.from_bytes(second)
                )
                outcomes = [a.wait(5), b.wait(5)]
            if second == b"B":
                self.assertEqual(
                    sum(o.status == JobStatus.COMPLETED for o in outcomes), 1
                )
                failed = next(o for o in outcomes if o.status == expected)
                self.assertEqual(failed.error["code"], "source_conflict")
            else:
                self.assertTrue(all(o.status == JobStatus.COMPLETED for o in outcomes))
                self.assertEqual(
                    {o.result.outcome for o in outcomes}, {"captured", "unchanged"}
                )

    def test_cancel_before_commit_and_late_cancel_after_commit(self):
        entered, release = threading.Event(), threading.Event()
        original = self.kb._graph.write_txn

        def paused(fn):
            value = original(fn)
            if fn.__name__ == "prepare":
                entered.set()
                release.wait(5)
            return value

        with patch.object(self.kb._graph, "write_txn", paused):
            job = self.kb.ingest_documents(
                self.source.id, DocumentInput.from_bytes(b"A"), operation_id="cancel"
            )
            self.assertTrue(entered.wait(5))
            job.cancel()
            release.set()
            self.assertEqual(job.wait(5).status, JobStatus.CANCELLED)
        self.assertEqual(self.kb.sources.get(self.source.id).latest_ingestion_id, "")
        self.assertEqual(self.kb.ingestions.get("cancel").state, "cancelled")
        entered.clear()
        release.clear()
        confirm = self.kb.sources._confirm

        def paused_confirm(result):
            entered.set()
            release.wait(5)
            confirm(result)

        with patch.object(self.kb.sources, "_confirm", paused_confirm):
            job = self.kb.ingest_documents(
                self.source.id, DocumentInput.from_bytes(b"B"), operation_id="late"
            )
            self.assertTrue(entered.wait(5))
            job.cancel()
            release.set()
            self.assertEqual(job.wait(5).status, JobStatus.COMPLETED)
        self.assertEqual(
            self.kb.sources.get(self.source.id).latest_ingestion_id, "late"
        )

    def test_unknown_commit_and_confirmation_require_reopen_reconciliation(self):
        import graphdb

        original = self.kb._graph.write_txn

        def unknown(fn):
            value = original(fn)
            if fn.__name__ == "commit":
                raise self.kb._graph._map(
                    graphdb.CommitOutcomeUnknown("injected acknowledgement loss")
                )
            return value

        with patch.object(self.kb._graph, "write_txn", unknown):
            job = self.kb.ingest_documents(
                self.source.id, DocumentInput.from_bytes(b"A"), operation_id="unknown"
            )
            self.assertEqual(job.wait(5).status, JobStatus.RECOVERY_REQUIRED)
        with self.assertRaises(RecoveryRequiredError):
            self.kb.sources.register(SourceSpec("blocked"))
        self.reopen()
        reconciled = self.kb.ingestions.reconcile("unknown")
        self.assertEqual(reconciled.state, "committed")
        self.assertEqual(self.ingest(b"A", operation_id="unknown"), reconciled.result)
        with patch.object(
            self.kb.sources,
            "_confirm",
            side_effect=StorageError("injected invisible receipt"),
        ):
            job = self.kb.ingest_documents(
                self.source.id, DocumentInput.from_bytes(b"B"), operation_id="confirm"
            )
            self.assertEqual(job.wait(5).status, JobStatus.RECOVERY_REQUIRED)
        self.reopen()
        self.assertEqual(self.kb.ingestions.reconcile("confirm").state, "committed")

    def test_prepared_intent_without_commit_explicit_reconciliation(self):
        import graphdb

        input_path = Path(self.tmp.name) / "prepared.md"
        input_path.write_bytes(b"A")

        original = self.kb._graph.write_txn

        def unknown(fn):
            value = original(fn)
            if fn.__name__ == "prepare":
                raise self.kb._graph._map(
                    graphdb.CommitOutcomeUnknown("injected prepare response loss")
                )
            return value

        with patch.object(self.kb._graph, "write_txn", unknown):
            job = self.kb.ingest_documents(
                self.source.id,
                DocumentInput.from_path(input_path),
                operation_id="prepared",
            )
            self.assertEqual(job.wait(5).status, JobStatus.RECOVERY_REQUIRED)
        self.reopen(readonly=True)
        self.assertEqual(self.kb.ingestions.get("prepared").state, "prepared")
        input_path.unlink()
        frozen_input = self.kb.ingestions.snapshot("prepared").data
        self.assertEqual(frozen_input, b"A")
        self.reopen()
        not_reconciled = self.kb.ingest_documents(
            self.source.id, DocumentInput.from_bytes(b"A"), operation_id="prepared"
        ).wait(5)
        self.assertEqual(not_reconciled.status, JobStatus.RECOVERY_REQUIRED)
        self.assertEqual(
            self.kb.ingestions.reconcile("prepared").state, "not_committed"
        )
        self.assertEqual(
            self.ingest(frozen_input, operation_id="prepared").outcome, "captured"
        )

    def test_old_schema_and_schema_create_interruption(self):
        self.kb.close()
        manifest = self.root / "manifest.json"
        content = json.loads(manifest.read_bytes())
        content["schema_version"] = 0
        manifest.write_text(json.dumps(content))
        with self.assertRaises(IncompatibleFormatError):
            KnowledgeBase.open(self.root)
        other = Path(self.tmp.name) / "partial"
        with patch(
            "zknowledge.source_store.SourceStore.initialize",
            side_effect=RuntimeError("interrupted"),
        ):
            with self.assertRaises(RuntimeError):
                KnowledgeBase.create(other)
        from zknowledge.errors import IncompleteInitError

        with self.assertRaises(IncompleteInitError):
            KnowledgeBase.open(other)
        self.assertFalse(json.loads((other / "manifest.json").read_bytes())["ready"])

    def test_close_drains_capture_and_rejects_new_work(self):
        entered, release = threading.Event(), threading.Event()
        original = self.kb.sources._read_input

        def paused(*args):
            entered.set()
            release.wait(5)
            return original(*args)

        with patch.object(self.kb.sources, "_read_input", paused):
            job = self.kb.ingest_documents(
                self.source.id, DocumentInput.from_bytes(b"A")
            )
            self.assertTrue(entered.wait(5))
            thread = threading.Thread(target=self.kb.close)
            thread.start()
            release.set()
            thread.join(5)
            self.assertFalse(thread.is_alive())
            self.assertEqual(job.get().status, JobStatus.COMPLETED)
        self.reopen()
        self.assertTrue(self.kb.sources.get(self.source.id).latest_ingestion_id)

    def test_custom_input_policy_budget_and_growth(self):
        self.kb.close()
        config = replace(
            KnowledgeBaseConfig.default(), inputs=InputPolicy(3, ("*.skip",))
        )
        self.kb = KnowledgeBase.open(self.root, config=config)
        path = Path(self.tmp.name) / "input.skip"
        path.write_bytes(b"A")
        with self.assertRaises(InputExcludedError):
            self.kb.ingest_documents(self.source.id, DocumentInput.from_path(path))
        from zknowledge.errors import ResourceExhaustedError

        with self.assertRaises(ResourceExhaustedError):
            self.ingest(b"large")
        path = Path(self.tmp.name) / "grow.md"
        path.write_bytes(b"A")
        original = self.kb.sources._read_input

        def grow(*args):
            path.write_bytes(b"AAAA")
            return original(*args)

        with patch.object(self.kb.sources, "_read_input", grow):
            job = self.kb.ingest_documents(
                self.source.id, DocumentInput.from_path(path)
            )
            self.assertEqual(job.wait(5).error["code"], "source_conflict")

    def test_missing_referenced_snapshot_is_not_silently_repaired(self):
        result = self.ingest(b"A")
        blob = self.kb._snapshots._blob_path(result.snapshot_id)
        blob.unlink()
        failed = self.kb.ingest_documents(
            self.source.id, DocumentInput.from_bytes(b"A")
        ).wait(5)
        self.assertEqual(failed.status, JobStatus.FAILED)
        self.assertFalse(blob.exists())

    def test_stale_attempt_cannot_commit(self):
        from zknowledge.source_store import fetch, put

        original = self.kb._graph.write_txn

        def takeover(fn):
            result = original(fn)
            if fn.__name__ == "prepare":

                def supersede(conn):
                    op = fetch(conn, "KGIngestOperation", "stale")
                    op["attempt_id"] = "newer-attempt"
                    put(
                        conn,
                        "KGIngestOperation",
                        "stale",
                        op,
                        owner=self.source.id,
                        state="prepared",
                    )
                    put(
                        conn,
                        "KGIngestAttempt",
                        "newer-attempt",
                        op,
                        owner="stale",
                        state="prepared",
                    )

                original(supersede)
            return result

        with patch.object(self.kb._graph, "write_txn", takeover):
            job = self.kb.ingest_documents(
                self.source.id, DocumentInput.from_bytes(b"A"), operation_id="stale"
            )
            result = job.wait(5)
            self.assertEqual(result.status, JobStatus.FAILED)
            self.assertEqual(result.error["code"], "source_conflict")
        self.assertEqual(self.kb.sources.get(self.source.id).latest_ingestion_id, "")
        self.assertEqual(self.kb.sources.revisions(self.source.id).items, ())

    def test_active_operation_and_snapshot_failure_retry(self):
        entered, release = threading.Event(), threading.Event()
        original = self.kb.sources._read_input

        def pause(*args):
            entered.set()
            release.wait(5)
            return original(*args)

        with patch.object(self.kb.sources, "_read_input", pause):
            first = self.kb.ingest_documents(
                self.source.id, DocumentInput.from_bytes(b"A"), operation_id="active"
            )
            self.assertTrue(entered.wait(5))
            second = self.kb.ingest_documents(
                self.source.id, DocumentInput.from_bytes(b"A"), operation_id="active"
            )
            self.assertEqual(second.wait(5).error["code"], "source_conflict")
            release.set()
            self.assertEqual(first.wait(5).status, JobStatus.COMPLETED)
        with patch.object(
            self.kb._snapshots,
            "put",
            side_effect=StorageError("injected snapshot failure"),
        ):
            failed = self.kb.ingest_documents(
                self.source.id,
                DocumentInput.from_bytes(b"B"),
                operation_id="snapshot-fail",
            ).wait(5)
            self.assertEqual(failed.status, JobStatus.FAILED)
        self.assertEqual(
            self.ingest(b"B", operation_id="snapshot-fail").outcome, "captured"
        )
