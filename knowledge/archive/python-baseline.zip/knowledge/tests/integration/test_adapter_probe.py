"""Integration probes for the storage adapters against real graphdb + zvec.

Verifies the narrow adapter contracts used by Phase 1: graphdb empty-database
open / health / read-only reopen, and zvec collection create / per-item insert
status / full-text + vector query / read-only reopen. The production projection
schema lands in Phase 3; this is the minimal smoke path.
"""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from zknowledge.adapters import GraphStoreAdapter, SearchIndexAdapter

from . import requires_bases


@requires_bases
class TestGraphStoreProbe(unittest.TestCase):
    def test_empty_db_open_health_and_readonly_reopen(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "graph"
            path.mkdir()
            graph = GraphStoreAdapter(path, read_only=False).open()
            try:
                self.assertTrue(graph.is_open)
                self.assertTrue(graph.health()["healthy"])
                rows = graph.read("RETURN 1")
                self.assertGreaterEqual(len(rows), 1)
                caps = graph.capabilities()
                self.assertEqual(caps["transaction_mode"], "tp")
                self.assertFalse(caps["vector"])
            finally:
                graph.close()
            read_only = GraphStoreAdapter(path, read_only=True).open()
            try:
                self.assertTrue(read_only.health()["healthy"])
                self.assertTrue(read_only.capabilities()["read_only"])
            finally:
                read_only.close()


@requires_bases
class TestSearchIndexProbe(unittest.TestCase):
    def _schema(self, zvec):
        from zvec import (
            CollectionSchema,
            DataType,
            FieldSchema,
            FtsIndexParam,
            HnswIndexParam,
            VectorSchema,
        )

        return CollectionSchema(
            name="phase1_probe",
            fields=[
                FieldSchema(
                    "body",
                    DataType.STRING,
                    nullable=False,
                    index_param=FtsIndexParam(
                        tokenizer_name="standard", filters=["lowercase"]
                    ),
                )
            ],
            vectors=[
                VectorSchema(
                    "embedding",
                    DataType.VECTOR_FP32,
                    dimension=4,
                    index_param=HnswIndexParam(),
                )
            ],
        )

    def test_create_insert_query_and_readonly_reopen(self):
        import zvec
        from zvec.model.param.query import Fts, Query

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "index"
            index = SearchIndexAdapter(path, read_only=False).create_collection(
                self._schema(zvec)
            )
            try:
                docs = [
                    zvec.Doc(
                        id="a",
                        fields={"body": "quasar knowledge graph"},
                        vectors={"embedding": [1.0, 0.0, 0.0, 0.0]},
                    ),
                    zvec.Doc(
                        id="b",
                        fields={"body": "bread flour water"},
                        vectors={"embedding": [0.0, 1.0, 0.0, 0.0]},
                    ),
                ]
                self.assertEqual(index.insert(docs), [True, True])
                index.flush()
                fts = index.query(
                    Query(field_name="body", fts=Fts(match_string="quasar")), topk=3
                )
                self.assertEqual([d.id for d in fts], ["a"])
                vec = index.query(
                    Query(field_name="embedding", vector=[1.0, 0.0, 0.0, 0.0]),
                    topk=1,
                )
                self.assertEqual([d.id for d in vec], ["a"])
                self.assertEqual(index.health()["doc_count"], 2)
            finally:
                index.close()

            read_only = SearchIndexAdapter(path, read_only=True).open(
                collection_created=True
            )
            try:
                fts2 = read_only.query(
                    Query(field_name="body", fts=Fts(match_string="quasar")), topk=3
                )
                self.assertEqual([d.id for d in fts2], ["a"])
                self.assertTrue(read_only.capabilities()["read_only"])
            finally:
                read_only.close()

    def test_open_not_created_is_a_state_not_an_error(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "index"
            path.mkdir()
            index = SearchIndexAdapter(path).open(collection_created=False)
            self.assertFalse(index.is_created)
            self.assertEqual(index.health()["state"], "not_created")
            index.close()


if __name__ == "__main__":
    unittest.main()
