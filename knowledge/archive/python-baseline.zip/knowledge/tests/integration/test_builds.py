from __future__ import annotations

import tempfile
import threading
import unittest
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch

from zknowledge import (
    BuildConfig,
    DocumentInput,
    EmbeddedVector,
    KnowledgeBase,
    KnowledgeBaseConfig,
    MarkdownParser,
    PlainTextParser,
    PrecomputedEmbeddings,
    SectionSegmenter,
    SourceSpec,
    StoreConfig,
    SyntheticEmbeddingProvider,
    prepare_document,
)
from zknowledge.document_processing import ParseContext, ProcessingBudget
from zknowledge.errors import (
    CapabilityNotConfiguredError,
    ProviderError,
    RecoveryRequiredError,
    ResourceExhaustedError,
    StorageError,
)
from zknowledge.execution import JobStatus
from zknowledge.publication_store import fetch, put

from . import requires_bases


@requires_bases
class TestDocumentBuilds(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / "kb"
        self.kb = KnowledgeBase.create(self.root)
        self.source = self.kb.sources.register(SourceSpec("manual"))
        self.config = BuildConfig(
            embedding=SyntheticEmbeddingProvider(3), vector="required"
        )

    def tearDown(self):
        self.kb.close()
        self.tmp.cleanup()

    def capture(self, text=b"# Heading\n\nquasar text\n", source=None):
        result = self.kb.ingest_documents(
            (source or self.source).id, DocumentInput.from_bytes(text)
        ).wait(10)
        self.assertEqual(result.status, JobStatus.COMPLETED, result.error)
        self.assertFalse(result.result.search_ready)
        return result.result

    def build(self, capture, config=None, operation_id=None):
        snapshot = self.kb.build_documents(
            capture.revision_id, config=config or self.config, operation_id=operation_id
        ).wait(15)
        self.assertEqual(snapshot.status, JobStatus.COMPLETED, snapshot.error)
        return snapshot.result

    def reopen(self, readonly=False):
        self.kb.close()
        self.kb = KnowledgeBase.open(self.root, read_only=readonly)

    def test_capture_build_reopen_and_bounded_inspection(self):
        capture = self.capture(
            "\ufeff# 标题\r\n\r\nquasar 中文\r\n\r\n## H2\r\nnext\r\n".encode()
        )
        result = self.build(capture, operation_id="build-v1")
        self.assertTrue(
            result.text_ready and result.vector_ready and result.search_ready
        )
        self.assertEqual(
            self.kb.publications.current(self.source.id).publication_id,
            result.publication_id,
        )
        self.assertEqual(self.kb.publications.get(result.publication_id).result, result)
        self.assertFalse(
            self.kb.ingestions.get(capture.operation_id).result.search_ready
        )
        units = self.kb.builds.segments("build-v1", limit=1)
        self.assertEqual(len(units.items), 1)
        self.assertIsNotNone(units.next_cursor)
        unit = self.kb.sources.content_unit(units.items[0].id)
        self.assertEqual(
            self.kb.sources.read_content_unit(unit.id),
            self.kb.sources.snapshot(capture.revision_id).data[unit.start : unit.end],
        )
        self.reopen(readonly=True)
        self.assertEqual(self.kb.builds.get("build-v1").result, result)
        self.kb.builds._confirm(result)
        with self.assertRaises(StorageError):
            self.kb.builds.reconcile("build-v1")

    def test_repeat_build_and_replay_are_not_repeat_publication(self):
        capture = self.capture()
        first = self.build(capture, operation_id="first")
        repeat = self.build(capture, operation_id="repeat")
        self.assertEqual(repeat.outcome, "unchanged")
        self.assertEqual(repeat.view_version, first.view_version)
        self.assertEqual(repeat.publication_id, first.publication_id)
        self.assertEqual(self.build(capture, operation_id="first"), first)
        self.assertEqual(self.kb.builds.reconcile("repeat").result, repeat)
        other_config = replace(self.config, segmenter=SectionSegmenter(16))
        failed = self.kb.build_documents(
            capture.revision_id, config=other_config, operation_id="first"
        ).wait(10)
        self.assertEqual(failed.error["code"], "source_conflict")

    def test_changed_embedding_reuses_text_and_retains_old_generation(self):
        capture = self.capture()
        first = self.build(capture, operation_id="first")
        with (
            patch.object(
                MarkdownParser, "parse", side_effect=AssertionError("must reuse parser")
            ),
            patch.object(
                SectionSegmenter,
                "segment",
                side_effect=AssertionError("must reuse segments"),
            ),
        ):
            second = self.build(
                capture,
                replace(self.config, embedding=SyntheticEmbeddingProvider(5)),
                "second",
            )
        self.assertEqual(second.text_collection, first.text_collection)
        self.assertNotEqual(second.vector_collection, first.vector_collection)
        self.assertIn("text_projection", second.reused_stages)
        self.assertEqual(second.outcome, "partial_processing")
        self.kb.builds._confirm(first)
        self.reopen()
        self.kb.builds._confirm(first)
        self.kb.builds._confirm(second)

    def test_segment_change_reuses_parse_parser_change_rebuilds(self):
        capture = self.capture(b"# H\n" + b"quasar " * 20)
        self.build(capture)
        with patch.object(
            MarkdownParser, "parse", side_effect=AssertionError("must reuse parse")
        ):
            second = self.build(
                capture, replace(self.config, segmenter=SectionSegmenter(20))
            )
        self.assertIn("parse", second.reused_stages)
        self.assertNotIn("segment", second.reused_stages)
        third = self.build(capture, replace(self.config, parser=PlainTextParser()))
        self.assertNotIn("parse", third.reused_stages)

    def test_a_b_a_reselect_not_unchanged(self):
        a = self.capture(b"# A\nquasar\n")
        first = self.build(a)
        b = self.capture(b"# B\nquasar\n")
        second = self.build(b)
        again = self.capture(b"# A\nquasar\n")
        third = self.build(again)
        self.assertEqual(a.revision_id, again.revision_id)
        self.assertNotEqual(third.outcome, "unchanged")
        self.assertGreater(third.view_version, second.view_version)
        self.kb.builds._confirm(first)

    def test_precomputed_persisted_input_and_exact_manifest_coverage(self):
        capture = self.capture()
        snapshot = self.kb.sources.snapshot(capture.revision_id)
        units = prepare_document(
            snapshot, context=ParseContext(ProcessingBudget(10000, 100))
        )
        synthetic = SyntheticEmbeddingProvider(3)
        precomputed = PrecomputedEmbeddings(
            synthetic.describe().space,
            tuple(EmbeddedVector(u.id, u.input_digest, (1.0, 0.0, 0.0)) for u in units),
        )
        config = replace(self.config, embedding=precomputed)
        result = self.build(capture, config, "precomputed")
        self.reopen()
        frozen = self.kb.builds.precomputed("precomputed")
        self.assertEqual(
            frozen.describe().fingerprint, precomputed.describe().fingerprint
        )
        self.assertEqual(
            self.build(capture, replace(config, embedding=frozen), "precomputed"),
            result,
        )
        extra = PrecomputedEmbeddings(
            synthetic.describe().space,
            precomputed.values + (EmbeddedVector("extra", "digest", (1.0, 0.0, 0.0)),),
        )
        failed = self.kb.build_documents(
            capture.revision_id,
            config=replace(config, embedding=extra),
            operation_id="bad",
        ).wait(10)
        self.assertEqual(failed.status, JobStatus.FAILED)
        self.assertEqual(
            self.kb.publications.current(self.source.id).publication_id,
            result.publication_id,
        )

    def test_required_missing_optional_provider_error_and_empty(self):
        capture = self.capture()
        with self.assertRaises(CapabilityNotConfiguredError):
            self.kb.build_documents(
                capture.revision_id, config=BuildConfig(vector="required")
            )
        text = self.build(capture, BuildConfig(vector="disabled"))
        self.assertTrue(text.text_ready)
        self.assertFalse(text.vector_ready)
        with patch.object(
            SyntheticEmbeddingProvider, "embed", side_effect=ProviderError("bad output")
        ):
            optional = self.build(capture, replace(self.config, vector="optional"))
        self.assertIn("optional_embedding_unavailable", optional.diagnostics)
        self.assertFalse(optional.vector_ready)
        empty = self.capture(b"")
        with patch.object(
            SyntheticEmbeddingProvider,
            "embed",
            side_effect=AssertionError("no empty call"),
        ):
            result = self.build(empty)
        self.assertEqual(result.unit_count, 0)
        self.assertTrue(result.indexed_empty)
        self.assertTrue(result.search_ready)

    def test_required_provider_failure_keeps_current_and_same_operation_retry(self):
        first = self.build(self.capture())
        capture = self.capture(b"# New\nquasar revision\n")
        with patch.object(
            SyntheticEmbeddingProvider,
            "embed",
            side_effect=ProviderError("known failed"),
        ):
            failed = self.kb.build_documents(
                capture.revision_id, config=self.config, operation_id="retry"
            ).wait(10)
        self.assertEqual(failed.status, JobStatus.FAILED)
        self.assertEqual(
            self.kb.publications.current(self.source.id).publication_id,
            first.publication_id,
        )
        retried = self.build(capture, operation_id="retry")
        self.assertNotEqual(retried.publication_id, first.publication_id)

    def test_new_capture_fences_an_old_build(self):
        a = self.capture()
        entered, release = threading.Event(), threading.Event()
        original = self.kb.builds._verify_manifest

        def paused(*args):
            value = original(*args)
            entered.set()
            release.wait(10)
            return value

        with patch.object(self.kb.builds, "_verify_manifest", paused):
            job = self.kb.build_documents(a.revision_id, config=self.config)
            self.assertTrue(entered.wait(10))
            self.capture(b"# Later\nquasar\n")
            release.set()
            failed = job.wait(10)
        self.assertEqual(failed.error["code"], "source_conflict")
        self.assertIsNone(self.kb.publications.current(self.source.id))

    def test_old_read_snapshot_coexists_with_publication(self):
        capture = self.capture()
        first = self.build(capture)
        later = self.capture(b"# Next\nquasar next\n")
        with self.kb._graph.read_txn() as conn:
            self.assertEqual(
                fetch(conn, "KGSourceSelection", self.source.id)["publication_id"],
                first.publication_id,
            )
            second = self.build(later)
            self.assertEqual(
                fetch(conn, "KGSourceSelection", self.source.id)["publication_id"],
                first.publication_id,
            )
        self.assertEqual(
            self.kb.publications.current(self.source.id).publication_id,
            second.publication_id,
        )

    def test_later_publication_before_earlier_confirmation_is_success(self):
        first_capture = self.capture()
        entered, release = threading.Event(), threading.Event()
        original = self.kb.builds._confirm

        def paused(result):
            if result.operation_id == "A":
                entered.set()
                release.wait(10)
            return original(result)

        with patch.object(self.kb.builds, "_confirm", paused):
            job = self.kb.build_documents(
                first_capture.revision_id, config=self.config, operation_id="A"
            )
            self.assertTrue(entered.wait(10))
            b = self.build(self.capture(b"# B\nquasar\n"), operation_id="B")
            release.set()
            a = job.wait(10)
        self.assertEqual(a.status, JobStatus.COMPLETED, a.error)
        self.assertLess(a.result.view_version, b.view_version)
        self.assertFalse(self.kb._graph.recovery_required)

    def test_atomic_publish_failure_has_no_partial_effect(self):
        capture = self.capture()
        original = self.kb._graph.write_txn

        def rollback(fn):
            if fn.__name__ == "publish":

                def body(conn):
                    fn(conn)
                    raise StorageError("injected transaction body failure")

                return original(body)
            return original(fn)

        with patch.object(self.kb._graph, "write_txn", rollback):
            result = self.kb.build_documents(
                capture.revision_id, config=self.config, operation_id="atomic"
            ).wait(10)
        self.assertEqual(result.status, JobStatus.FAILED)
        self.assertIsNone(self.kb.publications.current(self.source.id))
        self.assertIsNone(self.kb.builds._store.get("KGPublicationReceipt", "atomic"))
        self.assertEqual(
            self.kb.builds._store.get("KGPublicationView", "current")["version"], 0
        )
        self.assertTrue(self.build(capture, operation_id="atomic").search_ready)

    def test_commit_response_lost_quarantines_and_reconciles(self):
        import graphdb

        capture = self.capture()
        original = self.kb._graph.write_txn

        def lost(fn):
            value = original(fn)
            if fn.__name__ == "publish":
                raise self.kb._graph._map(
                    graphdb.CommitOutcomeUnknown("injected lost response")
                )
            return value

        with patch.object(self.kb._graph, "write_txn", lost):
            result = self.kb.build_documents(
                capture.revision_id, config=self.config, operation_id="unknown"
            ).wait(10)
        self.assertEqual(result.status, JobStatus.RECOVERY_REQUIRED)
        self.reopen(readonly=True)
        self.assertIsNotNone(self.kb.builds.get("unknown").result)
        self.reopen()
        reconciled = self.kb.builds.reconcile("unknown")
        self.assertEqual(reconciled.state, "committed")
        self.assertEqual(self.build(capture, operation_id="unknown"), reconciled.result)

    def test_cancel_before_publish_and_after_commit(self):
        capture = self.capture()
        entered, release = threading.Event(), threading.Event()
        original = self.kb.builds._verify_manifest

        def pause(*args):
            value = original(*args)
            entered.set()
            release.wait(10)
            return value

        with patch.object(self.kb.builds, "_verify_manifest", pause):
            job = self.kb.build_documents(capture.revision_id, config=self.config)
            self.assertTrue(entered.wait(10))
            job.cancel()
            release.set()
            self.assertEqual(job.wait(10).status, JobStatus.CANCELLED)
        self.assertIsNone(self.kb.publications.current(self.source.id))
        entered.clear()
        release.clear()
        original = self.kb._graph.write_txn

        def late(fn):
            value = original(fn)
            if fn.__name__ == "publish":
                entered.set()
                release.wait(10)
            return value

        with patch.object(self.kb._graph, "write_txn", late):
            job = self.kb.build_documents(capture.revision_id, config=self.config)
            self.assertTrue(entered.wait(10))
            job.cancel()
            release.set()
            self.assertEqual(job.wait(10).status, JobStatus.COMPLETED)

    def test_stale_attempt_fenced(self):
        capture = self.capture()
        original = self.kb._graph.write_txn

        def takeover(fn):
            value = original(fn)
            if fn.__name__ == "prepare":

                def newer(c):
                    op = fetch(c, "KGBuild", "stale")
                    op["attempt_id"] = "newer"
                    put(c, "KGBuild", "stale", op, owner=self.source.id)

                original(newer)
            return value

        with patch.object(self.kb._graph, "write_txn", takeover):
            result = self.kb.build_documents(
                capture.revision_id, config=self.config, operation_id="stale"
            ).wait(10)
        self.assertEqual(result.error["code"], "source_conflict")
        self.assertIsNone(self.kb.publications.current(self.source.id))

    def test_multi_source_merge_and_partial_space_switch_rejected(self):
        a = self.build(self.capture())
        other = self.kb.sources.register(SourceSpec("other"))
        b = self.build(self.capture(b"# Other\nquasar\n", other))
        self.assertGreater(b.view_version, a.view_version)
        capture = self.capture(b"# Update\nquasar\n")
        failed = self.kb.build_documents(
            capture.revision_id,
            config=replace(self.config, embedding=SyntheticEmbeddingProvider(5)),
        ).wait(10)
        self.assertEqual(failed.error["code"], "source_conflict")
        self.assertEqual(
            self.kb.publications.current(other.id).publication_id, b.publication_id
        )
        self.assertEqual(
            self.kb.publications.current(self.source.id).publication_id,
            a.publication_id,
        )

    def test_missing_artifact_is_not_false_unchanged_or_recreated(self):
        capture = self.capture()
        result = self.build(capture, operation_id="first")
        (self.root / "artifacts" / (result.manifest_id + ".json")).unlink()
        failed = self.kb.build_documents(
            capture.revision_id, config=self.config, operation_id="first"
        ).wait(10)
        self.assertEqual(failed.status, JobStatus.RECOVERY_REQUIRED)

    def test_disk_and_runtime_budget_failures_preserve_publication(self):
        first = self.build(self.capture())
        capture = self.capture(b"# New\nquasar\n")
        config = replace(self.config, min_free_disk_bytes=1 << 62)
        failed = self.kb.build_documents(capture.revision_id, config=config).wait(10)
        self.assertEqual(failed.error["code"], "resource_exhausted")
        self.assertEqual(
            self.kb.publications.current(self.source.id).publication_id,
            first.publication_id,
        )

    def test_actual_graph_budget_is_passed_to_native_engine(self):
        self.kb.close()
        config = replace(
            KnowledgeBaseConfig.default(),
            store=StoreConfig(graph_max_intermediate_rows=4),
        )
        self.kb = KnowledgeBase.open(self.root, config=config)
        with self.assertRaises(ResourceExhaustedError):
            self.kb._graph.read("UNWIND range(0,20) AS x RETURN x")

    def test_segment_expansion_stops_before_metadata_and_index_writes(self):
        first = self.build(self.capture())
        capture = self.capture(b"# Many\n" + b"quasar " * 2048)
        self.kb.close()
        defaults = KnowledgeBaseConfig.default()
        self.kb = KnowledgeBase.open(
            self.root,
            config=replace(
                defaults,
                admission=replace(defaults.admission, candidate_space_bytes=32 << 20),
            ),
        )
        config = BuildConfig(
            segmenter=SectionSegmenter(4),
            embedding=SyntheticEmbeddingProvider(384),
            vector="required",
        )
        failed = self.kb.build_documents(capture.revision_id, config=config).wait(15)
        self.assertEqual(failed.error["code"], "resource_exhausted")
        self.assertEqual(
            self.kb._graph.read(
                "MATCH (n:KGSegment) WHERE n.revision_id=$r RETURN count(n)",
                {"r": capture.revision_id},
            )[0][0],
            0,
        )
        self.assertEqual(
            self.kb.publications.current(self.source.id).publication_id,
            first.publication_id,
        )

    def test_independent_sources_keep_separate_revision_and_segment_ownership(self):
        other = self.kb.sources.register(SourceSpec("other"))
        a, b = self.capture(), self.capture(source=other)
        self.assertEqual(a.snapshot_id, b.snapshot_id)
        self.assertNotEqual(a.revision_id, b.revision_id)
        ra, rb = self.build(a), self.build(b)
        ua = self.kb.builds.segments(ra.operation_id).items[0]
        ub = self.kb.builds.segments(rb.operation_id).items[0]
        self.assertNotEqual(ua.id, ub.id)
        self.assertNotEqual(ua.source_id, ub.source_id)

    def test_same_target_concurrent_builds_can_reuse_completed_effect(self):
        capture = self.capture()
        barrier = threading.Barrier(2)
        original = SyntheticEmbeddingProvider.embed

        def simultaneous(provider, items, context):
            barrier.wait(10)
            return original(provider, items, context)

        with patch.object(SyntheticEmbeddingProvider, "embed", simultaneous):
            a = self.kb.build_documents(capture.revision_id, config=self.config)
            b = self.kb.build_documents(capture.revision_id, config=self.config)
            results = [a.wait(15), b.wait(15)]
        self.assertEqual(
            [r.status for r in results],
            [JobStatus.COMPLETED] * 2,
            [r.error for r in results],
        )
        self.assertEqual(sum(r.result.outcome == "unchanged" for r in results), 1)
        self.assertTrue(
            all(
                r.result.outcome in {"unchanged", "full_rebuild", "partial_processing"}
                for r in results
            )
        )
        self.assertEqual(
            results[0].result.publication_id, results[1].result.publication_id
        )

    def test_unrelated_sources_concurrent_first_vector_publications_merge(self):
        other = self.kb.sources.register(SourceSpec("other"))
        a, b = self.capture(), self.capture(b"# B\nquasar\n", other)
        barrier = threading.Barrier(2)
        original = SyntheticEmbeddingProvider.embed

        def simultaneous(provider, items, context):
            barrier.wait(10)
            return original(provider, items, context)

        with patch.object(SyntheticEmbeddingProvider, "embed", simultaneous):
            ja = self.kb.build_documents(a.revision_id, config=self.config)
            jb = self.kb.build_documents(b.revision_id, config=self.config)
            results = [ja.wait(15), jb.wait(15)]
        self.assertTrue(
            all(r.status == JobStatus.COMPLETED for r in results),
            [r.error for r in results],
        )
        self.assertIsNotNone(self.kb.publications.current(self.source.id))
        self.assertIsNotNone(self.kb.publications.current(other.id))
        self.assertEqual(
            self.kb.builds._store.get("KGPublicationView", "current")["version"], 2
        )

    def test_index_response_loss_uses_fetch_without_duplicate_reinsert(self):
        from zknowledge.adapters.search_index import SearchIndexAdapter

        capture = self.capture()
        original = SearchIndexAdapter.write_items
        lost = []

        def once(adapter, docs, **kwargs):
            result = original(adapter, docs, **kwargs)
            if not lost:
                lost.append(True)
                raise StorageError("injected index response loss")
            return result

        with patch.object(SearchIndexAdapter, "write_items", once):
            result = self.build(capture)
        manifest = self.kb.builds._artifacts.get(result.manifest_id)
        self.assertEqual(len(manifest["projections"]), result.unit_count * 2)
        self.assertTrue(lost)

    def test_creation_interrupted_after_native_create_reconciles_explicitly(self):
        capture = self.capture()
        original = self.kb._index._save
        calls = []

        def failed_registration():
            calls.append(True)
            if len(calls) == 2:
                raise OSError("injected marker failure")
            return original()

        with patch.object(self.kb._index, "_save", failed_registration):
            job = self.kb.build_documents(
                capture.revision_id, config=self.config, operation_id="creation"
            )
            state = job.wait(10)
        self.assertEqual(state.status, JobStatus.RECOVERY_REQUIRED)
        self.assertIsNone(self.kb.publications.current(self.source.id))
        self.reopen(readonly=True)
        self.assertFalse(self.kb.health()["index"]["healthy"])
        self.assertEqual(self.kb.health()["index"]["pending_creations"], 1)
        self.reopen()
        self.assertEqual(self.kb.builds.reconcile("creation").state, "not_committed")
        result = self.build(capture, operation_id="creation")
        self.assertTrue(result.search_ready)

    def test_missing_registered_collection_is_error_not_empty_index(self):
        import shutil

        capture = self.capture()
        result = self.build(capture)
        self.kb.close()
        shutil.rmtree(self.root / "index" / "collections" / result.vector_collection)
        with self.assertRaises(StorageError):
            KnowledgeBase.open(self.root, read_only=True)

    def test_readonly_checks_do_not_mutate_files(self):
        from spikes.validation.common import tree_digest

        self.kb.close()
        self.kb = KnowledgeBase.open(
            self.root,
            config=replace(
                KnowledgeBaseConfig.default(),
                store=StoreConfig(index_compact_threshold=2),
            ),
        )
        for i in range(3):
            result = self.build(self.capture(f"# Read only {i}\nquasar\n".encode()))
        self.kb.close()
        before = tree_digest(self.root)
        self.kb = KnowledgeBase.open(self.root, read_only=True)
        self.kb.builds._confirm(result)
        self.assertEqual(
            self.kb.health()["index"]["readonly_index_mode"], "isolated_copy"
        )
        self.assertGreater(self.kb.health()["index"]["readonly_copy_bytes"], 0)
        self.kb.close()
        self.assertEqual(before, tree_digest(self.root))

    def test_readonly_copy_budget_failure_does_not_write_original_files(self):
        from spikes.validation.common import tree_digest

        self.build(self.capture())
        self.kb.close()
        before = tree_digest(self.root)
        defaults = KnowledgeBaseConfig.default()
        config = replace(
            defaults,
            admission=replace(defaults.admission, candidate_space_bytes=1024),
        )
        with self.assertRaises(ResourceExhaustedError):
            KnowledgeBase.open(self.root, read_only=True, config=config)
        self.assertEqual(before, tree_digest(self.root))

    def test_build_deadline_and_cancelled_input_are_not_success(self):
        capture = self.capture()
        config = replace(self.config, deadline_seconds=1e-12)
        result = self.kb.build_documents(capture.revision_id, config=config).wait(10)
        self.assertEqual(result.status, JobStatus.FAILED)
        self.assertIsNone(self.kb.publications.current(self.source.id))

    def test_native_item_status_preserves_codes_without_input_leak(self):
        import zvec

        from zknowledge.adapters.search_index import SearchIndexAdapter
        from zknowledge.index_catalog import descriptor, native_schema

        with tempfile.TemporaryDirectory() as tmp:
            d = descriptor("text")
            adapter = SearchIndexAdapter(Path(tmp) / "status").create_collection(
                native_schema(d)
            )
            fields = {
                n: ""
                for n in (
                    "business_id",
                    "source_id",
                    "revision_id",
                    "build_version",
                    "space_id",
                    "content_digest",
                    "input_digest",
                )
            }
            fields["body"] = "do-not-leak-content"
            docs = [zvec.Doc(id=i, fields=fields) for i in ("a", "a", "b")]
            status = adapter.write_items(docs)
            self.assertEqual([v.ok for v in status], [True, False, True])
            self.assertIn("ALREADY_EXISTS", status[1].code)
            self.assertNotIn("do-not-leak-content", str(status))
            reused = adapter.write_items([docs[0]], upsert=True)
            self.assertEqual(reused[0].code, "OK_REUSED")
            with self.assertRaises(StorageError):
                adapter.write_items(
                    [zvec.Doc(id="a", fields={**fields, "body": "changed"})],
                    upsert=True,
                )
            repaired = adapter.write_items(
                [zvec.Doc(id="missing", fields=fields)], upsert=True
            )
            self.assertTrue(repaired[0].ok)
            self.assertEqual(
                set(adapter.fetch(["a", "b", "missing"])), {"a", "b", "missing"}
            )
            adapter.close()

    def test_close_drains_accepted_build_without_public_guard_failure(self):
        capture = self.capture()
        entered, release = threading.Event(), threading.Event()
        original = SyntheticEmbeddingProvider.embed

        def paused(provider, items, context):
            entered.set()
            release.wait(10)
            return original(provider, items, context)

        with patch.object(SyntheticEmbeddingProvider, "embed", paused):
            job = self.kb.build_documents(capture.revision_id, config=self.config)
            self.assertTrue(entered.wait(10))
            closer = threading.Thread(target=self.kb.close)
            closer.start()
            release.set()
            closer.join(15)
            self.assertFalse(closer.is_alive())
            self.assertEqual(job.get().status, JobStatus.COMPLETED, job.get().error)
        self.kb = KnowledgeBase.open(self.root)
        self.assertEqual(self.kb.builds.get(job.operation_id).phase, "confirmed")

    def test_provider_result_saved_before_status_loss_does_not_replay(self):
        capture = self.capture()
        original = self.kb.builds._cache_put

        def lose_status(key, value, owner, **kwargs):
            result = original(key, value, owner, **kwargs)
            if (
                value
                and isinstance(value, list)
                and isinstance(value[0], dict)
                and "vector" in value[0]
            ):
                raise RecoveryRequiredError("injected call status response loss")
            return result

        with patch.object(self.kb.builds, "_cache_put", lose_status):
            job = self.kb.build_documents(
                capture.revision_id, config=self.config, operation_id="call-status"
            )
            self.assertEqual(job.wait(10).status, JobStatus.RECOVERY_REQUIRED)
        self.reopen()
        self.assertEqual(self.kb.builds.reconcile("call-status").state, "not_committed")
        with patch.object(
            SyntheticEmbeddingProvider,
            "embed",
            side_effect=AssertionError("must reuse reliable result"),
        ):
            self.assertTrue(
                self.build(capture, operation_id="call-status").vector_ready
            )

    def test_retired_read_budget_backpressure_keeps_failure_record_and_current_view(
        self,
    ):
        first = self.build(self.capture())
        later = self.capture(b"# Next\nquasar\n")
        self.kb.close()
        config = replace(
            KnowledgeBaseConfig.default(),
            store=StoreConfig(graph_max_retired_versions=10),
        )
        self.kb = KnowledgeBase.open(self.root, config=config)
        with self.kb._graph.read_txn():
            failed = self.kb.build_documents(
                later.revision_id, config=self.config, operation_id="pressure"
            ).wait(10)
            self.assertEqual(failed.status, JobStatus.FAILED, failed.error)
            self.assertEqual(failed.error["code"], "resource_exhausted")
            self.assertFalse(self.kb._graph.recovery_required)
            self.assertEqual(self.kb.builds.get("pressure").state, "failed")
            self.assertEqual(
                self.kb.publications.current(self.source.id).publication_id,
                first.publication_id,
            )
        self.assertTrue(self.build(later, operation_id="pressure").search_ready)

    def test_physical_compaction_keeps_old_published_projection_ids(self):
        self.kb.close()
        self.kb = KnowledgeBase.open(
            self.root,
            config=replace(
                KnowledgeBaseConfig.default(),
                store=StoreConfig(index_compact_threshold=2),
            ),
        )
        first = self.build(self.capture())
        for i in range(3):
            self.build(self.capture(f"# Revision {i}\nquasar\n".encode()))
            self.kb.builds._confirm(first)
        path = self.kb._index.get(first.vector_collection).path
        self.assertLess(len(list(path.rglob("*.proxima"))), 2)
        self.reopen(readonly=True)
        self.kb.builds._confirm(first)

    def test_capture_failure_can_record_outcome_under_retained_read_backpressure(self):
        first = self.capture()
        self.kb.close()
        self.kb = KnowledgeBase.open(
            self.root,
            config=replace(
                KnowledgeBaseConfig.default(),
                store=StoreConfig(graph_max_retired_versions=10),
            ),
        )
        with self.kb._graph.read_txn():
            for _ in range(3):
                self.kb._graph.write_txn(
                    lambda c: put(
                        c,
                        "KGPublicationView",
                        "current",
                        fetch(c, "KGPublicationView", "current"),
                    )
                )
            job = self.kb.ingest_documents(
                self.source.id,
                DocumentInput.from_bytes(b"next"),
                operation_id="capture-pressure",
            )
            failed = job.wait(10)
            self.assertEqual(failed.error["code"], "resource_exhausted")
            self.assertFalse(self.kb._graph.recovery_required)
            self.assertEqual(
                self.kb.sources.get(self.source.id).latest_ingestion_id,
                first.operation_id,
            )
            self.assertEqual(self.kb.ingestions.get("capture-pressure").state, "failed")
        self.assertEqual(
            self.kb.ingestions.reconcile("capture-pressure").state, "not_committed"
        )
        retried = self.kb.ingest_documents(
            self.source.id,
            DocumentInput.from_bytes(b"next"),
            operation_id="capture-pressure",
        ).wait(10)
        self.assertEqual(retried.status, JobStatus.COMPLETED, retried.error)
