"""Execution model (section 2.4) and build admission/backpressure (section 5.8).

Phase 1 scaffolding: queries are synchronous on the handle, while long-running
maintenance operations are submitted to a bounded worker pool and return a
``JobHandle``. The handle is thread-safe; admission enforces a bounded queue,
limited execution slots and a candidate-space budget. Cancellation is
cooperative and takes effect at safe boundaries (section 5.4) -- it never
promises to interrupt a running native call immediately. Real ingest/build jobs
land in Phase 2/3; Phase 1 validates admission/cancel/wait semantics.
"""

from __future__ import annotations

import itertools
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from enum import Enum
from typing import Any, Callable, Optional

from .config import AdmissionConfig, TimeoutConfig
from .errors import (
    ErrorStage,
    KnowledgeGraphError,
    OperationCancelledError,
    RecoveryRequiredError,
    ResourceExhaustedError,
)


class JobStatus(str, Enum):
    """Task states (section 5.4); capability readiness is tracked separately."""

    QUEUED = "queued"
    RUNNING = "running"
    CANCEL_REQUESTED = "cancel_requested"
    CANCELLED = "cancelled"
    FAILED = "failed"
    RECOVERY_REQUIRED = "recovery_required"
    COMPLETED = "completed"


TERMINAL_STATUSES = frozenset(
    {
        JobStatus.CANCELLED,
        JobStatus.FAILED,
        JobStatus.RECOVERY_REQUIRED,
        JobStatus.COMPLETED,
    }
)


@dataclass(frozen=True)
class JobSnapshot:
    job_id: str
    status: JobStatus
    phase: str = "idle"
    error: Optional[dict] = None
    result: Any = None


@dataclass(frozen=True)
class _CommittedResult:
    """Internal fence: a durable, confirmed effect wins a late cancellation."""

    value: Any


class AdmissionLease:
    """A granted admission slot; release returns slots and space budget."""

    def __init__(self, controller: "AdmissionController", cost_bytes: int) -> None:
        self._controller = controller
        self._cost = cost_bytes
        self._released = False

    def release(self) -> None:
        if self._released:
            return
        self._released = True
        self._controller._release(self._cost)

    def grow_to(self, cost_bytes: int) -> None:
        """Do not wait for extra quota while retaining a worker's existing quota."""
        with self._controller._cond:
            if self._released or cost_bytes <= self._cost:
                return
            extra = cost_bytes - self._cost
            if (
                self._controller._reserved + extra
                > self._controller._cfg.candidate_space_bytes
            ):
                raise ResourceExhaustedError(
                    "actual preparation exceeds shared admission budget"
                )
            self._controller._reserved += extra
            self._cost = cost_bytes

    def __enter__(self) -> "AdmissionLease":
        return self

    def __exit__(self, *exc: object) -> None:
        self.release()


class AdmissionController:
    """Bounded queue + limited execution slots + candidate-space budget."""

    def __init__(self, config: AdmissionConfig) -> None:
        self._cfg = config
        self._cond = threading.Condition()
        self._running = 0
        self._queued = 0
        self._reserved = 0

    @property
    def stats(self) -> dict[str, int]:
        with self._cond:
            return {
                "running": self._running,
                "queued": self._queued,
                "reserved_bytes": self._reserved,
                "max_slots": self._cfg.max_slots,
                "max_queue": self._cfg.max_queue,
                "candidate_space_bytes": self._cfg.candidate_space_bytes,
            }

    def acquire(self, cost_bytes: int = 0, timeout: Optional[float] = None):
        deadline = None if timeout is None else time.monotonic() + timeout
        with self._cond:
            if cost_bytes > self._cfg.candidate_space_bytes:
                raise ResourceExhaustedError(
                    "request exceeds the total candidate-space budget",
                    stage=ErrorStage.ADMISSION,
                    retryable=False,
                )
            # Fast path: admit immediately without occupying a queue slot, so
            # max_queue bounds only waiters (section 5.8 bounded queue).
            if (
                self._running < self._cfg.max_slots
                and self._reserved + cost_bytes <= self._cfg.candidate_space_bytes
            ):
                self._running += 1
                self._reserved += cost_bytes
                return AdmissionLease(self, cost_bytes)
            if self._queued >= self._cfg.max_queue:
                raise ResourceExhaustedError(
                    "admission queue full", stage=ErrorStage.ADMISSION
                )
            self._queued += 1
            admitted = False
            try:
                while True:
                    if deadline is None:
                        self._cond.wait()
                    else:
                        remaining = deadline - time.monotonic()
                        if remaining <= 0:
                            raise ResourceExhaustedError(
                                "admission wait timed out",
                                stage=ErrorStage.ADMISSION,
                            )
                        self._cond.wait(remaining)
                    if (
                        self._running < self._cfg.max_slots
                        and self._reserved + cost_bytes
                        <= self._cfg.candidate_space_bytes
                    ):
                        self._queued -= 1
                        self._running += 1
                        self._reserved += cost_bytes
                        admitted = True
                        return AdmissionLease(self, cost_bytes)
            finally:
                if not admitted:
                    self._queued -= 1
                    self._cond.notify_all()

    def _release(self, cost_bytes: int) -> None:
        with self._cond:
            self._running = max(0, self._running - 1)
            self._reserved = max(0, self._reserved - cost_bytes)
            self._cond.notify_all()


class _Job:
    def __init__(self, job_id: str) -> None:
        self.job_id = job_id
        self._lock = threading.Lock()
        self._status = JobStatus.QUEUED
        self._phase = "queued"
        self._error: Optional[dict] = None
        self._result: Any = None
        self._done = threading.Event()
        self._cancel = threading.Event()

    def snapshot(self) -> JobSnapshot:
        with self._lock:
            return JobSnapshot(
                self.job_id, self._status, self._phase, self._error, self._result
            )

    @property
    def status(self) -> JobStatus:
        with self._lock:
            return self._status

    def _set(
        self,
        status: JobStatus,
        phase: Optional[str] = None,
        error: Optional[dict] = None,
        result: Any = None,
        terminal: bool = False,
    ) -> None:
        with self._lock:
            self._status = status
            if phase is not None:
                self._phase = phase
            if error is not None:
                self._error = error
            if result is not None:
                self._result = result
        if terminal:
            self._done.set()


class JobHandle:
    """Caller-facing handle to a submitted job (section 2.4)."""

    def __init__(self, pool: "WorkerPool", job: _Job) -> None:
        self._pool = pool
        self._job = job
        self.job_id = job.job_id

    def get(self) -> JobSnapshot:
        return self._job.snapshot()

    @property
    def status(self) -> JobStatus:
        return self._job.status

    def wait(self, timeout: Optional[float] = None) -> JobSnapshot:
        """Block until terminal or timeout; only ends the wait, not the job."""
        limit = self._pool.timeouts.job_wait_seconds if timeout is None else timeout
        self._job._done.wait(timeout=limit)
        return self._job.snapshot()

    def cancel(self) -> JobStatus:
        return self._pool.cancel(self.job_id)


class WorkerPool:
    """Bounded thread pool driving JobHandles behind an AdmissionController."""

    def __init__(self, admission: AdmissionConfig, timeouts: TimeoutConfig) -> None:
        self._local = threading.local()
        self._admission = AdmissionController(admission)
        self.timeouts = timeouts
        self._executor = ThreadPoolExecutor(
            max_workers=admission.max_slots, thread_name_prefix="zkg"
        )
        self._jobs: dict[str, _Job] = {}
        self._lock = threading.RLock()
        self._counter = itertools.count(1)
        self._closed = False
        self._pending = 0
        self._capacity = admission.max_slots + admission.max_queue

    def admission_stats(self) -> dict[str, int]:
        return self._admission.stats

    def reserve_current(self, cost_bytes: int) -> None:
        lease = getattr(self._local, "lease", None)
        if lease is not None:
            lease.grow_to(cost_bytes)

    def submit(
        self,
        op: Callable[[threading.Event], Any],
        *,
        kind: str = "task",
        cost_bytes: int = 0,
        phase: str = "run",
    ) -> JobHandle:
        with self._lock:
            if self._closed:
                raise KnowledgeGraphError(
                    "worker pool is closed",
                    stage=ErrorStage.ADMISSION,
                    retryable=False,
                )
            job_id = f"job-{next(self._counter)}"
            job = _Job(job_id)
            self._jobs[job_id] = job
            if self._pending >= self._capacity:
                error = ResourceExhaustedError("worker queue full")
                job._set(
                    JobStatus.FAILED,
                    phase="admission",
                    error=error.to_dict(),
                    terminal=True,
                )
            else:
                self._pending += 1
                self._executor.submit(self._dispatch, job, op, kind, cost_bytes, phase)
        return JobHandle(self, job)

    def _dispatch(self, *args) -> None:
        try:
            self._run(*args)
        finally:
            with self._lock:
                self._pending -= 1

    def _run(
        self,
        job: _Job,
        op: Callable[[threading.Event], Any],
        kind: str,
        cost_bytes: int,
        phase: str,
    ) -> None:
        try:
            lease = self._admission.acquire(
                cost_bytes, timeout=self.timeouts.admission_wait_seconds
            )
        except ResourceExhaustedError as exc:
            job._set(
                JobStatus.FAILED,
                phase="admission",
                error=exc.to_dict(),
                terminal=True,
            )
            return
        with lease:
            if job._cancel.is_set():
                job._set(JobStatus.CANCELLED, phase="cancelled", terminal=True)
                return
            job._set(JobStatus.RUNNING, phase=phase)
            try:
                self._local.lease = lease
                result = op(job._cancel)
            except OperationCancelledError:
                job._set(JobStatus.CANCELLED, phase="cancelled", terminal=True)
                return
            except RecoveryRequiredError as exc:
                job._set(
                    JobStatus.RECOVERY_REQUIRED,
                    phase="failed",
                    error=exc.to_dict(),
                    terminal=True,
                )
                return
            except KnowledgeGraphError as exc:
                job._set(
                    JobStatus.FAILED,
                    phase="failed",
                    error=exc.to_dict(),
                    terminal=True,
                )
                return
            except Exception:  # noqa: BLE001 - record unexpected failure
                job._set(
                    JobStatus.FAILED,
                    phase="failed",
                    error={"code": "unexpected", "message": "task execution failed"},
                    terminal=True,
                )
                return
            finally:
                self._local.lease = None
            if isinstance(result, _CommittedResult):
                job._set(
                    JobStatus.COMPLETED,
                    phase="done",
                    result=result.value,
                    terminal=True,
                )
            elif job._cancel.is_set():
                job._set(JobStatus.CANCELLED, phase="cancelled", terminal=True)
            else:
                job._set(
                    JobStatus.COMPLETED, phase="done", result=result, terminal=True
                )

    def cancel(self, job_id: str) -> JobStatus:
        with self._lock:
            job = self._jobs.get(job_id)
        if job is None:
            raise KeyError(job_id)
        with job._lock:
            if job._status in TERMINAL_STATUSES:
                return job._status
            job._cancel.set()
            job._status = JobStatus.CANCEL_REQUESTED
            return job._status

    def shutdown(self, *, drain: bool = True, timeout: Optional[float] = None):
        """Stop accepting work; drain or cancel at a safe boundary."""
        with self._lock:
            self._closed = True
            jobs = list(self._jobs.values())
        if not drain:
            for job in jobs:
                with job._lock:
                    if job._status not in TERMINAL_STATUSES:
                        job._cancel.set()
                        job._status = JobStatus.CANCEL_REQUESTED
        # ThreadPoolExecutor.shutdown does not take a timeout; wait=drain.
        self._executor.shutdown(wait=drain, cancel_futures=not drain)
