"""Typed publication control fields, versioned payload, immutable JSON artifacts."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from ._persistence import atomic_bytes, sync_directory
from .errors import IncompleteInitError, InvalidInputError, NotFoundError, StorageError

TABLES = (
    "KGBuild",
    "KGBuildAttempt",
    "KGStageArtifact",
    "KGProjection",
    "KGSegment",
    "KGPublication",
    "KGPublicationReceipt",
    "KGSourceSelection",
    "KGPublicationView",
)
DDL = tuple(
    f"CREATE NODE TABLE {table}(id STRING PRIMARY KEY, owner STRING, "
    "revision_id STRING, build_id STRING, state STRING, version INT64, payload STRING)"
    for table in TABLES
)


def fetch(conn, table, ident):
    if table not in TABLES:
        raise InvalidInputError("unknown publication record")
    rows = conn.execute(
        f"MATCH (n:{table}) WHERE n.id=$id RETURN n.payload", {"id": ident}
    ).fetchall()
    return json.loads(rows[0][0]) if rows else None


def put(conn, table, ident, value, *, owner="", state="", version=0):
    if table not in TABLES:
        raise InvalidInputError("unknown publication record")
    params = {
        "id": ident,
        "owner": owner,
        "revision_id": value.get("revision_id", ""),
        "build_id": value.get("build_id", ""),
        "state": state,
        "version": version,
        "payload": json.dumps(
            value,
            sort_keys=True,
            ensure_ascii=False,
            separators=(",", ":"),
            allow_nan=False,
        ),
    }
    if fetch(conn, table, ident) is None:
        conn.execute(
            f"CREATE (:{table} {{id:$id,owner:$owner,revision_id:$revision_id,build_id:$build_id,state:$state,version:$version,payload:$payload}})",
            params,
        )
    else:
        conn.execute(
            f"MATCH (n:{table}) WHERE n.id=$id SET n.owner=$owner,n.revision_id=$revision_id,n.build_id=$build_id,n.state=$state,n.version=$version,n.payload=$payload",
            params,
        )


def immutable(conn, table, ident, value, **kwargs):
    existing = fetch(conn, table, ident)
    if existing is not None:
        if existing != value:
            raise StorageError("immutable publication record mismatch", retryable=False)
    else:
        put(conn, table, ident, value, **kwargs)


class PublicationStore:
    def __init__(self, graph):
        self.graph = graph

    def initialize(self):
        self.graph.initialize_schema(DDL)
        self.graph.write_txn(
            lambda c: put(
                c,
                "KGPublicationView",
                "current",
                {
                    "version": 0,
                    "generation": "",
                    "space_id": "",
                    "layout": "documents-v1",
                },
                version=0,
            )
        )

    def validate(self):
        try:
            for table in TABLES:
                self.graph.read(
                    f"MATCH (n:{table}) RETURN n.id,n.owner,n.revision_id,n.build_id,n.state,n.version,n.payload LIMIT 0"
                )
            view = self.get("KGPublicationView", "current")
            if view is None or view.get("layout") != "documents-v1":
                raise ValueError("missing publication layout")
        except Exception as exc:
            raise IncompleteInitError(
                "document tables are incomplete; development databases must be explicitly rebuilt"
            ) from exc

    def get(self, table, ident):
        with self.graph.read_txn() as conn:
            return fetch(conn, table, ident)

    def required(self, table, ident):
        value = self.get(table, ident)
        if value is None:
            raise NotFoundError("build/publication record not found")
        return value

    def page(self, table, owner, limit=100, cursor=None):
        if (
            table not in TABLES
            or type(limit) is not int
            or not 1 <= limit <= 1000
            or (cursor is not None and not isinstance(cursor, str))
        ):
            raise InvalidInputError("invalid publication page")
        with self.graph.read_txn() as conn:
            rows = conn.execute(
                f"MATCH (n:{table}) WHERE n.owner=$owner AND n.id>$cursor RETURN n.id,n.payload ORDER BY n.id LIMIT {limit + 1}",
                {"owner": owner, "cursor": cursor or ""},
            ).fetchall()
        return tuple(json.loads(row[1]) for row in rows[:limit]), rows[limit - 1][
            0
        ] if len(rows) > limit else None


class ArtifactStore:
    """Content-addressed framework JSON; no untrusted path or automatic GC."""

    def __init__(self, root: Path):
        self.root = root

    def put(self, value):
        data = json.dumps(
            value,
            sort_keys=True,
            ensure_ascii=False,
            separators=(",", ":"),
            allow_nan=False,
        ).encode()
        ident = hashlib.sha256(data).hexdigest()
        path = self.root / (ident + ".json")
        if path.exists():
            if path.read_bytes() != data:
                raise StorageError("artifact content collision", retryable=False)
        else:
            if not self.root.exists():
                self.root.mkdir(parents=True, exist_ok=True)
                sync_directory(self.root.parent)
            atomic_bytes(path, data)
        return ident

    def get(self, ident):
        if (
            not isinstance(ident, str)
            or len(ident) != 64
            or any(c not in "0123456789abcdef" for c in ident)
        ):
            raise StorageError("invalid artifact id", retryable=False)
        try:
            data = (self.root / (ident + ".json")).read_bytes()
            if hashlib.sha256(data).hexdigest() != ident:
                raise ValueError("digest mismatch")
            return json.loads(data)
        except (OSError, ValueError) as exc:
            raise StorageError("artifact missing or corrupt", retryable=False) from exc
