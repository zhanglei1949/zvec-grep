"""Unified error model (design doc section 7.4), Phase 1 subset.

Every error carries a stable machine-readable ``code``, the ``stage`` where it
occurred (mirroring the job phases of section 5.4), and whether the operation
is ``retryable``. The CLI exit-code mapping and the full exception taxonomy are
frozen in detailed design; Phase 1 only needs the categories exercised by
create/open/close, admission and the storage adapters.
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Optional


class ErrorStage(str, Enum):
    """Where an error occurred; aligns with job phases (section 5.4)."""

    CREATE = "create"
    OPEN = "open"
    CLOSE = "close"
    ADMISSION = "admission"
    SNAPSHOT = "snapshot"
    PARSE = "parse"
    MODEL = "model"
    GRAPH_WRITE = "graph_write"
    INDEX = "index"
    PUBLISH = "publish"
    QUERY = "query"
    UNKNOWN = "unknown"


class KnowledgeGraphError(Exception):
    """Base class for all zknowledge errors.

    Subclasses override ``code``/``default_stage``/``default_retryable`` so that
    the same underlying failure surfaces with a consistent classification across
    interfaces (section 7.4). ``to_dict`` is the machine-readable form reused by
    the future CLI ``--json`` error body.
    """

    code = "knowledge_graph_error"
    default_stage = ErrorStage.UNKNOWN
    default_retryable = False

    def __init__(
        self,
        message: str,
        *,
        stage: Optional[ErrorStage] = None,
        retryable: Optional[bool] = None,
        cause: Optional[BaseException] = None,
        detail: Optional[dict[str, Any]] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.stage = stage if stage is not None else self.default_stage
        self.retryable = self.default_retryable if retryable is None else retryable
        self.detail = detail or {}
        if cause is not None:
            self.__cause__ = cause

    def to_dict(self) -> dict[str, Any]:
        stage = self.stage
        return {
            "code": self.code,
            "message": self.message,
            "stage": stage.value if isinstance(stage, ErrorStage) else str(stage),
            "retryable": self.retryable,
            "detail": self.detail,
        }

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return f"{type(self).__name__}({self.code!r}, stage={self.stage!r})"


class StorageError(KnowledgeGraphError):
    """A backing store (graphdb/zvec/snapshot) reported a failure."""

    code = "storage_error"
    default_retryable = True


class InvalidInputError(KnowledgeGraphError):
    code = "invalid_input"
    default_stage = ErrorStage.PARSE


class SourceConflictError(KnowledgeGraphError):
    code = "source_conflict"
    default_stage = ErrorStage.GRAPH_WRITE
    default_retryable = True


class NotFoundError(KnowledgeGraphError):
    code = "not_found"


class InputExcludedError(InvalidInputError):
    code = "input_excluded"
    default_stage = ErrorStage.SNAPSHOT


class OperationCancelledError(KnowledgeGraphError):
    code = "operation_cancelled"


class ProviderError(KnowledgeGraphError):
    code = "provider_error"
    default_stage = ErrorStage.PARSE


class IncompatibleFormatError(KnowledgeGraphError):
    """On-disk format/schema version is outside the readable compat matrix."""

    code = "incompatible_format"
    default_stage = ErrorStage.OPEN


class IdentityMismatchError(KnowledgeGraphError):
    """A store directory belongs to another KB identity or generation."""

    code = "identity_mismatch"
    default_stage = ErrorStage.OPEN


class IncompleteInitError(KnowledgeGraphError):
    """A previous create was interrupted; explicit recovery is required."""

    code = "incomplete_init"
    default_stage = ErrorStage.OPEN


class RecoveryRequiredError(KnowledgeGraphError):
    """Commit outcome unknown / instance must be reconciled before reuse."""

    code = "recovery_required"
    default_stage = ErrorStage.PUBLISH


class ResourceExhaustedError(KnowledgeGraphError):
    """Admission rejected: queue/slots full or candidate space exhausted."""

    code = "resource_exhausted"
    default_stage = ErrorStage.ADMISSION
    default_retryable = True


class OccupiedError(KnowledgeGraphError):
    """The KB is already held by a writable process (single-writer rule)."""

    code = "occupied"
    default_stage = ErrorStage.OPEN
    default_retryable = True


class CapabilityNotConfiguredError(KnowledgeGraphError):
    """A required capability has no configured provider."""

    code = "capability_not_configured"


class CapabilityNotReadyError(KnowledgeGraphError):
    """A configured capability is not currently ready/healthy."""

    code = "capability_not_ready"
    default_retryable = True
