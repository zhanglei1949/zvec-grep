"""Development preflight: prove we run on the Spike-0 built wheels.

Phase 1 must reuse the native wheels built by ``spikes/spike_0/build.py`` and
never rebuild them. This module reuses the provenance idea from ``run.py``: it
checks that the installed distribution's wheel hash matches the Spike-0 build
receipt, that the receipt passed, and that the expected source variants are in
place (graphdb ``libcxx-csv-fallback``, zvec ``unmodified``). Integration tests
use it to skip with a clear hint instead of failing on a missing/mismatched
base.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

# dependencies.json name -> installed distribution name
_DIST_NAME = {
    "graphdb": "graphdb",
    "zvec": "zvec",
    "py-tree-sitter": "tree-sitter",
    "tree-sitter-python": "tree-sitter-python",
    "tree-sitter-cpp": "tree-sitter-cpp",
}

_EXPECTED_VARIANT = {
    "graphdb": "libcxx-csv-fallback",
    "zvec": "unmodified",
}

PHASE1_BASES = ("graphdb", "zvec")


@dataclass
class PreflightReport:
    ok: bool
    entries: dict[str, dict] = field(default_factory=dict)

    def reason(self) -> str:
        bad = {k: v.get("reason") for k, v in self.entries.items() if not v.get("ok")}
        return "; ".join(f"{k}: {v}" for k, v in bad.items()) if bad else ""


def _repo_root(explicit: Optional[Path]) -> Path:
    return Path(explicit) if explicit else Path(__file__).resolve().parent.parent


def _installed_wheel_sha(dist_name: str) -> Optional[str]:
    try:
        import importlib.metadata as md
    except ImportError:  # pragma: no cover
        return None
    try:
        dist = md.distribution(dist_name)
    except Exception:
        return None
    try:
        direct = json.loads(dist.read_text("direct_url.json") or "{}")
    except Exception:
        return None
    return direct.get("archive_info", {}).get("hashes", {}).get("sha256")


def check_base_provenance(
    repo_root: Optional[Path] = None, names: tuple[str, ...] = PHASE1_BASES
) -> PreflightReport:
    root = _repo_root(repo_root)
    build_dir = root / ".artifacts" / "spike-0" / "build"
    entries: dict[str, dict] = {}
    for name in names:
        entry: dict = {"name": name, "ok": False}
        receipt_path = build_dir / f"{name}.json"
        if not receipt_path.exists():
            entry["reason"] = f"no Spike-0 build receipt at {receipt_path}"
            entries[name] = entry
            continue
        try:
            receipt = json.loads(receipt_path.read_text())
        except ValueError as exc:
            entry["reason"] = f"unreadable receipt: {exc}"
            entries[name] = entry
            continue
        if receipt.get("status") != "passed":
            entry["reason"] = f"receipt status={receipt.get('status')!r}"
            entries[name] = entry
            continue
        wheel_sha = receipt.get("wheel_sha256")
        installed = _installed_wheel_sha(_DIST_NAME[name])
        if installed is None:
            entry["reason"] = "distribution not installed in this environment"
            entries[name] = entry
            continue
        if installed != wheel_sha:
            entry["reason"] = "installed wheel hash != Spike-0 receipt hash"
            entries[name] = entry
            continue
        variant = receipt.get("source_variant", "unmodified")
        expected = _EXPECTED_VARIANT.get(name)
        if expected and variant != expected:
            entry["reason"] = f"source_variant={variant!r}, expected {expected!r}"
            entries[name] = entry
            continue
        entry.update(ok=True, source_variant=variant, wheel_sha256=wheel_sha)
        entries[name] = entry
    return PreflightReport(ok=all(e["ok"] for e in entries.values()), entries=entries)


def base_import_error() -> Optional[str]:
    """Return a message if graphdb/zvec cannot be imported, else None."""
    try:
        import graphdb  # noqa: F401
        import zvec  # noqa: F401
    except Exception as exc:
        return f"{type(exc).__name__}: {exc}"
    return None
