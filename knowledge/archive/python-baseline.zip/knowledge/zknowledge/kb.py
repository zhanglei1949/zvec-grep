"""KnowledgeBase handle: create / open / close lifecycle (design sections 7, 8.2).

The handle owns this process's store connections, the worker pool and the read
references. It is thread-safe within its process: queries run concurrently,
while the maintenance write path is serialised through an in-process publish
coordinator lock (section 2.4 / 5.3). The single-writable-holder rule is
enforced with an advisory lock file at ``<root>/lock`` (graphdb's same-directory
one-writer constraint is the hard backstop). Adapters and raw Cypher are never
exposed on the public surface.
"""

from __future__ import annotations

import json
import os
import socket
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Callable, Optional

from .adapters import GraphStoreAdapter, SearchIndexAdapter, SnapshotStore
from .build_models import BuildConfig
from .builds import Builds, Publications
from .config import KnowledgeBaseConfig
from .errors import (
    ErrorStage,
    IncompleteInitError,
    KnowledgeGraphError,
    OccupiedError,
    StorageError,
)
from .execution import JobHandle, WorkerPool
from .index_catalog import IndexCatalog
from .manifest import (
    KnowledgeBaseManifest,
    StoreRef,
    mark_ready,
    new_manifest,
    read_manifest,
    validate_store_ownership,
    write_manifest,
    write_store_marker,
)
from .models import CaptureConfig, DocumentInput
from .publication_store import PublicationStore
from .source_store import SourceStore
from .sources import Ingestions, Sources

_LOCK_NAME = "lock"


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def _acquire_lock(root: Path) -> dict:
    """Atomically take the single-writer lock; reject a live holder."""
    lock_path = root / _LOCK_NAME
    token = {
        "pid": os.getpid(),
        "host": socket.gethostname(),
        "ts": time.time(),
    }

    def _write() -> dict:
        fd = os.open(str(lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        with os.fdopen(fd, "w") as handle:
            json.dump(token, handle)
        return token

    try:
        return _write()
    except FileExistsError:
        pass
    holder: Optional[dict] = None
    try:
        holder = json.loads(lock_path.read_text())
    except (OSError, ValueError):
        holder = None
    same_host = bool(holder) and holder.get("host") == token["host"]
    stale = bool(holder) and same_host and not _pid_alive(int(holder.get("pid", -1)))
    if holder and not stale:
        raise OccupiedError(
            f"KB at {root} is already held by a writable process "
            f"(pid={holder.get('pid')}, host={holder.get('host')})"
        )
    # Stale or unreadable lock from a dead local holder: clear and retry once.
    try:
        lock_path.unlink()
    except FileNotFoundError:
        pass
    try:
        return _write()
    except FileExistsError as exc:
        raise OccupiedError(f"KB at {root} became occupied during open") from exc


def _release_lock(root: Path, token: dict) -> None:
    lock_path = root / _LOCK_NAME
    try:
        holder = json.loads(lock_path.read_text())
    except (OSError, ValueError):
        holder = None
    if holder and holder.get("pid") == token.get("pid"):
        try:
            lock_path.unlink()
        except FileNotFoundError:
            pass


class KnowledgeBase:
    """Process-local handle to one knowledge base."""

    def __init__(
        self,
        root: Path,
        manifest: KnowledgeBaseManifest,
        config: KnowledgeBaseConfig,
        *,
        read_only: bool,
        graph: GraphStoreAdapter,
        index: SearchIndexAdapter,
        snapshots: SnapshotStore,
        pool: WorkerPool,
        lock_token: Optional[dict],
    ) -> None:
        self._root = root
        self._manifest = manifest
        self._config = config
        self._read_only = read_only
        self._graph = graph
        self._index = index
        self._snapshots = snapshots
        self._pool = pool
        self._lock_token = lock_token
        self._lock = threading.RLock()
        self._publish_lock = index._lock
        self._closed = False
        self._closing = False
        self._close_lock = threading.Lock()
        self.sources = Sources(self)
        self.ingestions = Ingestions(self)
        self.builds = Builds(self)
        self.publications = Publications(self)

    # -- construction ----------------------------------------------------
    @classmethod
    def create(
        cls,
        root: Path | str,
        config: Optional[KnowledgeBaseConfig] = None,
        *,
        base_compat: Any = None,
    ) -> "KnowledgeBase":
        root = Path(root)
        config = config or KnowledgeBaseConfig.default()
        if root.exists() and any(root.iterdir()):
            raise KnowledgeGraphError(
                f"create refuses to overwrite non-empty directory: {root}",
                stage=ErrorStage.CREATE,
                retryable=False,
            )
        root.mkdir(parents=True, exist_ok=True)
        # 1) record initialization intent (ready=False) before touching stores.
        manifest = new_manifest(base_compat)
        write_manifest(root, manifest)
        try:
            (root / "stores").mkdir(parents=True, exist_ok=True)
            for ref in manifest.stores:
                # zvec.create_and_open (Phase 3) requires the index path to be
                # absent, so do not pre-create it; graphdb/snapshots are ours.
                if ref.kind != "index":
                    (root / ref.relpath).mkdir(parents=True, exist_ok=True)
                state = (
                    {
                        "collection_created": False,
                        "layout": "documents-v1",
                        "collections": {},
                    }
                    if ref.kind == "index"
                    else None
                )
                write_store_marker(root, ref, manifest, state=state)
            # 2) initialise Phase 2 schema outside ordinary TP data transactions.
            probe = GraphStoreAdapter(
                root / manifest.store("graphdb").relpath,
                read_only=False,
                config=config.store,
            )
            probe.open()
            try:
                SourceStore(probe).initialize(manifest)
                PublicationStore(probe).initialize()
            finally:
                probe.close()
            # 3) flip ready only after every store is initialised.
            manifest = mark_ready(root, manifest)
        except BaseException:
            # Leave ready=False so the next open reports IncompleteInitError;
            # never silently clear a partial create.
            raise
        # create() yields a writable handle, so it must hold the single-writer
        # lock exactly like open(read_only=False).
        lock_token = _acquire_lock(root)
        try:
            return cls._open(
                root, manifest, config, read_only=False, lock_token=lock_token
            )
        except BaseException:
            _release_lock(root, lock_token)
            raise

    @classmethod
    def open(
        cls,
        root: Path | str,
        *,
        read_only: bool = False,
        config: Optional[KnowledgeBaseConfig] = None,
    ) -> "KnowledgeBase":
        root = Path(root)
        config = config or KnowledgeBaseConfig.default()
        manifest = read_manifest(root)  # format-compat check inside
        if not manifest.ready:
            raise IncompleteInitError(
                f"KB at {root} has an incomplete create; explicit recovery "
                "is required (re-create is refused to avoid clearing residue)"
            )
        validate_store_ownership(root, manifest)
        lock_token = None if read_only else _acquire_lock(root)
        try:
            return cls._open(
                root, manifest, config, read_only=read_only, lock_token=lock_token
            )
        except BaseException:
            if lock_token is not None:
                _release_lock(root, lock_token)
            raise

    @classmethod
    def _open(
        cls,
        root: Path,
        manifest: KnowledgeBaseManifest,
        config: KnowledgeBaseConfig,
        *,
        read_only: bool,
        lock_token: Optional[dict] = None,
    ) -> "KnowledgeBase":
        graph_ref: StoreRef = manifest.store("graphdb")
        index_ref: StoreRef = manifest.store("index")
        snap_ref: StoreRef = manifest.store("snapshots")
        graph = GraphStoreAdapter(
            root / graph_ref.relpath,
            read_only=read_only,
            config=config.store,
            cleanup_reserve=config.admission.max_slots + 2,
        ).open()
        index = None
        try:
            SourceStore(graph).validate(manifest)
            PublicationStore(graph).validate()
            index = IndexCatalog(
                root,
                root / index_ref.relpath,
                read_only=read_only,
                config=config.store,
                lock=threading.RLock(),
                read_copy_budget_bytes=config.admission.candidate_space_bytes,
            )
            snapshots = SnapshotStore(root / snap_ref.relpath)
            pool = WorkerPool(config.admission, config.timeouts)
        except BaseException:
            if index is not None:
                index.close()
            graph.close()
            raise
        return cls(
            root,
            manifest,
            config,
            read_only=read_only,
            graph=graph,
            index=index,
            snapshots=snapshots,
            pool=pool,
            lock_token=lock_token,
        )

    # -- properties ------------------------------------------------------
    @property
    def root(self) -> Path:
        return self._root

    @property
    def read_only(self) -> bool:
        return self._read_only

    @property
    def manifest(self) -> KnowledgeBaseManifest:
        return self._manifest

    @property
    def closed(self) -> bool:
        return self._closed

    # -- capabilities / health (section 7) -------------------------------
    def capabilities(self) -> dict[str, Any]:
        self._require_open()
        return {
            "read_only": self._read_only,
            "graph": self._graph.capabilities(),
            "index": self._index.capabilities(),
            "snapshot": {"immutable_text": True},
            # Embedding providers are configured in Phase 3.
            "embedding": {
                "configured": False,
                "configuration_scope": "per_build",
                "precomputed": True,
            },
            "documents": {
                "capture": True,
                "structural_parse": True,
                "knowledge_extraction": False,
                "search_ready": False,
            },
            "builds": {"documents": True, "precomputed_embedding": True},
            "search_api_available": False,
        }

    def health(self) -> dict[str, Any]:
        self._require_open()
        return {
            "closed": self._closed,
            "read_only": self._read_only,
            "graph": self._graph.health(),
            "index": self._index.health(),
            "builds": self.builds.health(),
        }

    # -- admission / jobs (sections 2.4, 5.8) ----------------------------
    def admission_stats(self) -> dict[str, int]:
        self._require_open()
        return self._pool.admission_stats()

    def submit(
        self,
        op: Callable[[threading.Event], Any],
        *,
        kind: str = "task",
        cost_bytes: int = 0,
        phase: str = "run",
    ) -> JobHandle:
        with self._lock:
            self._require_writable()
            return self._pool.submit(op, kind=kind, cost_bytes=cost_bytes, phase=phase)

    def ingest_documents(
        self,
        source_id: str,
        document: DocumentInput,
        *,
        operation_id: str | None = None,
        capture: CaptureConfig | None = None,
    ) -> JobHandle:
        return self.sources.submit(
            source_id, document, operation_id=operation_id, capture=capture
        )

    @contextmanager
    def publish_critical_section(self):
        """In-process short critical section for the write/publish path."""
        with self._publish_lock:
            self._require_writable()
            yield

    def build_documents(
        self,
        revision_id: str,
        *,
        config: BuildConfig | None = None,
        operation_id: str | None = None,
    ) -> JobHandle:
        return self.builds.submit(revision_id, config=config, operation_id=operation_id)

    # -- lifecycle -------------------------------------------------------
    def close(self) -> None:
        with self._close_lock:
            with self._lock:
                if self._closed:
                    return
                self._closing = True
            # Accepted workers do not need the public lifecycle guard to finish.
            try:
                self._pool.shutdown(drain=True)
            finally:
                with self._publish_lock:
                    try:
                        self._graph.close()
                    finally:
                        try:
                            self._index.close()
                        finally:
                            try:
                                self._snapshots.close()
                            finally:
                                if self._lock_token is not None:
                                    _release_lock(self._root, self._lock_token)
                                    self._lock_token = None
                                self._closed = True

    def __enter__(self) -> "KnowledgeBase":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    def _require_open(self) -> None:
        if self._closed or self._closing:
            raise KnowledgeGraphError(
                "knowledge base is closed",
                stage=ErrorStage.UNKNOWN,
                retryable=False,
            )

    def _require_writable(self) -> None:
        self._require_open()
        self._graph.require_usable()
        if self._read_only:
            raise StorageError(
                "maintenance on a read-only KB",
                stage=ErrorStage.ADMISSION,
                retryable=False,
            )
