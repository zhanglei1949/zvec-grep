"""Replaceable document-processing contracts; no parser/model implementation.

Adapters return framework values only. Helpers validate structure and locations,
not the truth, completeness or semantic quality of extracted propositions.
"""

from __future__ import annotations

import hashlib
import json
import threading
import time
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Mapping, Protocol, Sequence, runtime_checkable

from .errors import InvalidInputError, OperationCancelledError, ProviderError
from .models import CaptureConfig, require_text


def _freeze(value):
    if isinstance(value, Mapping):
        result = {}
        for key, item in value.items():
            if not isinstance(key, str):
                raise InvalidInputError("configuration keys must be strings")
            if key.lower() in {
                "password",
                "secret",
                "api_key",
                "apikey",
                "token",
                "access_token",
                "credential",
                "credentials",
                "authorization",
            }:
                raise InvalidInputError(
                    "credentials must not enter processing descriptors"
                )
            result[key] = _freeze(item)
        return MappingProxyType(result)
    if isinstance(value, (tuple, list)):
        return tuple(_freeze(x) for x in value)
    if value is None or type(value) in (str, int, bool):
        return value
    if type(value) is float and value == value and abs(value) != float("inf"):
        return value
    raise InvalidInputError("configuration must contain finite JSON values")


def _json_value(value):
    if isinstance(value, Mapping):
        return {k: _json_value(v) for k, v in value.items()}
    if isinstance(value, tuple):
        return [_json_value(v) for v in value]
    return value


def stable_digest(value) -> str:
    return hashlib.sha256(
        json.dumps(
            _json_value(value),
            sort_keys=True,
            ensure_ascii=False,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
    ).hexdigest()


@dataclass(frozen=True)
class ParserDescriptor:
    implementation: str
    version: str
    contract_version: str = "1"
    supported_formats: tuple[str, ...] = ("text/markdown",)
    configuration: Mapping = field(default_factory=dict)

    def __post_init__(self):
        for value in (self.implementation, self.version, self.contract_version):
            require_text(value, "descriptor identifier")
        object.__setattr__(self, "configuration", _freeze(self.configuration))
        object.__setattr__(self, "supported_formats", tuple(self.supported_formats))


@dataclass(frozen=True)
class ExtractorDescriptor:
    implementation: str
    version: str
    contract_version: str = "1"
    capabilities: tuple[str, ...] = ("entities", "assertions", "evidence")
    configuration: Mapping = field(default_factory=dict)

    def __post_init__(self):
        for value in (self.implementation, self.version, self.contract_version):
            require_text(value, "descriptor identifier")
        object.__setattr__(self, "configuration", _freeze(self.configuration))
        object.__setattr__(self, "capabilities", tuple(self.capabilities))


@dataclass(frozen=True)
class StageFingerprint:
    stage: str
    digest: str


def processing_fingerprint(
    stage: str,
    descriptor: ParserDescriptor | ExtractorDescriptor,
    dependencies: Sequence[StageFingerprint] = (),
) -> StageFingerprint:
    if stage not in {"capture", "parse", "segment", "extract"}:
        raise InvalidInputError("unknown processing stage")
    capabilities = (
        descriptor.supported_formats
        if isinstance(descriptor, ParserDescriptor)
        else descriptor.capabilities
    )
    digest = stable_digest(
        {
            "stage": stage,
            "implementation": descriptor.implementation,
            "version": descriptor.version,
            "contract": descriptor.contract_version,
            "capabilities": capabilities,
            "configuration": descriptor.configuration,
            "dependencies": tuple((d.stage, d.digest) for d in dependencies),
        }
    )
    return StageFingerprint(stage, digest)


def capture_fingerprint(config: CaptureConfig) -> str:
    return processing_fingerprint(
        "capture",
        ParserDescriptor(
            "zknowledge.capture",
            config.processor_version,
            configuration={
                "encoding": "utf-8",
                "normalization": "none",
                "unit": "whole-document",
            },
        ),
    ).digest


@dataclass(frozen=True)
class SourceSnapshot:
    source_id: str
    revision_id: str
    snapshot_id: str
    data: bytes = field(repr=False)
    encoding: str = "utf-8"
    media_type: str = "text/markdown"

    def __post_init__(self):
        if not isinstance(self.data, bytes):
            raise InvalidInputError("snapshot requires immutable bytes")
        if hashlib.sha256(self.data).hexdigest() != self.snapshot_id:
            raise InvalidInputError("snapshot digest mismatch")
        if self.encoding != "utf-8":
            raise InvalidInputError("Phase 2 supports UTF-8 snapshots only")
        try:
            self.data.decode(self.encoding)
        except UnicodeError as exc:
            raise InvalidInputError("invalid UTF-8 snapshot") from exc

    def read(self, start: int = 0, end: int | None = None) -> bytes:
        end = len(self.data) if end is None else end
        if (
            type(start) is not int
            or type(end) is not int
            or not 0 <= start <= end <= len(self.data)
        ):
            raise InvalidInputError("invalid snapshot range")
        return self.data[start:end]


@dataclass(frozen=True)
class SourceSpan:
    revision_id: str
    snapshot_id: str
    start: int
    end: int


@dataclass(frozen=True)
class Diagnostic:
    code: str
    message: str
    item_id: str | None = None


@dataclass(frozen=True)
class DocumentBlock:
    local_id: str
    kind: str
    span: SourceSpan
    parent_id: str | None = None


@dataclass(frozen=True)
class ParsedDocument:
    revision_id: str
    blocks: tuple[DocumentBlock, ...]
    status: str = "complete"
    diagnostics: tuple[Diagnostic, ...] = ()


@dataclass(frozen=True)
class DocumentUnit:
    local_id: str
    snapshot: SourceSnapshot
    spans: tuple[SourceSpan, ...]

    def read(self) -> bytes:
        return b"".join(self.snapshot.read(s.start, s.end) for s in self.spans)


@dataclass(frozen=True)
class CandidateEntity:
    local_id: str
    name: str
    entity_type: str


@dataclass(frozen=True)
class EvidenceCandidate:
    span: SourceSpan
    quote: str


@dataclass(frozen=True)
class TypedValue:
    datatype: str
    value: str | int | float | bool | None


@dataclass(frozen=True)
class Qualifier:
    name: str
    value: TypedValue


@dataclass(frozen=True)
class CandidateAssertion:
    local_id: str
    subject_id: str
    predicate: str
    object_id: str | None = None
    value: TypedValue | None = None
    qualifiers: tuple[Qualifier, ...] = ()
    polarity: str = "positive"
    evidence: tuple[EvidenceCandidate, ...] = ()


@dataclass(frozen=True)
class ExtractionResult:
    entities: tuple[CandidateEntity, ...] = ()
    assertions: tuple[CandidateAssertion, ...] = ()
    status: str = "complete"
    diagnostics: tuple[Diagnostic, ...] = ()


@dataclass(frozen=True)
class ProcessingBudget:
    max_input_bytes: int
    max_output_items: int

    def __post_init__(self):
        if self.max_input_bytes < 0 or self.max_output_items < 0:
            raise InvalidInputError("processing budgets must be non-negative")


@dataclass(frozen=True)
class ParseContext:
    budget: ProcessingBudget
    cancel: threading.Event = field(default_factory=threading.Event)
    deadline: float | None = None  # monotonic deadline, not wall-clock time

    def check(self):
        if self.cancel.is_set():
            raise OperationCancelledError("processing cancelled")
        if self.deadline is not None and time.monotonic() >= self.deadline:
            raise ProviderError(
                "provider deadline exceeded", detail={"reason": "timeout"}
            )


@dataclass(frozen=True)
class ExtractionContext(ParseContext):
    allowed_entity_types: tuple[str, ...] = ()
    allowed_predicates: tuple[str, ...] = ()


@runtime_checkable
class DocumentParser(Protocol):
    def describe(self) -> ParserDescriptor: ...
    def parse(
        self, snapshot: SourceSnapshot, context: ParseContext
    ) -> ParsedDocument: ...


@runtime_checkable
class KnowledgeExtractor(Protocol):
    def describe(self) -> ExtractorDescriptor: ...
    def extract(
        self, units: Sequence[DocumentUnit], context: ExtractionContext
    ) -> ExtractionResult: ...


def _span(span: SourceSpan, snapshot: SourceSnapshot):
    if not isinstance(span, SourceSpan):
        raise ProviderError("provider returned a foreign position type")
    if (
        span.revision_id != snapshot.revision_id
        or span.snapshot_id != snapshot.snapshot_id
    ):
        raise ProviderError("provider position references another snapshot")
    try:
        snapshot.read(span.start, span.end)
        # Ranges used as text must not split UTF-8 characters.
        snapshot.data[: span.start].decode("utf-8")
        snapshot.data[span.start : span.end].decode("utf-8")
    except (InvalidInputError, UnicodeError) as exc:
        raise ProviderError("provider returned an invalid byte range") from exc


def _status(status: str, diagnostics: tuple):
    if not isinstance(status, str) or status not in {
        "complete",
        "partial",
        "truncated",
    }:
        raise ProviderError("invalid provider result status")
    if status != "complete" and not diagnostics:
        raise ProviderError("incomplete output requires diagnostics")
    if not isinstance(diagnostics, tuple) or any(
        not isinstance(d, Diagnostic) for d in diagnostics
    ):
        raise ProviderError("provider returned foreign diagnostics")


def _typed(value: TypedValue):
    if (
        not isinstance(value, TypedValue)
        or not isinstance(value.datatype, str)
        or not value.datatype
        or type(value.value) not in (str, int, float, bool, type(None))
    ):
        raise ProviderError("invalid typed value")
    if type(value.value) is float and (
        value.value != value.value or abs(value.value) == float("inf")
    ):
        raise ProviderError("non-finite typed value")


def parse_document(
    parser: DocumentParser, snapshot: SourceSnapshot, context: ParseContext
) -> ParsedDocument:
    """Synchronous contract helper; host owns scheduling and hard isolation."""
    context.check()
    descriptor = parser.describe()
    if not isinstance(descriptor, ParserDescriptor):
        raise ProviderError("parser descriptor type mismatch")
    if snapshot.media_type not in descriptor.supported_formats:
        raise ProviderError(
            "unsupported input format", detail={"reason": "unsupported"}
        )
    if len(snapshot.data) > context.budget.max_input_bytes:
        raise ProviderError("parser input budget exceeded")
    try:
        result = parser.parse(snapshot, context)
    except (ProviderError, OperationCancelledError):
        raise
    except Exception as exc:
        raise ProviderError("parser execution failed") from exc
    context.check()
    if (
        not isinstance(result, ParsedDocument)
        or result.revision_id != snapshot.revision_id
    ):
        raise ProviderError("parser output type or revision mismatch")
    _status(result.status, result.diagnostics)
    if not isinstance(result.blocks, tuple):
        raise ProviderError("parser blocks must be immutable framework values")
    if len(result.blocks) > context.budget.max_output_items:
        raise ProviderError("parser output budget exceeded")
    blocks = {}
    for block in result.blocks:
        if (
            not isinstance(block, DocumentBlock)
            or not isinstance(block.local_id, str)
            or not isinstance(block.kind, str)
            or not (block.parent_id is None or isinstance(block.parent_id, str))
            or not block.local_id
            or block.local_id in blocks
        ):
            raise ProviderError("invalid or duplicate block")
        _span(block.span, snapshot)
        blocks[block.local_id] = block
    for block in blocks.values():
        seen = {block.local_id}
        child = block
        while child.parent_id is not None:
            parent = blocks.get(child.parent_id)
            if parent is None or parent.local_id in seen:
                raise ProviderError("invalid block hierarchy")
            if (
                not parent.span.start
                <= child.span.start
                <= child.span.end
                <= parent.span.end
            ):
                raise ProviderError("child range escapes its parent")
            seen.add(parent.local_id)
            child = parent
    return result


def extract_knowledge(
    extractor: KnowledgeExtractor,
    units: Sequence[DocumentUnit],
    context: ExtractionContext,
) -> ExtractionResult:
    context.check()
    snapshots = {}
    size = 0
    for unit in units:
        if not isinstance(unit, DocumentUnit):
            raise ProviderError("extractor input must use framework units")
        for span in unit.spans:
            _span(span, unit.snapshot)
            size += span.end - span.start
        snapshots[(unit.snapshot.revision_id, unit.snapshot.snapshot_id)] = (
            unit.snapshot
        )
    if size > context.budget.max_input_bytes:
        raise ProviderError("extractor input budget exceeded")
    descriptor = extractor.describe()
    if not isinstance(descriptor, ExtractorDescriptor):
        raise ProviderError("extractor descriptor type mismatch")
    if not {"entities", "assertions", "evidence"} <= set(descriptor.capabilities):
        raise ProviderError("unsupported extraction capability")
    try:
        result = extractor.extract(tuple(units), context)
    except (ProviderError, OperationCancelledError):
        raise
    except Exception as exc:
        raise ProviderError("extractor execution failed") from exc
    context.check()
    if not isinstance(result, ExtractionResult):
        raise ProviderError("extractor output must use framework values")
    _status(result.status, result.diagnostics)
    if not isinstance(result.entities, tuple) or not isinstance(
        result.assertions, tuple
    ):
        raise ProviderError("extraction output must be immutable framework values")
    if len(result.entities) + len(result.assertions) > context.budget.max_output_items:
        raise ProviderError("extractor output budget exceeded")
    entities = {}
    for entity in result.entities:
        if (
            not isinstance(entity, CandidateEntity)
            or not isinstance(entity.local_id, str)
            or not isinstance(entity.name, str)
            or not entity.local_id
            or not entity.name
            or entity.local_id in entities
            or entity.entity_type not in context.allowed_entity_types
        ):
            raise ProviderError("invalid entity or undeclared entity type")
        entities[entity.local_id] = entity
    assertion_ids = set()
    for assertion in result.assertions:
        if (
            not isinstance(assertion, CandidateAssertion)
            or not isinstance(assertion.local_id, str)
            or not isinstance(assertion.subject_id, str)
            or not isinstance(assertion.predicate, str)
            or not isinstance(assertion.polarity, str)
            or not (assertion.object_id is None or isinstance(assertion.object_id, str))
            or not isinstance(assertion.evidence, tuple)
            or not isinstance(assertion.qualifiers, tuple)
            or not assertion.local_id
            or assertion.local_id in assertion_ids
            or assertion.subject_id not in entities
            or assertion.predicate not in context.allowed_predicates
            or assertion.polarity not in {"positive", "negative"}
            or not assertion.evidence
            or (assertion.object_id is None) == (assertion.value is None)
            or (assertion.object_id is not None and assertion.object_id not in entities)
        ):
            raise ProviderError("invalid assertion references or proposition")
        assertion_ids.add(assertion.local_id)
        if assertion.value is not None:
            _typed(assertion.value)
        qualifier_names = set()
        for qualifier in assertion.qualifiers:
            if (
                not isinstance(qualifier, Qualifier)
                or not isinstance(qualifier.name, str)
                or not qualifier.name
                or qualifier.name in qualifier_names
            ):
                raise ProviderError("invalid or duplicate qualifier")
            qualifier_names.add(qualifier.name)
            _typed(qualifier.value)
        for evidence in assertion.evidence:
            if not isinstance(evidence, EvidenceCandidate) or not isinstance(
                evidence.span, SourceSpan
            ):
                raise ProviderError("invalid evidence type")
            snapshot = snapshots.get(
                (evidence.span.revision_id, evidence.span.snapshot_id)
            )
            if snapshot is None:
                raise ProviderError("evidence references an unknown input")
            _span(evidence.span, snapshot)
            if not any(
                evidence.span.revision_id == u.snapshot.revision_id
                and evidence.span.snapshot_id == u.snapshot.snapshot_id
                and s.start <= evidence.span.start <= evidence.span.end <= s.end
                for u in units
                for s in u.spans
            ):
                raise ProviderError("evidence escapes submitted input units")
            if (
                not evidence.quote
                or snapshot.read(evidence.span.start, evidence.span.end).decode("utf-8")
                != evidence.quote
            ):
                raise ProviderError("evidence quote does not match snapshot")
    return result
