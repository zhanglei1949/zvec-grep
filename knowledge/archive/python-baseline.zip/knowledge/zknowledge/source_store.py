"""Internal source schema/repository. JSON payloads have versioned SDK types.

Stable id and owner/state columns support bounded-result inspections; graph relationships
express source -> revision -> unit. No arbitrary table/query enters the SDK API.
"""

from __future__ import annotations

import json
from dataclasses import asdict

from .errors import IncompleteInitError, InvalidInputError, NotFoundError

TABLES = (
    "KGSource",
    "KGRevision",
    "KGContentUnit",
    "KGIngestOperation",
    "KGIngestAttempt",
    "KGIngestReceipt",
    "KGMetadata",
)
DDL = tuple(
    f"CREATE NODE TABLE {t}(id STRING PRIMARY KEY, owner STRING, "
    "state STRING, payload STRING)"
    for t in TABLES
) + (
    "CREATE REL TABLE KG_HAS_REVISION(FROM KGSource TO KGRevision)",
    "CREATE REL TABLE KG_HAS_UNIT(FROM KGRevision TO KGContentUnit)",
)


def encode(value) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def fetch(conn, table: str, ident: str) -> dict | None:
    if table not in TABLES:
        raise InvalidInputError(f"unknown source-store table: {table}")
    rows = conn.execute(
        f"MATCH (n:{table}) WHERE n.id=$id RETURN n.payload", {"id": ident}
    ).fetchall()
    return json.loads(rows[0][0]) if rows else None


def put(
    conn, table: str, ident: str, payload: dict, *, owner: str = "", state: str = ""
):
    if table not in TABLES:
        raise InvalidInputError(f"unknown source-store table: {table}")
    params = {"id": ident, "owner": owner, "state": state, "payload": encode(payload)}
    if fetch(conn, table, ident) is None:
        conn.execute(
            f"CREATE (:{table} {{id:$id, owner:$owner, state:$state, payload:$payload}})",
            params,
        )
    else:
        conn.execute(
            f"MATCH (n:{table}) WHERE n.id=$id "
            "SET n.owner=$owner, n.state=$state, n.payload=$payload",
            params,
        )


def create_immutable(conn, table: str, value, *, owner: str) -> bool:
    payload = asdict(value)
    existing = fetch(conn, table, value.id)
    if existing is not None:
        if existing != payload:
            raise InvalidInputError("immutable graph record mismatch")
        return False
    put(conn, table, value.id, payload, owner=owner)
    return True


class SourceStore:
    def __init__(self, graph):
        self.graph = graph

    def initialize(self, manifest):
        self.graph.initialize_schema(DDL)
        self.graph.write_txn(
            lambda c: put(
                c,
                "KGMetadata",
                "identity",
                {
                    "kb_id": manifest.kb_id,
                    "schema_version": manifest.schema_version,
                    "storage_generation": manifest.storage_generation,
                },
            )
        )

    def validate(self, manifest):
        try:
            identity = self.get("KGMetadata", "identity")
        except Exception as exc:
            raise IncompleteInitError(
                "source schema is missing or incomplete; graphdb has no DROP, "
                "so a partially initialised graph cannot be repaired in place "
                "- recreate the KB directory"
            ) from exc
        if identity != {
            "kb_id": manifest.kb_id,
            "schema_version": manifest.schema_version,
            "storage_generation": manifest.storage_generation,
        }:
            raise IncompleteInitError("graph identity/schema does not match manifest")

    def get(self, table: str, ident: str) -> dict | None:
        if table not in TABLES:
            raise InvalidInputError(f"unknown source-store table: {table}")
        rows = self.graph.read(
            f"MATCH (n:{table}) WHERE n.id=$id RETURN n.payload", {"id": ident}
        )
        return json.loads(rows[0][0]) if rows else None

    def required(self, table: str, ident: str) -> dict:
        result = self.get(table, ident)
        if result is None:
            raise NotFoundError("record not found", detail={"kind": table})
        return result

    def page(self, table: str, owner: str, limit: int, cursor: str | None):
        if table not in TABLES:
            raise InvalidInputError(f"unknown source-store table: {table}")
        if type(limit) is not int or not 1 <= limit <= 1000:
            raise InvalidInputError("list limit must be between 1 and 1000")
        if cursor is not None and not isinstance(cursor, str):
            raise InvalidInputError("cursor must be an opaque string")
        rows = self.graph.read(
            f"MATCH (n:{table}) WHERE n.owner=$owner AND n.id>$cursor "
            f"RETURN n.id,n.payload ORDER BY n.id LIMIT {limit + 1}",
            {"owner": owner, "cursor": cursor or ""},
        )
        more = len(rows) > limit
        return tuple(json.loads(r[1]) for r in rows[:limit]), (
            rows[limit - 1][0] if more else None
        )
