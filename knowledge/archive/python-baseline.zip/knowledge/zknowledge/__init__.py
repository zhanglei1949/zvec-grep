"""z-knowledge-graph embedded SDK (document capture, builds and publication).

Phase 1 supplies lifecycle/admission; Phase 2 adds immutable source revisions,
snapshots and capture receipts; Phase 3 adds document processing and publication.
The native bases (graphdb,
zvec) are imported lazily inside the adapters, so importing ``zknowledge`` does
not require them; they are a preinstalled prerequisite built by Spike-0.
"""

from __future__ import annotations

from .build_models import (
    BuildConfig,
    BuildReconciliation,
    BuildRecord,
    BuildResult,
    Publication,
    PublishedSelection,
)
from .config import (
    AdmissionConfig,
    InputPolicy,
    KnowledgeBaseConfig,
    StoreConfig,
    TimeoutConfig,
)
from .documents import (
    MarkdownParser,
    PlainTextParser,
    SectionSegmenter,
    Segment,
    Segmenter,
    prepare_document,
)
from .embedding import (
    EmbeddedVector,
    EmbeddingDescriptor,
    EmbeddingInput,
    EmbeddingProvider,
    EmbeddingSpace,
    PrecomputedEmbeddings,
    SyntheticEmbeddingProvider,
)
from .errors import (
    CapabilityNotConfiguredError,
    CapabilityNotReadyError,
    ErrorStage,
    IdentityMismatchError,
    IncompatibleFormatError,
    IncompleteInitError,
    InputExcludedError,
    InvalidInputError,
    KnowledgeGraphError,
    NotFoundError,
    OccupiedError,
    OperationCancelledError,
    ProviderError,
    RecoveryRequiredError,
    ResourceExhaustedError,
    SourceConflictError,
    StorageError,
)
from .execution import JobHandle, JobSnapshot, JobStatus, WorkerPool
from .kb import KnowledgeBase
from .manifest import KnowledgeBaseManifest, StoreRef
from .models import (
    CaptureConfig,
    ContentUnit,
    DocumentInput,
    IngestionRecord,
    IngestResult,
    Page,
    Reconciliation,
    Source,
    SourceRevision,
    SourceSpec,
)

__version__ = "0.0.0"

__all__ = [
    "BuildConfig",
    "BuildRecord",
    "BuildReconciliation",
    "BuildResult",
    "Publication",
    "PublishedSelection",
    "MarkdownParser",
    "PlainTextParser",
    "SectionSegmenter",
    "Segment",
    "Segmenter",
    "prepare_document",
    "EmbeddingDescriptor",
    "EmbeddingInput",
    "EmbeddingProvider",
    "EmbeddingSpace",
    "EmbeddedVector",
    "PrecomputedEmbeddings",
    "SyntheticEmbeddingProvider",
    "AdmissionConfig",
    "InputPolicy",
    "SourceSpec",
    "Source",
    "SourceRevision",
    "ContentUnit",
    "DocumentInput",
    "CaptureConfig",
    "IngestResult",
    "IngestionRecord",
    "Reconciliation",
    "Page",
    "InputExcludedError",
    "InvalidInputError",
    "NotFoundError",
    "OperationCancelledError",
    "ProviderError",
    "SourceConflictError",
    "CapabilityNotConfiguredError",
    "CapabilityNotReadyError",
    "ErrorStage",
    "IdentityMismatchError",
    "IncompatibleFormatError",
    "IncompleteInitError",
    "JobHandle",
    "JobSnapshot",
    "JobStatus",
    "KnowledgeBase",
    "KnowledgeBaseConfig",
    "KnowledgeBaseManifest",
    "KnowledgeGraphError",
    "OccupiedError",
    "RecoveryRequiredError",
    "ResourceExhaustedError",
    "StorageError",
    "StoreConfig",
    "StoreRef",
    "TimeoutConfig",
    "WorkerPool",
    "__version__",
]
