"""Source registration and bounded snapshot ingestion, without knowledge publication."""

from __future__ import annotations

import codecs
import fnmatch
import hashlib
import stat
import threading
import uuid
from dataclasses import asdict
from pathlib import Path

from .document_processing import SourceSnapshot, capture_fingerprint, stable_digest
from .errors import (
    ErrorStage,
    InputExcludedError,
    InvalidInputError,
    OperationCancelledError,
    RecoveryRequiredError,
    ResourceExhaustedError,
    SourceConflictError,
    StorageError,
)
from .execution import _CommittedResult
from .models import (
    CaptureConfig,
    ContentUnit,
    DocumentInput,
    IngestionRecord,
    IngestResult,
    Page,
    Reconciliation,
    Source,
    SourceRevision,
    SourceSpec,
    require_text,
)
from .source_store import SourceStore, create_immutable, fetch, put

_DEFAULT_EXCLUDES = (
    ".env",
    ".env.*",
    "*.pem",
    "*.key",
    "*.p12",
    "*.pfx",
    "*.crt",
    "*.cer",
    "id_rsa",
    "id_ed25519",
    "credentials",
    "credentials.*",
    ".git",
    ".ssh",
    ".aws",
)


def _cancel(event):
    if event.is_set():
        raise OperationCancelledError("ingestion cancelled before commit")


class Sources:
    def __init__(self, kb):
        self._kb = kb
        self._store = SourceStore(kb._graph)
        self._active: set[str] = set()
        self._active_lock = threading.Lock()

    def _id(self, *parts: str) -> str:
        return uuid.uuid5(uuid.UUID(self._kb.manifest.kb_id), stable_digest(parts)).hex

    def register(self, spec: SourceSpec) -> Source:
        self._kb._require_writable()
        if not isinstance(spec, SourceSpec):
            raise InvalidInputError("register requires SourceSpec")
        ident = self._id("source", spec.source_key)
        source = Source(ident, spec.source_key, spec.location, spec.domain)

        def write(conn):
            existing = fetch(conn, "KGSource", ident)
            if existing is not None:
                original = Source(**existing)
                if (original.source_key, original.location, original.domain) != (
                    spec.source_key,
                    spec.location,
                    spec.domain,
                ):
                    raise SourceConflictError(
                        "source key already has another domain or location"
                    )
                return original
            put(conn, "KGSource", ident, asdict(source), owner=self._kb.manifest.kb_id)
            return source

        with self._kb._publish_lock:
            self._kb._require_writable()
            return self._kb._graph.write_txn(write)

    def get(self, source_id: str) -> Source:
        self._kb._require_open()
        return Source(**self._store.required("KGSource", source_id))

    def list(self, limit: int = 100, cursor: str | None = None) -> Page[Source]:
        self._kb._require_open()
        values, next_cursor = self._store.page(
            "KGSource", self._kb.manifest.kb_id, limit, cursor
        )
        return Page(tuple(Source(**v) for v in values), next_cursor)

    def revisions(
        self, source_id: str, limit: int = 100, cursor: str | None = None
    ) -> Page[SourceRevision]:
        self.get(source_id)
        values, next_cursor = self._store.page("KGRevision", source_id, limit, cursor)
        return Page(tuple(SourceRevision(**v) for v in values), next_cursor)

    def revision(self, revision_id: str) -> SourceRevision:
        self._kb._require_open()
        return SourceRevision(**self._store.required("KGRevision", revision_id))

    def content_unit(self, unit_id: str) -> ContentUnit:
        self._kb._require_open()
        return ContentUnit(**self._store.required("KGContentUnit", unit_id))

    def read_content_unit(self, unit_id: str) -> bytes:
        unit = self.content_unit(unit_id)
        return self._kb._snapshots.read_range(unit.snapshot_id, unit.start, unit.end)

    def snapshot(self, revision_id: str) -> SourceSnapshot:
        revision = self.revision(revision_id)
        data = self._kb._snapshots.get(revision.snapshot_id)
        return SourceSnapshot(
            revision.source_id,
            revision.id,
            revision.snapshot_id,
            data,
            revision.encoding,
        )

    def _path(self, path: Path) -> Path:
        patterns = _DEFAULT_EXCLUDES + tuple(
            self._kb._config.inputs.additional_excludes
        )
        # Check both spelling and symlink target, before reading any content.
        for candidate in (path, path.resolve()):
            if any(
                fnmatch.fnmatchcase(part.lower(), pattern.lower())
                for pattern in patterns
                for part in candidate.parts
            ) or any(
                fnmatch.fnmatchcase(candidate.as_posix().lower(), p.lower())
                for p in patterns
            ):
                raise InputExcludedError(
                    "input excluded by path policy", detail={"reason": "path_policy"}
                )
        return path

    def submit(
        self,
        source_id: str,
        document: DocumentInput,
        *,
        operation_id: str | None = None,
        capture: CaptureConfig | None = None,
    ):
        self._kb._require_writable()
        if not isinstance(document, DocumentInput):
            raise InvalidInputError("ingest_documents requires DocumentInput")
        source = self.get(source_id)
        config = capture or CaptureConfig()
        if not isinstance(config, CaptureConfig):
            raise InvalidInputError("capture requires CaptureConfig")
        operation_id = uuid.uuid4().hex if operation_id is None else operation_id
        require_text(operation_id, "operation_id")
        maximum = self._kb._config.admission.candidate_space_bytes // 4
        policy_limit = self._kb._config.inputs.max_input_bytes
        if policy_limit is not None:
            if type(policy_limit) is not int or policy_limit < 0:
                raise InvalidInputError("max_input_bytes must be non-negative")
            maximum = min(maximum, policy_limit)
        try:
            path = self._path(document.path) if document.path is not None else None
            if path is not None:
                info = path.stat()
                if not stat.S_ISREG(info.st_mode):
                    raise InvalidInputError("document path must be a regular file")
                estimate = info.st_size
            else:
                estimate = len(document.data)
        except OSError as exc:
            raise InvalidInputError("document input is unavailable") from exc
        if estimate > maximum:
            raise ResourceExhaustedError(
                "input exceeds capture budget",
                retryable=False,
                stage=ErrorStage.SNAPSHOT,
            )

        # Reserve 4x captured bytes for raw/snapshot/checking buffers. Inputs
        # growing beyond the admitted size are rejected, not read unboundedly.
        def run(cancel):
            with self._active_lock:
                if operation_id in self._active:
                    raise SourceConflictError("operation already has an active attempt")
                self._active.add(operation_id)
            try:
                return self._ingest(
                    source, document, path, estimate, config, operation_id, cancel
                )
            finally:
                with self._active_lock:
                    self._active.discard(operation_id)

        handle = self._kb.submit(
            run, kind="ingest_documents", cost_bytes=4 * estimate, phase="capture"
        )
        handle.operation_id = operation_id
        return handle

    def _read_input(self, document, path, estimate):
        try:
            if path is None:
                data = document.data
            else:
                self._path(path)
                with path.open("rb") as stream:
                    data = stream.read(estimate + 1)
                if len(data) > estimate:
                    raise SourceConflictError("input grew beyond its admitted size")
            data.decode("utf-8")
            return data
        except UnicodeError as exc:
            raise InvalidInputError("document is not valid UTF-8") from exc
        except OSError as exc:
            raise InvalidInputError("document capture failed") from exc

    def _ingest(self, source, document, path, estimate, config, operation_id, cancel):
        _cancel(cancel)
        self._kb._graph.require_usable()
        data = self._read_input(document, path, estimate)
        fingerprint = capture_fingerprint(config)
        digest = hashlib.sha256(data).hexdigest()
        _cancel(cancel)
        # Verify existing committed effects before put(): otherwise a missing
        # referenced snapshot could be silently recreated and called unchanged.
        prior = self._store.get("KGIngestOperation", operation_id)
        if prior is not None:
            if any(
                prior[key] != value
                for key, value in (
                    ("source_id", source.id),
                    ("content_digest", digest),
                    ("processing_fingerprint", fingerprint),
                )
            ):
                raise SourceConflictError("operation is bound to another input")
            receipt = self._store.get("KGIngestReceipt", operation_id)
            if receipt is not None:
                result = IngestResult(**receipt)
                try:
                    self._confirm(result)
                except Exception as exc:
                    self._kb._graph.quarantine()
                    raise RecoveryRequiredError(
                        "existing receipt products cannot be verified",
                        detail={"operation_id": operation_id},
                    ) from exc
                return _CommittedResult(result)
        if source.latest_ingestion_id:
            selected = self._store.get("KGIngestReceipt", source.latest_ingestion_id)
            if (
                selected is not None
                and selected["processing_fingerprint"] == fingerprint
            ):
                selected_revision = self._store.get(
                    "KGRevision", selected["revision_id"]
                )
                if selected_revision and selected_revision["content_digest"] == digest:
                    self._confirm(IngestResult(**selected))
        snapshot_id = self._kb._snapshots.put(data, "utf-8")
        revision = SourceRevision(
            self._id("revision", source.id, digest),
            source.id,
            digest,
            snapshot_id,
            "utf-8",
            len(data),
            data.startswith(codecs.BOM_UTF8),
        )
        unit = ContentUnit(
            self._id("unit", revision.id, fingerprint),
            source.id,
            revision.id,
            snapshot_id,
            fingerprint,
            0,
            len(data),
        )
        attempt_id = uuid.uuid4().hex
        operation = {
            "operation_id": operation_id,
            "attempt_id": attempt_id,
            "source_id": source.id,
            "content_digest": digest,
            "snapshot_id": snapshot_id,
            "processing_fingerprint": fingerprint,
            "expected_base": source.latest_ingestion_id,
            "state": "prepared",
        }
        prepared = False
        committed = False
        try:
            with self._kb._publish_lock:
                _cancel(cancel)
                self._kb._graph.require_usable()

                def prepare(conn):
                    prior = fetch(conn, "KGIngestOperation", operation_id)
                    if prior is not None:
                        if any(
                            prior[k] != operation[k]
                            for k in (
                                "source_id",
                                "content_digest",
                                "processing_fingerprint",
                            )
                        ):
                            raise SourceConflictError(
                                "operation is bound to another input"
                            )
                        receipt = fetch(conn, "KGIngestReceipt", operation_id)
                        if receipt is not None:
                            return IngestResult(**receipt)
                        if prior["state"] == "prepared":
                            raise RecoveryRequiredError(
                                "unfinished operation; explicitly reconcile before retry",
                                detail={"operation_id": operation_id},
                            )
                    put(
                        conn,
                        "KGIngestOperation",
                        operation_id,
                        operation,
                        owner=source.id,
                        state="prepared",
                    )
                    put(
                        conn,
                        "KGIngestAttempt",
                        attempt_id,
                        operation,
                        owner=operation_id,
                        state="prepared",
                    )
                    return None

                old_result = self._kb._graph.write_txn(prepare)
                if old_result is None:
                    prepared = True
            if old_result is not None:
                committed = True
                self._confirm(old_result)
                return _CommittedResult(old_result)
            _cancel(cancel)
            with self._kb._publish_lock:
                _cancel(
                    cancel
                )  # commit boundary: after this, commit decides the result
                self._kb._graph.require_usable()

                def commit(conn):
                    current_op = fetch(conn, "KGIngestOperation", operation_id)
                    if (
                        current_op["attempt_id"] != attempt_id
                        or current_op["state"] != "prepared"
                    ):
                        raise SourceConflictError("stale ingestion attempt")
                    current = fetch(conn, "KGSource", source.id)
                    base = current["latest_ingestion_id"]
                    selected = fetch(conn, "KGIngestReceipt", base) if base else None
                    same = bool(
                        selected
                        and selected["revision_id"] == revision.id
                        and selected["processing_fingerprint"] == fingerprint
                    )
                    if base != operation["expected_base"] and not same:
                        raise SourceConflictError("source changed since submission")
                    if same and (
                        fetch(conn, "KGRevision", revision.id) is None
                        or fetch(conn, "KGContentUnit", unit.id) is None
                    ):
                        raise StorageError("current ingestion products are missing")
                    if same:
                        outcome, reason = (
                            "unchanged",
                            "current_input_and_processing_match",
                        )
                    elif not selected:
                        outcome, reason = "captured", "first_capture"
                    elif selected["revision_id"] == revision.id:
                        outcome, reason = "captured", "processing_changed"
                    elif fetch(conn, "KGRevision", revision.id) is not None:
                        outcome, reason = "captured", "reselected_revision"
                    else:
                        outcome, reason = "captured", "input_changed"
                    if create_immutable(conn, "KGRevision", revision, owner=source.id):
                        conn.execute(
                            "MATCH (s:KGSource) WHERE s.id=$s "
                            "MATCH (r:KGRevision) WHERE r.id=$r CREATE (s)-[:KG_HAS_REVISION]->(r)",
                            {"s": source.id, "r": revision.id},
                        )
                    if create_immutable(conn, "KGContentUnit", unit, owner=revision.id):
                        conn.execute(
                            "MATCH (r:KGRevision) WHERE r.id=$r "
                            "MATCH (u:KGContentUnit) WHERE u.id=$u CREATE (r)-[:KG_HAS_UNIT]->(u)",
                            {"r": revision.id, "u": unit.id},
                        )
                    result = IngestResult(
                        operation_id,
                        attempt_id,
                        source.id,
                        revision.id,
                        unit.id,
                        snapshot_id,
                        digest,
                        fingerprint,
                        outcome,
                        reason,
                    )
                    put(
                        conn,
                        "KGIngestReceipt",
                        operation_id,
                        asdict(result),
                        owner=source.id,
                        state="committed",
                    )
                    # An unchanged request gets a receipt without changing the source baseline.
                    if not same:
                        current["latest_ingestion_id"] = operation_id
                        put(
                            conn,
                            "KGSource",
                            source.id,
                            current,
                            owner=self._kb.manifest.kb_id,
                        )
                    operation["state"] = "committed"
                    put(
                        conn,
                        "KGIngestOperation",
                        operation_id,
                        operation,
                        owner=source.id,
                        state="committed",
                    )
                    put(
                        conn,
                        "KGIngestAttempt",
                        attempt_id,
                        operation,
                        owner=operation_id,
                        state="committed",
                    )
                    return result

                result = self._kb._graph.write_txn(commit)
                committed = True
            self._confirm(result)
            return _CommittedResult(result)
        except BaseException as exc:
            if committed or (self._kb._graph.recovery_required):
                self._kb._graph.quarantine()
                raise RecoveryRequiredError(
                    "ingestion outcome requires writable reopen and receipt reconciliation",
                    detail={"operation_id": operation_id},
                    cause=exc,
                ) from exc
            if prepared:
                state = (
                    "cancelled"
                    if isinstance(exc, OperationCancelledError)
                    else "failed"
                )
                try:
                    with self._kb._publish_lock:

                        def fail(conn):
                            op = fetch(conn, "KGIngestOperation", operation_id)
                            if (
                                op["attempt_id"] == attempt_id
                                and op["state"] == "prepared"
                            ):
                                op["state"] = state
                                put(
                                    conn,
                                    "KGIngestOperation",
                                    operation_id,
                                    op,
                                    owner=source.id,
                                    state=state,
                                )
                                put(
                                    conn,
                                    "KGIngestAttempt",
                                    attempt_id,
                                    op,
                                    owner=operation_id,
                                    state=state,
                                )

                        fail._zkg_cleanup = True
                        self._kb._graph.write_txn(fail)
                except Exception as failure:
                    self._kb._graph.quarantine()
                    raise RecoveryRequiredError(
                        "failed to record ingestion outcome",
                        detail={"operation_id": operation_id},
                    ) from failure
            raise

    def _confirm(self, result: IngestResult):
        receipt = self._store.get("KGIngestReceipt", result.operation_id)
        revision = self._store.get("KGRevision", result.revision_id)
        unit = self._store.get("KGContentUnit", result.content_unit_id)
        if (
            receipt != asdict(result)
            or revision is None
            or unit is None
            or revision["source_id"] != result.source_id
            or revision["snapshot_id"] != result.snapshot_id
            or revision["content_digest"] != result.content_digest
            or revision["encoding"] != "utf-8"
            or unit["source_id"] != result.source_id
            or unit["revision_id"] != result.revision_id
            or unit["snapshot_id"] != result.snapshot_id
            or unit["processing_fingerprint"] != result.processing_fingerprint
        ):
            raise StorageError("ingestion receipt or products are not visible")
        data = self._kb._snapshots.get(result.snapshot_id)
        if (
            len(data) != revision["byte_length"]
            or unit["start"] != 0
            or unit["end"] != len(data)
        ):
            raise StorageError("ingestion snapshot does not match graph references")


class Ingestions:
    """Read-only inspection and explicit writable reconciliation after reopen."""

    def __init__(self, kb):
        self._kb = kb
        self._store = SourceStore(kb._graph)

    def get(self, operation_id: str) -> IngestionRecord:
        self._kb._require_open()
        op = self._store.required("KGIngestOperation", operation_id)
        receipt = self._store.get("KGIngestReceipt", operation_id)
        return IngestionRecord(
            **op, result=IngestResult(**receipt) if receipt else None
        )

    def snapshot(self, operation_id: str) -> SourceSnapshot:
        """Inspect frozen input, including a prepared operation without a revision."""
        record = self.get(operation_id)
        data = self._kb._snapshots.get(record.snapshot_id)
        revision_id = self._kb.sources._id(
            "revision", record.source_id, record.content_digest
        )
        return SourceSnapshot(record.source_id, revision_id, record.snapshot_id, data)

    def reconcile(self, operation_id: str) -> Reconciliation:
        self._kb._require_writable()
        with self._kb._publish_lock:
            self._kb._require_writable()
            op = self._store.required("KGIngestOperation", operation_id)
            receipt = self._store.get("KGIngestReceipt", operation_id)
            if receipt is not None:
                result = IngestResult(**receipt)
                try:
                    self._kb.sources._confirm(result)
                except Exception as exc:
                    self._kb._graph.quarantine()
                    raise RecoveryRequiredError(
                        "receipt products cannot be verified",
                        detail={"operation_id": operation_id},
                    ) from exc
                return Reconciliation(operation_id, "committed", result)
            if op["state"] == "committed":
                self._kb._graph.quarantine()
                raise RecoveryRequiredError("committed operation has no receipt")
            with self._kb.sources._active_lock:
                if operation_id in self._kb.sources._active:
                    raise SourceConflictError("cannot reconcile an active operation")

                def mark(conn):
                    op["state"] = "failed"
                    put(
                        conn,
                        "KGIngestOperation",
                        operation_id,
                        op,
                        owner=op["source_id"],
                        state="failed",
                    )
                    put(
                        conn,
                        "KGIngestAttempt",
                        op["attempt_id"],
                        op,
                        owner=operation_id,
                        state="failed",
                    )

                self._kb._graph.write_txn(mark)
            return Reconciliation(operation_id, "not_committed")
