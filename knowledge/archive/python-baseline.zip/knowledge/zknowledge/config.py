"""Configuration and resource defaults (design doc sections 5.8 and 2.4).

All numeric limits here are conservative placeholders. Section 5.8 is explicit
that admission quotas, estimation method and timeout defaults are NOT frozen in
the design; they are recorded in the resource profile and detailed design. Keep
them small and documented so Phase 1 behaviour is testable without pretending
to be tuned.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class AdmissionConfig:
    """Build admission / backpressure limits (section 5.8).

    Placeholder values pending the Spike profile; do not treat as tuned.
    """

    max_queue: int = 64
    max_slots: int = 4
    batch_buffer: int = 16
    candidate_space_bytes: int = 1 << 30  # 1 GiB placeholder


@dataclass(frozen=True)
class TimeoutConfig:
    """Wait deadlines. Placeholders pending profile (section 5.8)."""

    admission_wait_seconds: float = 5.0
    job_wait_seconds: float = 30.0
    visibility_wait_seconds: float = 5.0
    close_drain_seconds: float = 10.0


@dataclass(frozen=True)
class StoreConfig:
    """Backing-store options verified against Spike-0 usage."""

    graph_transaction_mode: str = "tp"
    index_enable_mmap: bool = True
    graph_transaction_timeout_ms: int = 1000
    graph_max_intermediate_rows: int = 1_000_000
    graph_max_retired_versions: int = 64
    index_compact_threshold: int = 16

    def __post_init__(self):
        if (
            type(self.graph_transaction_timeout_ms) is not int
            or self.graph_transaction_timeout_ms <= 0
            or type(self.graph_max_intermediate_rows) is not int
            or self.graph_max_intermediate_rows <= 0
            or type(self.graph_max_retired_versions) is not int
            or self.graph_max_retired_versions < 8
            or type(self.index_compact_threshold) is not int
            or self.index_compact_threshold < 2
        ):
            from .errors import InvalidInputError

            raise InvalidInputError("graph budgets must be positive integers")


@dataclass(frozen=True)
class InputPolicy:
    # None derives a ceiling from candidate_space_bytes / 4. This is a
    # conservative admission estimate, not a native RSS or disk hard limit.
    max_input_bytes: int | None = None
    additional_excludes: tuple[str, ...] = ()


@dataclass(frozen=True)
class KnowledgeBaseConfig:
    """Top-level handle configuration assembled from the groups above."""

    admission: AdmissionConfig = field(default_factory=AdmissionConfig)
    timeouts: TimeoutConfig = field(default_factory=TimeoutConfig)
    store: StoreConfig = field(default_factory=StoreConfig)
    inputs: InputPolicy = field(default_factory=InputPolicy)

    def __post_init__(self):
        if self.store.graph_max_retired_versions < self.admission.max_slots + 4:
            from .errors import InvalidInputError

            raise InvalidInputError(
                "retired-version budget must reserve cleanup capacity for all workers"
            )

    @classmethod
    def default(cls) -> "KnowledgeBaseConfig":
        return cls()
