"""Knowledge base manifest (design doc section 8.2).

The manifest is the independently checkable logical inventory of a KB: stable
identity, storage generation, format/schema versions, domain-rules version,
base compatibility, and the ownership of the graphdb / zvec / snapshot stores.
Physical layout and encoding are detailed-design concerns; the pre-open checks
and rejection behaviour implemented here are first-version contract.

Ownership markers live in ``<root>/stores/<kind>.json`` -- deliberately OUTSIDE
the graphdb / zvec data directories, because graphdb refuses to open a TP
directory that contains unexpected files (verified in Phase 1). ``open`` uses
these markers to reject a root that mixes stores from another KB identity or
another generation (acceptance A25).
"""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from ._persistence import atomic_bytes
from .errors import (
    IdentityMismatchError,
    IncompatibleFormatError,
    IncompleteInitError,
)

FORMAT_VERSION = 1
# Phase 2 source/capture schema; no migration from Phase 1 empty stores.
SCHEMA_VERSION = 1
DOMAIN_RULES_VERSION = 0
# format_version values this build is willing to read.
COMPAT_MATRIX = frozenset({1})

MANIFEST_NAME = "manifest.json"
STORES_DIRNAME = "stores"

STORE_KINDS = ("graphdb", "index", "snapshots")
_STORE_RELPATH = {
    "graphdb": "graph",
    "index": "index",
    "snapshots": "snapshots",
}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass(frozen=True)
class BaseCompat:
    """Pinned base revisions the KB was created against."""

    graphdb_commit: str = "unknown"
    zvec_commit: str = "unknown"

    def to_dict(self) -> dict[str, str]:
        return {
            "graphdb_commit": self.graphdb_commit,
            "zvec_commit": self.zvec_commit,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "BaseCompat":
        return cls(
            graphdb_commit=data.get("graphdb_commit", "unknown"),
            zvec_commit=data.get("zvec_commit", "unknown"),
        )


@dataclass(frozen=True)
class StoreRef:
    """One store's relative path and stable ownership id."""

    kind: str
    relpath: str
    store_id: str

    def to_dict(self) -> dict[str, str]:
        return {
            "kind": self.kind,
            "relpath": self.relpath,
            "store_id": self.store_id,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "StoreRef":
        return cls(
            kind=data["kind"],
            relpath=data["relpath"],
            store_id=data["store_id"],
        )


@dataclass(frozen=True)
class KnowledgeBaseManifest:
    kb_id: str
    storage_generation: int
    format_version: int
    schema_version: int
    domain_rules_version: int
    base_compat: BaseCompat
    stores: tuple[StoreRef, ...]
    created_at: str
    ready: bool

    def store(self, kind: str) -> StoreRef:
        for ref in self.stores:
            if ref.kind == kind:
                return ref
        raise KeyError(kind)

    def to_dict(self) -> dict:
        return {
            "kb_id": self.kb_id,
            "storage_generation": self.storage_generation,
            "format_version": self.format_version,
            "schema_version": self.schema_version,
            "domain_rules_version": self.domain_rules_version,
            "base_compat": self.base_compat.to_dict(),
            "stores": [s.to_dict() for s in self.stores],
            "created_at": self.created_at,
            "ready": self.ready,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "KnowledgeBaseManifest":
        return cls(
            kb_id=data["kb_id"],
            storage_generation=int(data["storage_generation"]),
            format_version=int(data["format_version"]),
            schema_version=int(data["schema_version"]),
            domain_rules_version=int(data["domain_rules_version"]),
            base_compat=BaseCompat.from_dict(data.get("base_compat", {})),
            stores=tuple(StoreRef.from_dict(s) for s in data["stores"]),
            created_at=data["created_at"],
            ready=bool(data["ready"]),
        )

    def with_ready(self, ready: bool) -> "KnowledgeBaseManifest":
        return KnowledgeBaseManifest(
            kb_id=self.kb_id,
            storage_generation=self.storage_generation,
            format_version=self.format_version,
            schema_version=self.schema_version,
            domain_rules_version=self.domain_rules_version,
            base_compat=self.base_compat,
            stores=self.stores,
            created_at=self.created_at,
            ready=ready,
        )


def default_base_compat() -> BaseCompat:
    """Best-effort pinned revisions from the Spike-0 dependency manifest.

    Falls back to installed distribution versions, then to ``unknown``. This is
    a convenience for create(); callers may pass an explicit BaseCompat.
    """
    repo_root = Path(__file__).resolve().parent.parent
    deps = repo_root / "spikes" / "spike_0" / "dependencies.json"
    commits: dict[str, str] = {}
    try:
        payload = json.loads(deps.read_text())
        for item in payload.get("dependencies", []):
            if item.get("name") in ("graphdb", "zvec"):
                commits[item["name"]] = item.get("commit", "unknown")
    except (OSError, ValueError, KeyError):
        pass
    if "graphdb" not in commits or "zvec" not in commits:
        try:
            import importlib.metadata as md

            for name in ("graphdb", "zvec"):
                if name not in commits:
                    commits[name] = "version:" + md.version(name)
        except Exception:  # pragma: no cover - metadata optional
            pass
    return BaseCompat(
        graphdb_commit=commits.get("graphdb", "unknown"),
        zvec_commit=commits.get("zvec", "unknown"),
    )


def new_manifest(base_compat: Optional[BaseCompat] = None) -> KnowledgeBaseManifest:
    """Build a fresh, not-yet-ready manifest with stable store ids."""
    compat = base_compat or default_base_compat()
    stores = tuple(
        StoreRef(kind=kind, relpath=_STORE_RELPATH[kind], store_id=uuid.uuid4().hex)
        for kind in STORE_KINDS
    )
    return KnowledgeBaseManifest(
        kb_id=uuid.uuid4().hex,
        storage_generation=0,
        format_version=FORMAT_VERSION,
        schema_version=SCHEMA_VERSION,
        domain_rules_version=DOMAIN_RULES_VERSION,
        base_compat=compat,
        stores=stores,
        created_at=_now(),
        ready=False,
    )


def _atomic_write_json(path: Path, payload: dict) -> None:
    atomic_bytes(
        path, (json.dumps(payload, indent=2, ensure_ascii=False) + "\n").encode()
    )


def manifest_path(root: Path) -> Path:
    return root / MANIFEST_NAME


def write_manifest(root: Path, manifest: KnowledgeBaseManifest) -> None:
    _atomic_write_json(manifest_path(root), manifest.to_dict())


def read_manifest(root: Path) -> KnowledgeBaseManifest:
    """Load and format-check the manifest. Raises on missing/incompatible."""
    path = manifest_path(root)
    if not path.exists():
        raise IncompleteInitError(
            f"no manifest at {path}; not a zknowledge KB or create was interrupted"
        )
    try:
        data = json.loads(path.read_text())
    except ValueError as exc:
        raise IncompatibleFormatError(
            f"manifest at {path} is not valid JSON", cause=exc
        ) from exc
    manifest = KnowledgeBaseManifest.from_dict(data)
    if manifest.format_version not in COMPAT_MATRIX:
        raise IncompatibleFormatError(
            "KB format_version "
            f"{manifest.format_version} not in readable set "
            f"{sorted(COMPAT_MATRIX)}; explicit offline migration required"
        )
    if manifest.schema_version != SCHEMA_VERSION:
        raise IncompatibleFormatError(
            f"unsupported schema_version {manifest.schema_version}; expected "
            f"{SCHEMA_VERSION}; no automatic migration or overwrite"
        )
    return manifest


def mark_ready(root: Path, manifest: KnowledgeBaseManifest) -> KnowledgeBaseManifest:
    ready = manifest.with_ready(True)
    write_manifest(root, ready)
    return ready


def _marker_path(root: Path, kind: str) -> Path:
    return root / STORES_DIRNAME / f"{kind}.json"


def write_store_marker(
    root: Path,
    ref: StoreRef,
    manifest: KnowledgeBaseManifest,
    state: Optional[dict] = None,
) -> None:
    _atomic_write_json(
        _marker_path(root, ref.kind),
        {
            "kb_id": manifest.kb_id,
            "store_id": ref.store_id,
            "kind": ref.kind,
            "storage_generation": manifest.storage_generation,
            "relpath": ref.relpath,
            "state": state or {},
        },
    )


def read_store_marker(root: Path, kind: str) -> Optional[dict]:
    path = _marker_path(root, kind)
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except ValueError:
        return None


def update_store_state(root: Path, kind: str, **fields: object) -> None:
    """Merge mutable state into a store marker without touching identity."""
    marker = read_store_marker(root, kind)
    if marker is None:
        raise IdentityMismatchError(f"store '{kind}' has no ownership marker")
    state = dict(marker.get("state", {}))
    state.update(fields)
    marker["state"] = state
    _atomic_write_json(_marker_path(root, kind), marker)


def validate_store_ownership(root: Path, manifest: KnowledgeBaseManifest) -> None:
    """Reject a root that mixes stores from another KB identity/generation."""
    for ref in manifest.stores:
        marker = read_store_marker(root, ref.kind)
        if marker is None:
            raise IdentityMismatchError(
                f"store '{ref.kind}' has no ownership marker under "
                f"{root / STORES_DIRNAME}; refusing to open a mixed or "
                "foreign store assembly"
            )
        if (
            marker.get("kb_id") != manifest.kb_id
            or marker.get("store_id") != ref.store_id
            or marker.get("storage_generation") != manifest.storage_generation
        ):
            raise IdentityMismatchError(
                f"store '{ref.kind}' belongs to another KB identity or "
                "storage generation"
            )
