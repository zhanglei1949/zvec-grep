"""Framework embedding values, local precomputed input and explicit test provider."""

from __future__ import annotations

import hashlib
import math
import struct
from dataclasses import asdict, dataclass, field
from typing import Mapping, Protocol, Sequence

from .document_processing import ParseContext, _freeze, stable_digest
from .errors import InvalidInputError, ProviderError
from .models import require_text


@dataclass(frozen=True)
class EmbeddingSpace:
    model: str
    version: str
    dimensions: int
    metric: str = "cosine"
    normalization: str = "l2"
    preprocessing: str = "raw-utf8-v1"
    quantization: str = "fp32"
    document_encoding: str = "document"
    query_encoding: str = "query"

    def __post_init__(self):
        for name in (
            "model",
            "version",
            "preprocessing",
            "quantization",
            "document_encoding",
            "query_encoding",
        ):
            require_text(getattr(self, name), name)
        if (
            type(self.dimensions) is not int
            or not 1 <= self.dimensions <= 65536
            or self.metric not in {"cosine", "ip", "l2"}
            or self.normalization not in {"l2", "none"}
        ):
            raise InvalidInputError("invalid embedding space")

    @property
    def id(self):
        return stable_digest(asdict(self))


@dataclass(frozen=True)
class EmbeddingDescriptor:
    implementation: str
    version: str
    space: EmbeddingSpace
    configuration: Mapping = field(default_factory=dict)
    contract_version: str = "1"

    def __post_init__(self):
        require_text(self.implementation, "embedding implementation")
        require_text(self.version, "embedding implementation version")
        require_text(self.contract_version, "embedding contract version")
        if not isinstance(self.space, EmbeddingSpace):
            raise InvalidInputError("embedding space type mismatch")
        object.__setattr__(self, "configuration", _freeze(self.configuration))

    @property
    def fingerprint(self):
        return stable_digest(
            {
                "implementation": self.implementation,
                "version": self.version,
                "contract": self.contract_version,
                "space": asdict(self.space),
                "configuration": self.configuration,
            }
        )


@dataclass(frozen=True)
class EmbeddingInput:
    unit_id: str
    input_digest: str
    text: str = field(repr=False)


@dataclass(frozen=True)
class EmbeddedVector:
    unit_id: str
    input_digest: str
    vector: tuple[float, ...] = field(repr=False)
    status: str = "complete"
    diagnostic: str = ""


class EmbeddingProvider(Protocol):
    def describe(self) -> EmbeddingDescriptor: ...
    def embed(
        self, items: Sequence[EmbeddingInput], context: ParseContext
    ) -> Sequence[EmbeddedVector]: ...


def validate_vector(vector, space):
    if not isinstance(vector, (tuple, list)) or len(vector) != space.dimensions:
        raise ProviderError("embedding dimension mismatch")
    try:
        if any(type(x) not in (int, float) or not math.isfinite(x) for x in vector):
            raise ValueError("non-finite value")
        canonical = struct.unpack(
            f"<{space.dimensions}f", struct.pack(f"<{space.dimensions}f", *vector)
        )
        if not all(math.isfinite(x) for x in canonical):
            raise ValueError("fp32 overflow")
    except (ValueError, TypeError, OverflowError, struct.error) as exc:
        raise ProviderError("embedding must contain finite fp32 values") from exc
    norm = math.sqrt(sum(x * x for x in canonical))
    if (space.metric == "cosine" and norm == 0) or (
        space.normalization == "l2" and abs(norm - 1) > 1e-4
    ):
        raise ProviderError("embedding normalization mismatch")
    return tuple(canonical)


@dataclass(frozen=True)
class PrecomputedEmbeddings:
    space: EmbeddingSpace
    values: tuple[EmbeddedVector, ...] = field(repr=False)

    def __post_init__(self):
        clean, seen = [], set()
        for value in self.values:
            if (
                not isinstance(value, EmbeddedVector)
                or value.unit_id in seen
                or value.status != "complete"
            ):
                raise InvalidInputError("invalid or duplicate precomputed vector")
            require_text(value.unit_id, "vector unit id")
            require_text(value.input_digest, "vector input digest")
            seen.add(value.unit_id)
            clean.append(
                EmbeddedVector(
                    value.unit_id,
                    value.input_digest,
                    validate_vector(value.vector, self.space),
                )
            )
        object.__setattr__(self, "values", tuple(clean))

    def describe(self):
        return EmbeddingDescriptor(
            "zknowledge.precomputed",
            "1",
            self.space,
            {
                "manifest_digest": stable_digest(
                    [asdict(v) for v in sorted(self.values, key=lambda v: v.unit_id)]
                )
            },
        )

    def frozen_manifest(self):
        return {"space": asdict(self.space), "values": [asdict(v) for v in self.values]}

    def embed(self, items, context):
        context.check()
        by_id = {v.unit_id: v for v in self.values}
        result = []
        for item in items:
            if (
                item.unit_id not in by_id
                or by_id[item.unit_id].input_digest != item.input_digest
            ):
                raise ProviderError("precomputed vector input mismatch")
            result.append(by_id[item.unit_id])
        return tuple(result)


@dataclass(frozen=True)
class SyntheticEmbeddingProvider:
    """Explicit deterministic storage-test vectors, not semantic embeddings."""

    dimensions: int = 8

    def describe(self):
        return EmbeddingDescriptor(
            "zknowledge.synthetic_test",
            "1",
            EmbeddingSpace("synthetic/storage-test", "1", self.dimensions),
        )

    def embed(self, items, context):
        result = []
        for item in items:
            context.check()
            vector = [0.0] * self.dimensions
            vector[
                int(hashlib.sha256(item.text.encode()).hexdigest(), 16)
                % self.dimensions
            ] = 1.0
            result.append(
                EmbeddedVector(item.unit_id, item.input_digest, tuple(vector))
            )
        return tuple(result)


def embed_batch(provider, items, context):
    descriptor = provider.describe()
    if not isinstance(descriptor, EmbeddingDescriptor):
        raise ProviderError("embedding descriptor type mismatch")
    context.check()
    try:
        result = tuple(provider.embed(tuple(items), context))
    except Exception as exc:
        from .errors import KnowledgeGraphError

        if isinstance(exc, KnowledgeGraphError):
            raise
        raise ProviderError("embedding provider failed") from exc
    context.check()
    if provider.describe() != descriptor or len(result) != len(items):
        raise ProviderError("embedding contract or result count mismatch")
    seen, clean = set(), []
    expected = {item.unit_id: item for item in items}
    for value in result:
        if (
            not isinstance(value, EmbeddedVector)
            or value.unit_id in seen
            or value.unit_id not in expected
            or value.status != "complete"
            or value.input_digest != expected[value.unit_id].input_digest
        ):
            raise ProviderError("embedding item identity/status mismatch")
        seen.add(value.unit_id)
        clean.append(
            EmbeddedVector(
                value.unit_id,
                value.input_digest,
                validate_vector(value.vector, descriptor.space),
            )
        )
    by_id = {v.unit_id: v for v in clean}
    return tuple(by_id[item.unit_id] for item in items)
