"""Markdown structure and independent, byte-addressed retrieval segmentation."""

from __future__ import annotations

import hashlib
import re
from dataclasses import asdict, dataclass, replace
from typing import Protocol, Sequence

from .document_processing import (
    DocumentBlock,
    ParseContext,
    ParsedDocument,
    ParserDescriptor,
    SourceSnapshot,
    SourceSpan,
    StageFingerprint,
    parse_document,
    processing_fingerprint,
    stable_digest,
)
from .errors import InvalidInputError, ProviderError


class MarkdownParser:
    """CommonMark + tables. No rendering, network access, or external file reads."""

    def describe(self) -> ParserDescriptor:
        from importlib.metadata import version

        return ParserDescriptor(
            "zknowledge.markdown_it",
            version("markdown-it-py"),
            supported_formats=("text/markdown", "text/plain"),
            configuration={"syntax": "commonmark+table", "mapping": "raw-lines-v1"},
        )

    def parse(self, snapshot: SourceSnapshot, context: ParseContext) -> ParsedDocument:
        from markdown_it import MarkdownIt

        context.check()
        data = snapshot.data
        offsets = [0] + [m.end() for m in re.finditer(rb"\r\n|\r|\n", data)]
        if offsets[-1] != len(data):
            offsets.append(len(data))

        def span(start, end):
            return SourceSpan(snapshot.revision_id, snapshot.snapshot_id, start, end)

        root = DocumentBlock("root", "document", span(0, len(data)))
        if snapshot.media_type == "text/plain":
            return ParsedDocument(snapshot.revision_id, (root,))
        tokens = (
            MarkdownIt("commonmark").enable("table").parse(data.decode("utf-8-sig"))
        )
        headings = [
            (i, t, int(t.tag[1:]))
            for i, t in enumerate(tokens)
            if t.type == "heading_open" and t.level == 0
        ]
        sections = []
        for pos, (i, token, level) in enumerate(headings):
            context.check()
            start = offsets[token.map[0]]
            end = len(data)
            for _, following, next_level in headings[pos + 1 :]:
                if next_level <= level:
                    end = offsets[following.map[0]]
                    break
            parent = "root"
            for prior in reversed(sections):
                if prior.span.start <= start and end <= prior.span.end:
                    parent = prior.local_id
                    break
            sections.append(
                DocumentBlock(f"section-{i}", "section", span(start, end), parent)
            )
        blocks = [root, *sections]
        for i, token in enumerate(tokens):
            context.check()
            if not token.block or token.map is None or token.type == "inline":
                continue
            start, end = offsets[token.map[0]], offsets[token.map[1]]
            parent = "root"
            for section in reversed(sections):
                if section.span.start <= start and end <= section.span.end:
                    parent = section.local_id
                    break
            blocks.append(
                DocumentBlock(f"block-{i}", token.type, span(start, end), parent)
            )
            if len(blocks) > context.budget.max_output_items:
                raise ProviderError("parser output budget exceeded")
        return ParsedDocument(snapshot.revision_id, tuple(blocks))


class PlainTextParser:
    def describe(self) -> ParserDescriptor:
        return ParserDescriptor(
            "zknowledge.plaintext",
            "1",
            supported_formats=("text/plain", "text/markdown"),
        )

    def parse(self, snapshot, context):
        context.check()
        return ParsedDocument(
            snapshot.revision_id,
            (
                DocumentBlock(
                    "root",
                    "document",
                    SourceSpan(
                        snapshot.revision_id,
                        snapshot.snapshot_id,
                        0,
                        len(snapshot.data),
                    ),
                ),
            ),
        )


@dataclass(frozen=True)
class Segment:
    id: str
    source_id: str
    revision_id: str
    snapshot_id: str
    start: int
    end: int
    content_digest: str
    input_digest: str
    processing_fingerprint: str

    def read(self, snapshot: SourceSnapshot) -> bytes:
        if (snapshot.revision_id, snapshot.snapshot_id) != (
            self.revision_id,
            self.snapshot_id,
        ):
            raise InvalidInputError("segment snapshot mismatch")
        value = snapshot.read(self.start, self.end)
        if hashlib.sha256(value).hexdigest() != self.content_digest:
            raise InvalidInputError("segment digest mismatch")
        return value


class Segmenter(Protocol):
    def describe(self) -> ParserDescriptor: ...
    def segment(
        self, document: ParsedDocument, snapshot: SourceSnapshot, context: ParseContext
    ) -> Sequence[Segment]: ...


@dataclass(frozen=True)
class SectionSegmenter:
    """Bounded raw-byte sections, UTF-8 safe. Oversized blocks split explicitly."""

    max_bytes: int = 4096
    overlap_bytes: int = 0

    def __post_init__(self):
        if (
            type(self.max_bytes) is not int
            or self.max_bytes < 4
            or type(self.overlap_bytes) is not int
            or not 0 <= self.overlap_bytes < self.max_bytes - 3
        ):
            raise InvalidInputError("invalid segment byte limits")

    def describe(self):
        return ParserDescriptor(
            "zknowledge.sections",
            "1",
            configuration={
                **asdict(self),
                "oversize": "split-utf8",
                "context": "raw-only",
            },
        )

    def segment(self, document, snapshot, context):
        if document.revision_id != snapshot.revision_id:
            raise ProviderError("segment document revision mismatch")
        # The coordinator supplies the full parse -> segment dependency fingerprint.
        own_fp = processing_fingerprint("segment", self.describe()).digest
        boundaries = sorted(
            {
                0,
                len(snapshot.data),
                *(b.span.start for b in document.blocks if b.kind == "section"),
            }
        )
        result = []
        for start, stop in zip(boundaries, boundaries[1:]):
            while start < stop:
                context.check()
                end = min(start + self.max_bytes, stop)
                while end < len(snapshot.data) and snapshot.data[end] & 0xC0 == 0x80:
                    end -= 1
                if end < stop:
                    line_end = snapshot.data.rfind(
                        b"\n", start + self.overlap_bytes + 1, end
                    )
                    if line_end >= 0:
                        end = line_end + 1
                value = snapshot.read(start, end)
                digest = hashlib.sha256(value).hexdigest()
                ident = stable_digest(
                    [snapshot.revision_id, own_fp, start, end, digest]
                )
                result.append(
                    Segment(
                        ident,
                        snapshot.source_id,
                        snapshot.revision_id,
                        snapshot.snapshot_id,
                        start,
                        end,
                        digest,
                        digest,
                        own_fp,
                    )
                )
                if len(result) > context.budget.max_output_items:
                    raise ProviderError("segment output budget exceeded")
                if end == stop:
                    break
                following = end - self.overlap_bytes
                while following < end and snapshot.data[following] & 0xC0 == 0x80:
                    following += 1
                start = max(start + 1, following)
        return tuple(result)


def segment_document(
    segmenter, parsed, snapshot, context, *, parse_fingerprint=None
) -> tuple[Segment, ...]:
    context.check()
    if parsed.status != "complete":
        raise ProviderError("incomplete parse cannot be segmented for publication")
    descriptor = segmenter.describe()
    if not isinstance(descriptor, ParserDescriptor):
        raise ProviderError("segmenter descriptor type mismatch")
    try:
        units = tuple(segmenter.segment(parsed, snapshot, context))
    except (ProviderError, InvalidInputError):
        raise
    except Exception as exc:
        from .errors import OperationCancelledError

        if isinstance(exc, OperationCancelledError):
            raise
        raise ProviderError("segmenter failed") from exc
    if len(units) > context.budget.max_output_items:
        raise ProviderError("segment output budget exceeded")
    covered, seen, ranges = 0, set(), set()
    last_start = -1
    for unit in units:
        context.check()
        if (
            not isinstance(unit, Segment)
            or unit.id in seen
            or unit.source_id != snapshot.source_id
            or unit.start < last_start
            or not 0 <= unit.start < unit.end <= len(snapshot.data)
        ):
            raise ProviderError("invalid segment identity or range")
        if unit.start > covered or (unit.start, unit.end) in ranges:
            raise ProviderError("segment coverage gap or duplicate range")
        allowed_overlap = descriptor.configuration.get("overlap_bytes", 0)
        if (
            type(allowed_overlap) is not int
            or allowed_overlap < 0
            or covered - unit.start > allowed_overlap
        ):
            raise ProviderError("segment overlap exceeds declared policy")
        try:
            raw = unit.read(snapshot)
            raw.decode("utf-8")
            if snapshot.data[unit.start] & 0xC0 == 0x80:
                raise UnicodeError("start is not UTF-8 boundary")
        except (UnicodeError, InvalidInputError) as exc:
            raise ProviderError("segment mapping or UTF-8 mismatch") from exc
        if unit.input_digest != unit.content_digest:
            raise ProviderError("raw-only segment input digest mismatch")
        covered = max(covered, unit.end)
        last_start = unit.start
        seen.add(unit.id)
        ranges.add((unit.start, unit.end))
    if covered != len(snapshot.data):
        raise ProviderError("segment coverage is incomplete")
    context.check()
    fingerprint = processing_fingerprint(
        "segment", descriptor, (parse_fingerprint,) if parse_fingerprint else ()
    ).digest
    return tuple(
        replace(
            unit,
            id=stable_digest([snapshot.revision_id, fingerprint, unit.start, unit.end]),
            processing_fingerprint=fingerprint,
        )
        for unit in units
    )


def prepare_document(snapshot, *, parser=None, segmenter=None, context):
    """Pure deterministic preparation for precomputed embeddings; no store writes."""
    parser, segmenter = parser or MarkdownParser(), segmenter or SectionSegmenter()
    parsed = parse_document(parser, snapshot, context)
    return segment_document(
        segmenter,
        parsed,
        snapshot,
        context,
        parse_fingerprint=processing_fingerprint(
            "parse",
            parser.describe(),
            (StageFingerprint("media_type", stable_digest(snapshot.media_type)),),
        ),
    )
