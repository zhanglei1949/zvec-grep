"""Phase 2 public values. IDs are opaque, immutable application identifiers."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Generic, TypeVar

from .errors import InvalidInputError


def require_text(value: str, field: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise InvalidInputError(f"{field} must be a non-empty string")


@dataclass(frozen=True)
class SourceSpec:
    source_key: str
    location: str = ""
    domain: str = "documents"

    def __post_init__(self):
        require_text(self.source_key, "source_key")
        require_text(self.domain, "domain")
        if not isinstance(self.location, str):
            raise InvalidInputError("location must be a string")


@dataclass(frozen=True)
class Source:
    id: str
    source_key: str
    location: str
    domain: str
    latest_ingestion_id: str = ""


@dataclass(frozen=True)
class SourceRevision:
    id: str
    source_id: str
    content_digest: str
    snapshot_id: str
    encoding: str
    byte_length: int
    has_bom: bool


@dataclass(frozen=True)
class ContentUnit:
    id: str
    source_id: str
    revision_id: str
    snapshot_id: str
    processing_fingerprint: str
    start: int
    end: int
    kind: str = "document"


@dataclass(frozen=True)
class DocumentInput:
    """Exactly one input; bytes are explicit caller-submitted content."""

    path: Path | None = None
    data: bytes | None = field(default=None, repr=False)

    def __post_init__(self):
        if (self.path is None) == (self.data is None):
            raise InvalidInputError("provide exactly one path or bytes input")
        if self.path is not None:
            object.__setattr__(self, "path", Path(self.path).absolute())
        if self.data is not None and not isinstance(self.data, bytes):
            raise InvalidInputError("document data must be immutable bytes")

    @classmethod
    def from_path(cls, path: Path | str) -> DocumentInput:
        return cls(path=Path(path))

    @classmethod
    def from_bytes(cls, data: bytes) -> DocumentInput:
        return cls(data=data)


@dataclass(frozen=True)
class CaptureConfig:
    """Version of the deterministic capture algorithm, not a model version."""

    processor_version: str = "1"

    def __post_init__(self):
        require_text(self.processor_version, "processor_version")


@dataclass(frozen=True)
class IngestResult:
    operation_id: str
    attempt_id: str
    source_id: str
    revision_id: str
    content_unit_id: str
    # snapshot_id (content address of the stored bytes) and content_digest
    # (revision content summary) are distinct fields. Phase 2 makes them equal
    # for a whole-document sha256, but they are kept separate so multi-file
    # snapshot manifests or normalized-content digests in later phases do not
    # silently break confirmation or snapshot retrieval.
    snapshot_id: str
    content_digest: str
    processing_fingerprint: str
    outcome: str
    reason: str
    search_ready: bool = False


T = TypeVar("T")


@dataclass(frozen=True)
class Page(Generic[T]):
    items: tuple[T, ...]
    next_cursor: str | None = None


@dataclass(frozen=True)
class IngestionRecord:
    operation_id: str
    attempt_id: str
    source_id: str
    content_digest: str
    snapshot_id: str
    processing_fingerprint: str
    expected_base: str
    state: str
    result: IngestResult | None = None


@dataclass(frozen=True)
class Reconciliation:
    operation_id: str
    state: str  # committed / not_committed
    result: IngestResult | None = None
