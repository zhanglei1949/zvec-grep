"""Owned, versioned text/vector collections and recoverable creation intents."""

from __future__ import annotations

import gc
import json
import shutil
import tempfile
from pathlib import Path

from .adapters.search_index import SearchIndexAdapter
from .document_processing import stable_digest
from .errors import (
    IdentityMismatchError,
    IncompleteInitError,
    RecoveryRequiredError,
    ResourceExhaustedError,
    StorageError,
)
from .manifest import read_store_marker, update_store_state


def descriptor(channel, space=None, *, owner=""):
    value = {
        "owner": owner,
        "contract": "projection-v1",
        "channel": channel,
        "text_config": "standard-lowercase-v1" if channel == "text" else "",
        "space": space,
    }
    return {**value, "id": stable_digest(value)}


def native_schema(value):
    import zvec

    fields = [
        zvec.FieldSchema(name, zvec.DataType.STRING, nullable=False)
        for name in (
            "business_id",
            "source_id",
            "revision_id",
            "build_version",
            "space_id",
            "content_digest",
            "input_digest",
        )
    ]
    fields.append(
        zvec.FieldSchema(
            "body",
            zvec.DataType.STRING,
            nullable=False,
            index_param=zvec.FtsIndexParam(
                tokenizer_name="standard", filters=["lowercase"]
            )
            if value["channel"] == "text"
            else None,
        )
    )
    vectors = None
    if value["channel"] == "vector":
        space = value["space"]
        metric = {
            "cosine": zvec.MetricType.COSINE,
            "ip": zvec.MetricType.IP,
            "l2": zvec.MetricType.L2,
        }[space["metric"]]
        vectors = [
            zvec.VectorSchema(
                "embedding",
                zvec.DataType.VECTOR_FP32,
                dimension=space["dimensions"],
                index_param=zvec.HnswIndexParam(metric_type=metric),
            )
        ]
    return zvec.CollectionSchema(
        name="kg_" + value["id"][:24], fields=fields, vectors=vectors
    )


class IndexCatalog:
    def __init__(
        self, root, path, *, read_only, config, lock, read_copy_budget_bytes=1 << 30
    ):
        self.root, self.path = Path(root), Path(path)
        self.read_only, self.config, self._lock = read_only, config, lock
        self._handles = {}
        self._closed = False
        self._read_copies = None
        self._read_copy_bytes = 0
        self._read_copy_budget = read_copy_budget_bytes
        self._load()
        self._session_dirty = self._unclean
        if not self.read_only:
            self._session_dirty = True
            self._save()  # mark native writer session before opening any collection
        try:
            for ident, entry in self._entries.items():
                if entry["state"] == "ready" and not (self.read_only and self._unclean):
                    self.get(ident)
        except BaseException:
            self.close(preserve_dirty=True)
            raise

    def _load(self):
        marker = read_store_marker(self.root, "index")
        if marker is None:
            raise IdentityMismatchError("index ownership marker missing")
        state = marker["state"]
        self._owner = marker["kb_id"]
        self._unclean = bool(state.get("writer_session_dirty", False))
        if state.get("layout") != "documents-v1":
            raise IncompleteInitError(
                "document index layout missing; explicitly recreate development database"
            )
        self._entries = state.get("collections", {})
        for ident, entry in self._entries.items():
            expected = descriptor(
                entry["descriptor"]["channel"],
                entry["descriptor"].get("space"),
                owner=self._owner,
            )
            if (
                entry.get("descriptor") != expected
                or ident != expected["id"]
                or entry.get("relpath") != "collections/" + ident
            ):
                raise IdentityMismatchError("index collection descriptor mismatch")
            if (
                entry["state"] == "ready"
                and not (self.path / entry["relpath"]).is_dir()
            ):
                raise StorageError("registered collection is missing", retryable=False)

    def _save(self):
        update_store_state(
            self.root,
            "index",
            layout="documents-v1",
            writer_session_dirty=self._session_dirty,
            collections=self._entries,
            collection_created=any(
                e["state"] == "ready" for e in self._entries.values()
            ),
        )

    def _isolated_path(self, source, ident):
        # The pinned native mmap path can write HNSW metadata even on a clean
        # read-only reopen. Never give it the original files in a read-only KB.
        # Byte copies are intentional: hard links would modify the original.
        size = 0
        for path in source.rglob("*"):
            if path.is_symlink():
                raise StorageError("symbolic link in index collection", retryable=False)
            if path.is_file():
                size += path.stat().st_size
        if self._read_copies is None:
            self._read_copies = tempfile.TemporaryDirectory(prefix="zkg-read-index-")
        if self._read_copy_bytes + size > self._read_copy_budget or shutil.disk_usage(
            self._read_copies.name
        ).free < size + (16 << 20):
            raise ResourceExhaustedError("read-only index copy budget exhausted")
        target = Path(self._read_copies.name) / ident
        try:
            shutil.copytree(source, target)
        except OSError as exc:
            raise StorageError(
                "read-only index isolation failed", retryable=False
            ) from exc
        self._read_copy_bytes += size
        return target

    def _open(self, entry):
        schema = native_schema(entry["descriptor"])
        path = self.path / entry["relpath"]
        if self.read_only:
            path = self._isolated_path(path, entry["descriptor"]["id"])
        handle = SearchIndexAdapter(
            path, read_only=self.read_only, config=self.config
        ).open(collection_created=True)
        try:
            if json.loads(str(handle._collection.schema)) != json.loads(str(schema)):
                raise IdentityMismatchError(
                    "native index schema differs from creation intent"
                )
        except BaseException:
            handle.close()
            raise
        return handle

    def ensure(self, value, *, repair=False):
        with self._lock:
            if self._closed:
                raise StorageError("index catalog is closed")
            if self.read_only and self._unclean:
                raise RecoveryRequiredError(
                    "unclean native index session requires writable reopen before index reads"
                )
            ident = value["id"]
            if (
                ident
                != descriptor(value["channel"], value.get("space"), owner=self._owner)[
                    "id"
                ]
            ):
                raise IdentityMismatchError("invalid collection descriptor")
            if ident in self._handles:
                return self._handles[ident]
            entry = self._entries.get(ident)
            if entry is None:
                if self.read_only:
                    raise StorageError("collection not registered", retryable=False)
                entry = {
                    "descriptor": value,
                    "relpath": "collections/" + ident,
                    "state": "creating",
                }
                self._entries[ident] = entry
                self._save()  # intent is durable before native create
                fresh = True
            else:
                fresh = False
                if entry["descriptor"] != value:
                    raise IdentityMismatchError("collection intent mismatch")
            path = self.path / entry["relpath"]
            if entry["state"] != "ready":
                if self.read_only or (not fresh and not repair):
                    raise RecoveryRequiredError(
                        "collection creation requires explicit writable reconciliation"
                    )
                if path.exists():
                    handle = self._open(entry)  # never overwrite an unknown directory
                else:
                    handle = SearchIndexAdapter(
                        path, config=self.config
                    ).create_collection(native_schema(value))
                entry["state"] = "ready"
                try:
                    self._save()
                except Exception as exc:
                    entry["state"] = "creating"
                    handle.close()
                    raise RecoveryRequiredError(
                        "collection created but registration requires reconciliation"
                    ) from exc
                self._handles[ident] = handle
            else:
                if not path.is_dir():
                    raise StorageError(
                        "registered collection is missing", retryable=False
                    )
                handle = self._open(entry)
                self._handles[ident] = handle
            return handle

    def get(self, ident):
        with self._lock:
            if ident not in self._entries:
                raise StorageError(
                    "projection collection is not registered", retryable=False
                )
            entry = self._entries[ident]
            return self.ensure(entry["descriptor"])

    def reconcile(self, ids):
        if self.read_only:
            raise StorageError(
                "index reconciliation requires writable instance", retryable=False
            )
        for ident in ids:
            with self._lock:
                entry = self._entries.get(ident)
                if entry is None:
                    continue
                self.ensure(entry["descriptor"], repair=True)

    def close(self, *, preserve_dirty=False):
        with self._lock:
            if self._closed:
                return
            self._closed = True
            for handle in self._handles.values():
                handle.close()
            self._handles.clear()
            gc.collect()
            if self._read_copies is not None:
                self._read_copies.cleanup()
                self._read_copies = None
                self._read_copy_bytes = 0
            if not self.read_only and not preserve_dirty:
                self._session_dirty = False
                self._save()

    def health(self):
        with self._lock:
            pending = sum(e["state"] != "ready" for e in self._entries.values())
            return {
                "healthy": not pending and not (self.read_only and self._unclean),
                "state": "recovery_required"
                if self.read_only and self._unclean
                else "not_created"
                if not self._entries
                else ("recovery_required" if pending else "ready"),
                "read_only": self.read_only,
                "collections": len(self._entries),
                "pending_creations": pending,
                "unclean_shutdown": self._unclean,
                "native_reads_blocked": self.read_only and self._unclean,
                "readonly_index_mode": "isolated_copy" if self.read_only else "direct",
                "readonly_copy_bytes": self._read_copy_bytes,
            }

    def capabilities(self):
        return {
            "vector": True,
            "fulltext": True,
            "read_only": self.read_only,
            "created": any(e["state"] == "ready" for e in self._entries.values()),
        }
