"""Serialized internal graphdb access; SDK callers never receive a connection."""

from __future__ import annotations

import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Callable, Optional

from ..config import StoreConfig
from ..errors import (
    ErrorStage,
    KnowledgeGraphError,
    RecoveryRequiredError,
    ResourceExhaustedError,
    StorageError,
)


class GraphStoreAdapter:
    def __init__(
        self,
        path: Path,
        *,
        read_only: bool = False,
        config: Optional[StoreConfig] = None,
        cleanup_reserve: int = 4,
    ) -> None:
        self.path = Path(path)
        self.read_only = read_only
        self._config = config or StoreConfig()
        self._conn = None
        self._graphdb = None
        self._lock = threading.RLock()
        self._recovery_required = False
        self._readers = 0
        self._closing = False
        self._condition = threading.Condition(self._lock)
        self._read_epochs = {}
        self._write_epoch = 0
        self._cleanup_reserve = cleanup_reserve

    def open(self) -> GraphStoreAdapter:
        import graphdb

        with self._lock:
            self._graphdb = graphdb
            try:
                self._conn = graphdb.connect(
                    str(self.path),
                    read_only=self.read_only,
                    config={
                        "transaction_mode": self._config.graph_transaction_mode,
                        "transaction_timeout_ms": self._config.graph_transaction_timeout_ms,
                        "max_intermediate_rows": self._config.graph_max_intermediate_rows,
                        "max_retired_versions": self._config.graph_max_retired_versions,
                    },
                )
            except Exception as exc:
                raise StorageError(
                    "failed to open graphdb", stage=ErrorStage.OPEN, cause=exc
                ) from exc
        return self

    def close(self) -> None:
        with self._condition:
            self._closing = True
            while self._readers:
                self._condition.wait()
            if self._conn is not None:
                try:
                    self._conn.close()
                finally:
                    self._conn = None

    @property
    def is_open(self) -> bool:
        return self._conn is not None

    @property
    def recovery_required(self) -> bool:
        return self._recovery_required

    def __enter__(self) -> GraphStoreAdapter:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    def require_usable(self) -> None:
        if self._recovery_required:
            raise RecoveryRequiredError("close, reopen writable and reconcile receipts")

    def quarantine(self) -> None:
        with self._lock:
            self._recovery_required = True

    def _require(self):
        self.require_usable()
        if self._conn is None:
            raise StorageError("graph store is not open", retryable=False)
        return self._conn

    def health(self) -> dict[str, Any]:
        with self._lock:
            try:
                self._require().execute("RETURN 1").fetchall()
                return {
                    "healthy": True,
                    "read_only": self.read_only,
                    "read_references": self._readers,
                }
            except Exception:
                return {
                    "healthy": False,
                    "read_only": self.read_only,
                    "recovery_required": self._recovery_required,
                }

    def capabilities(self) -> dict[str, Any]:
        return {
            "transaction_mode": self._config.graph_transaction_mode,
            "read_only": self.read_only,
            "has_ipc": bool(getattr(self._graphdb, "HAS_IPC", False)),
            "has_cypher_frontend": bool(
                getattr(self._graphdb, "HAS_KUZU_FRONTEND", False)
            ),
            "vector": False,
            "fulltext": False,
            "max_intermediate_rows": self._config.graph_max_intermediate_rows,
            "transaction_timeout_ms": self._config.graph_transaction_timeout_ms,
            "max_retired_versions": self._config.graph_max_retired_versions,
        }

    def read(self, cypher: str, params: Optional[dict] = None) -> list:
        with self._lock:
            try:
                return self._require().execute(cypher, params).fetchall()
            except KnowledgeGraphError:
                raise
            except Exception as exc:
                raise self._map(exc) from exc

    @contextmanager
    def read_txn(self):
        """Internal pinned read. The adapter lock is NOT held across the yield."""
        with self._condition:
            if self._closing:
                raise StorageError("graph store is closing", retryable=False)
            cursor = self._require().cursor()
            self._readers += 1
            self._read_epochs[id(cursor)] = self._write_epoch
        try:
            cursor.execute("BEGIN TRANSACTION READ ONLY")
            try:
                yield cursor
            except BaseException:
                if cursor.in_transaction:
                    cursor.rollback()
                raise
            else:
                cursor.commit()
        except KnowledgeGraphError:
            raise
        except Exception as exc:
            raise self._map(exc) from exc
        finally:
            try:
                cursor.close()
            finally:
                with self._condition:
                    self._readers -= 1
                    del self._read_epochs[id(cursor)]
                    self._condition.notify_all()

    def initialize_schema(self, statements: tuple[str, ...]) -> None:
        """TP DDL requires an idle connection, outside data transactions."""
        with self._lock:
            if self.read_only:
                raise StorageError("schema initialization on read-only store")
            try:
                conn = self._require()
                for statement in statements:
                    conn.execute(statement)
            except KnowledgeGraphError:
                raise
            except Exception as exc:
                raise self._map(exc) from exc

    def write_txn(self, fn: Callable[[Any], Any]) -> Any:
        with self._lock:
            if self.read_only:
                raise StorageError(
                    "write_txn on a read-only graph store",
                    stage=ErrorStage.GRAPH_WRITE,
                    retryable=False,
                )
            try:
                cleanup = bool(getattr(fn, "_zkg_cleanup", False))
                allowance = self._config.graph_max_retired_versions - (
                    0 if cleanup else self._cleanup_reserve
                )
                if (
                    self._read_epochs
                    and self._write_epoch - min(self._read_epochs.values()) >= allowance
                ):
                    raise ResourceExhaustedError(
                        "retained read budget exhausted; release old reads before retry",
                        stage=ErrorStage.GRAPH_WRITE,
                    )
                with self._require().transaction():
                    result = fn(self._conn)
                self._write_epoch += 1
                return result
            except KnowledgeGraphError:
                raise
            except Exception as exc:
                raise self._map(exc) from exc

    def _map(self, exc: BaseException) -> KnowledgeGraphError:
        unknown = getattr(self._graphdb, "CommitOutcomeUnknown", None)
        if unknown is not None and isinstance(exc, unknown):
            self._recovery_required = True
            return RecoveryRequiredError(
                "graphdb commit outcome unknown; close, reopen writable and reconcile",
                stage=ErrorStage.PUBLISH,
                cause=exc,
            )
        if isinstance(exc, KnowledgeGraphError):
            return exc
        if "intermediate row budget exceeded" in str(exc).lower():
            return ResourceExhaustedError(
                "graph intermediate-row budget exceeded",
                stage=ErrorStage.QUERY,
                retryable=False,
                cause=exc,
            )
        if "retired version budget exhausted" in str(exc).lower():
            return ResourceExhaustedError(
                "native retained-version budget exhausted; release old reads",
                stage=ErrorStage.GRAPH_WRITE,
                cause=exc,
            )
        # Native errors can contain query text/parameters: do not expose them.
        return StorageError(
            "graphdb operation failed", stage=ErrorStage.GRAPH_WRITE, cause=exc
        )
