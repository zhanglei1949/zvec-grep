"""Verified, immutable content-addressed snapshots; no automatic reclamation.

Durability uses file fsync, atomic replace and directory fsync on local POSIX
filesystems. It is not a cross-store transaction or a power-loss test result.
"""

from __future__ import annotations

import codecs
import hashlib
import json
import threading
import weakref
from pathlib import Path

from .._persistence import atomic_bytes, sync_directory
from ..errors import ErrorStage, StorageError

_LOCKS: weakref.WeakValueDictionary = weakref.WeakValueDictionary()
_LOCK_GUARD = threading.Lock()


class SnapshotStore:
    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        with _LOCK_GUARD:
            key = str(self.root.resolve())
            self._lock = _LOCKS.setdefault(key, threading.RLock())

    @staticmethod
    def _error(message: str) -> StorageError:
        return StorageError(message, stage=ErrorStage.SNAPSHOT, retryable=False)

    @staticmethod
    def _validate_id(snapshot_id: str) -> None:
        if (
            not isinstance(snapshot_id, str)
            or len(snapshot_id) != 64
            or any(c not in "0123456789abcdef" for c in snapshot_id)
        ):
            raise SnapshotStore._error("invalid snapshot id")

    def _blob_path(self, snapshot_id: str) -> Path:
        self._validate_id(snapshot_id)
        return self.root / snapshot_id[:2] / snapshot_id

    def _meta_path(self, snapshot_id: str) -> Path:
        return self._blob_path(snapshot_id).with_suffix(".meta.json")

    def put(self, data: bytes, encoding: str = "utf-8") -> str:
        if not isinstance(data, (bytes, bytearray)):
            raise self._error("snapshot data must be bytes")
        data = bytes(data)
        try:
            encoding = codecs.lookup(encoding).name
        except (LookupError, TypeError) as exc:
            raise self._error("invalid snapshot encoding") from exc
        sid = hashlib.sha256(data).hexdigest()
        blob = self._blob_path(sid)
        meta = {"encoding": encoding, "byte_length": len(data), "digest": sid}
        try:
            with self._lock:
                if blob.exists():
                    if blob.read_bytes() != data:
                        raise self._error("existing snapshot digest mismatch")
                else:
                    blob.parent.mkdir(parents=True, exist_ok=True)
                    sync_directory(self.root.parent)
                    sync_directory(self.root)
                    atomic_bytes(blob, data)
                metadata = self._meta_path(sid)
                if metadata.exists():
                    if json.loads(metadata.read_bytes()) != meta:
                        raise self._error("snapshot metadata or encoding conflict")
                else:
                    atomic_bytes(metadata, json.dumps(meta).encode("utf-8"))
            return sid
        except (OSError, ValueError) as exc:
            raise self._error("snapshot installation failed") from exc

    def _load(self, snapshot_id: str) -> tuple[bytes, dict]:
        try:
            data = self._blob_path(snapshot_id).read_bytes()
            meta = json.loads(self._meta_path(snapshot_id).read_bytes())
            if (
                not isinstance(meta, dict)
                or meta.get("digest") != snapshot_id
                or meta.get("byte_length") != len(data)
                or hashlib.sha256(data).hexdigest() != snapshot_id
                or codecs.lookup(meta["encoding"]).name != meta["encoding"]
            ):
                raise self._error("snapshot integrity check failed")
            return data, meta
        except (OSError, ValueError, KeyError, LookupError, TypeError) as exc:
            raise self._error("snapshot missing or invalid") from exc

    def exists(self, snapshot_id: str) -> bool:
        self._validate_id(snapshot_id)
        if not self._blob_path(snapshot_id).exists():
            return False
        self._load(snapshot_id)
        return True

    def get(self, snapshot_id: str) -> bytes:
        return self._load(snapshot_id)[0]

    def read_range(self, snapshot_id: str, start: int, end: int) -> bytes:
        data = self.get(snapshot_id)
        if (
            type(start) is not int
            or type(end) is not int
            or start < 0
            or end < start
            or end > len(data)
        ):
            raise self._error("invalid snapshot byte range")
        return data[start:end]

    def encoding(self, snapshot_id: str) -> str:
        return self._load(snapshot_id)[1]["encoding"]

    def add_reference(self, snapshot_id: str) -> None:
        raise NotImplementedError("reference reclamation lands with explicit gc")

    def release_reference(self, snapshot_id: str) -> None:
        raise NotImplementedError("reference reclamation lands with explicit gc")

    def close(self) -> None:
        pass
