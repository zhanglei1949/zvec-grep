"""Storage adapters (design section 7): narrow interfaces over the bases.

These adapters encapsulate base differences and only use public Python APIs;
they do not build a separate database transaction-management layer. They are
internal building blocks: the SDK never exposes a raw writable base connection
or a Cypher entry point that bypasses the publication view.
"""

from __future__ import annotations

from .graph_store import GraphStoreAdapter
from .search_index import SearchIndexAdapter
from .snapshot_store import SnapshotStore

__all__ = [
    "GraphStoreAdapter",
    "SearchIndexAdapter",
    "SnapshotStore",
]
