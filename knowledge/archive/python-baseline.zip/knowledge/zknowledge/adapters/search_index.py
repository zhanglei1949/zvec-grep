"""SearchIndexAdapter: narrow internal interface over zvec (design section 7).

zvec holds rebuildable full-text / vector projections; a hit is only a
candidate. Phase 1 implements the lifecycle plus a minimal write/query smoke
path used by tests; the production projection schema and recall logic land in
Phase 3/4. The KB index store starts "not_created" (no collection) because the
projection schema is not defined yet -- that is a capability state, not an
error. zvec has no public close(), so close() is best-effort (drop reference).
"""

from __future__ import annotations

import threading
from dataclasses import dataclass
from functools import wraps
from pathlib import Path
from typing import Any, Optional, Sequence

from ..config import StoreConfig
from ..errors import ErrorStage, StorageError


@dataclass(frozen=True)
class IndexWriteStatus:
    id: str
    ok: bool
    code: str
    retryable: bool


def _serialized(fn):
    @wraps(fn)
    def call(self, *args, **kwargs):
        with self._io_lock:
            return fn(self, *args, **kwargs)

    return call


class SearchIndexAdapter:
    """Owns a zvec collection handle for one KB process."""

    def __init__(
        self,
        path: Path,
        *,
        read_only: bool = False,
        config: Optional[StoreConfig] = None,
    ) -> None:
        self.path = Path(path)
        self.read_only = read_only
        self._config = config or StoreConfig()
        self._collection = None
        self._created = False
        self._zvec = None
        self._io_lock = threading.RLock()

    # -- lifecycle -------------------------------------------------------
    @_serialized
    def create_collection(self, schema: Any) -> "SearchIndexAdapter":
        """Create and open a new zvec collection at ``path`` (Phase 3 schema)."""
        import zvec

        if self.read_only:
            raise StorageError("create on read-only index", retryable=False)

        self._zvec = zvec
        # zvec.create_and_open requires the collection path to NOT exist; only
        # ensure the parent directory is present and let zvec create the dir.
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            self._collection = zvec.create_and_open(path=str(self.path), schema=schema)
        except Exception as exc:
            raise StorageError(
                f"failed to create zvec collection at {self.path}: {exc}",
                stage=ErrorStage.INDEX,
                cause=exc,
            ) from exc
        self._created = True
        return self

    @_serialized
    def open(self, *, collection_created: bool) -> "SearchIndexAdapter":
        """Open an existing collection, or record not_created when absent."""
        import zvec

        self._zvec = zvec
        self._created = collection_created
        if not collection_created:
            self._collection = None
            return self
        option = zvec.CollectionOption(
            enable_mmap=int(self._config.index_enable_mmap),
            read_only=int(self.read_only),
        )
        try:
            self._collection = zvec.open(path=str(self.path), option=option)
        except Exception as exc:
            raise StorageError(
                f"failed to open zvec collection at {self.path}: {exc}",
                stage=ErrorStage.OPEN,
                cause=exc,
            ) from exc
        return self

    @_serialized
    def close(self) -> None:
        # zvec exposes no public close(); releasing the handle is best-effort
        # and the native collection is reclaimed at process exit.
        self._collection = None

    @property
    def is_created(self) -> bool:
        return self._created

    # -- introspection ---------------------------------------------------
    def health(self) -> dict[str, Any]:
        if not self._created or self._collection is None:
            return {
                "healthy": True,
                "state": "not_created",
                "read_only": self.read_only,
            }
        try:
            return {
                "healthy": True,
                "state": "ready",
                "read_only": self.read_only,
                "doc_count": self._collection.stats.doc_count,
            }
        except Exception as exc:
            return {
                "healthy": False,
                "state": "error",
                "read_only": self.read_only,
                "error": f"{type(exc).__name__}: {exc}",
            }

    def capabilities(self) -> dict[str, Any]:
        return {
            # zvec carries the two retrieval channels graphdb lacks.
            "vector": True,
            "fulltext": True,
            "read_only": self.read_only,
            "created": self._created,
        }

    # -- minimal data path (smoke; production schema is Phase 3/4) -------
    def _require_collection(self):
        if self._collection is None:
            raise StorageError(
                "zvec collection is not created/open",
                stage=ErrorStage.INDEX,
                retryable=False,
            )
        return self._collection

    @_serialized
    def insert(self, docs: Sequence[Any]) -> list[bool]:
        """Insert docs; return per-item ok flags (partial failure visible)."""
        if self.read_only:
            raise StorageError(
                "insert on a read-only index store",
                stage=ErrorStage.INDEX,
                retryable=False,
            )
        collection = self._require_collection()
        try:
            statuses = collection.insert(list(docs))
        except Exception as exc:
            raise StorageError(
                f"zvec insert failed: {exc}", stage=ErrorStage.INDEX, cause=exc
            ) from exc
        return [bool(status.ok()) for status in statuses]

    @_serialized
    def flush(self) -> None:
        collection = self._require_collection()
        try:
            collection.flush()
            if (
                collection.schema.vectors
                and len(list(self.path.rglob("*.proxima")))
                >= self._config.index_compact_threshold
            ):
                # The pinned HNSW writer seals one native block per flush.
                # Merge physical blocks; every versioned SDK projection ID remains.
                count = collection.stats.doc_count
                collection.optimize(self._zvec.OptimizeOption(concurrency=1))
                collection.flush()
                if collection.stats.doc_count != count:
                    raise StorageError(
                        "native compaction changed projection count", retryable=False
                    )
        except Exception as exc:
            raise StorageError(
                "zvec flush/physical compaction failed",
                stage=ErrorStage.INDEX,
                cause=exc,
            ) from exc

    @_serialized
    def compaction_reservation(self) -> int:
        collection = self._require_collection()
        if (
            collection.schema.vectors
            and len(list(self.path.rglob("*.proxima")))
            >= self._config.index_compact_threshold - 1
        ):
            return sum(p.stat().st_size for p in self.path.rglob("*") if p.is_file())
        return 0

    @_serialized
    def query(self, queries: Any, topk: int) -> list[Any]:
        collection = self._require_collection()
        try:
            return list(collection.query(queries=queries, topk=topk))
        except Exception as exc:
            raise StorageError(
                f"zvec query failed: {exc}", stage=ErrorStage.QUERY, cause=exc
            ) from exc

    @_serialized
    def fetch(self, ids: Sequence[str]) -> dict:
        try:
            return self._require_collection().fetch(list(ids), include_vector=True)
        except Exception as exc:
            raise StorageError(
                "index fetch failed", stage=ErrorStage.INDEX, cause=exc
            ) from exc

    @_serialized
    def write_items(self, docs, *, upsert=False):
        if self.read_only:
            raise StorageError("write on read-only index", retryable=False)
        try:
            collection = self._require_collection()
            reused = {}
            pending = list(docs)
            if upsert:
                if len({doc.id for doc in docs}) != len(docs):
                    raise StorageError(
                        "duplicate projection IDs in repair batch", retryable=False
                    )
                existing = collection.fetch(
                    [doc.id for doc in docs], include_vector=True
                )
                for doc in docs:
                    old = existing.get(doc.id)
                    if old is not None:
                        if old.fields != doc.fields or old.vectors != doc.vectors:
                            raise StorageError(
                                "repair cannot overwrite an immutable projection",
                                retryable=False,
                            )
                        reused[doc.id] = IndexWriteStatus(
                            doc.id, True, "OK_REUSED", False
                        )
                pending = [doc for doc in docs if doc.id not in reused]
            statuses = (
                (collection.upsert if upsert else collection.insert)(pending)
                if pending
                else []
            )
            if len(statuses) != len(pending):
                raise StorageError("index item status count mismatch")
            written = tuple(
                IndexWriteStatus(
                    doc.id,
                    bool(status.ok()),
                    str(status.code()),
                    str(status.code()).lower().split(".")[-1]
                    in {
                        "internal_error",
                        "internalerror",
                        "unavailable",
                        "resource_exhausted",
                    },
                )
                for doc, status in zip(pending, statuses)
            )
            if upsert:
                by_id = {status.id: status for status in written}
                return tuple(
                    reused[doc.id] if doc.id in reused else by_id[doc.id]
                    for doc in docs
                )
            return written
        except StorageError:
            raise
        except Exception as exc:
            raise StorageError(
                "index batch outcome requires ID verification",
                stage=ErrorStage.INDEX,
                cause=exc,
            ) from exc

    @_serialized
    def filtered_query(self, queries, *, topk=10, filter=None):
        try:
            return list(
                self._require_collection().query(queries, topk=topk, filter=filter)
            )
        except Exception as exc:
            raise StorageError(
                "filtered index query failed", stage=ErrorStage.QUERY, cause=exc
            ) from exc

    def delete(self, ids: Sequence[str]) -> None:  # pragma: no cover
        raise NotImplementedError(
            "projection delete lands with Phase 3/4 (rebuildable projections)"
        )
