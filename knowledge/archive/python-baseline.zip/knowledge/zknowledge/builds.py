"""Capture-independent document builds, candidate verification and atomic publication."""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import threading
import time
import uuid
from dataclasses import asdict, replace

from .build_models import (
    BuildConfig,
    BuildReconciliation,
    BuildRecord,
    BuildResult,
    Publication,
    PublishedSelection,
    build_result,
)
from .document_processing import (
    DocumentBlock,
    ParseContext,
    ParsedDocument,
    ProcessingBudget,
    SourceSnapshot,
    SourceSpan,
    StageFingerprint,
    parse_document,
    processing_fingerprint,
    stable_digest,
)
from .documents import Segment, segment_document
from .embedding import (
    EmbeddedVector,
    EmbeddingDescriptor,
    EmbeddingInput,
    EmbeddingSpace,
    PrecomputedEmbeddings,
    embed_batch,
)
from .errors import (
    CapabilityNotConfiguredError,
    InvalidInputError,
    KnowledgeGraphError,
    OperationCancelledError,
    ProviderError,
    RecoveryRequiredError,
    ResourceExhaustedError,
    SourceConflictError,
    StorageError,
)
from .execution import _CommittedResult
from .index_catalog import descriptor as index_descriptor
from .models import ContentUnit, Page, SourceRevision, require_text
from .publication_store import ArtifactStore, PublicationStore, fetch, immutable, put
from .source_store import create_immutable
from .source_store import fetch as source_fetch


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _chunks(values, size):
    for offset in range(0, len(values), size):
        yield values[offset : offset + size]


def _parsed(value):
    from .document_processing import Diagnostic

    return ParsedDocument(
        value["revision_id"],
        tuple(
            DocumentBlock(
                b["local_id"], b["kind"], SourceSpan(**b["span"]), b["parent_id"]
            )
            for b in value["blocks"]
        ),
        value["status"],
        tuple(Diagnostic(**d) for d in value["diagnostics"]),
    )


class _Cached:
    def __init__(self, descriptor, value):
        self.descriptor, self.value = descriptor, value

    def describe(self):
        return self.descriptor

    def parse(self, snapshot, context):
        return self.value

    def segment(self, parsed, snapshot, context):
        return self.value


class Builds:
    def __init__(self, kb):
        self._kb = kb
        self._store = PublicationStore(kb._graph)
        self._artifacts = ArtifactStore(kb.root / "artifacts")
        self._active = set()
        self._active_lock = threading.Lock()

    def _snapshot(self, revision_id):
        # Accepted workers drain while the public KB handle is closing.
        revision = SourceRevision(
            **self._kb.sources._store.required("KGRevision", revision_id)
        )
        return SourceSnapshot(
            revision.source_id,
            revision.id,
            revision.snapshot_id,
            self._kb._snapshots.get(revision.snapshot_id),
            revision.encoding,
        )

    def _configuration(self, config):
        parse = processing_fingerprint(
            "parse",
            config.parser.describe(),
            (StageFingerprint("media_type", stable_digest(config.media_type)),),
        )
        segment = processing_fingerprint(
            "segment", config.segmenter.describe(), (parse,)
        )
        embedding = (
            None
            if config.vector == "disabled" or config.embedding is None
            else config.embedding.describe()
        )
        if embedding is not None and not isinstance(embedding, EmbeddingDescriptor):
            raise ProviderError("embedding descriptor type mismatch")
        if config.vector == "required" and embedding is None:
            raise CapabilityNotConfiguredError(
                "required embedding provider is not configured"
            )
        value = {
            "parse": parse.digest,
            "segment": segment.digest,
            "embedding": embedding.fingerprint if embedding else "",
            "space": asdict(embedding.space) if embedding else None,
            "vector": config.vector,
            "media_type": config.media_type,
        }
        return value, parse, segment, embedding

    def submit(self, revision_id, *, config=None, operation_id=None):
        self._kb._require_writable()
        config = config or BuildConfig()
        if not isinstance(config, BuildConfig):
            raise InvalidInputError("build_documents requires BuildConfig")
        operation_id = uuid.uuid4().hex if operation_id is None else operation_id
        require_text(operation_id, "operation_id")
        if len(operation_id) > 256:
            raise InvalidInputError("operation_id exceeds 256 characters")
        revision = self._kb.sources.revision(revision_id)
        configuration, parse_fp, segment_fp, embedding = self._configuration(config)
        request = stable_digest(
            {"revision": revision_id, "configuration": configuration}
        )
        dimension = embedding.space.dimensions if embedding else 0
        estimate = (
            8 * revision.byte_length + config.batch_size * dimension * 64 + (1 << 20)
        )
        if estimate > self._kb._config.admission.candidate_space_bytes:
            raise ResourceExhaustedError(
                "build preparation exceeds admission budget", retryable=False
            )
        with self._kb._graph.read_txn() as conn:
            source = source_fetch(conn, "KGSource", revision.source_id)
            selected = fetch(conn, "KGSourceSelection", revision.source_id)
            view = fetch(conn, "KGPublicationView", "current")
        fixed = {
            "operation_id": operation_id,
            "source_id": revision.source_id,
            "revision_id": revision.id,
            "snapshot_id": revision.snapshot_id,
            "fingerprint": request,
            "configuration": configuration,
            "expected_capture": source["latest_ingestion_id"],
            "expected_publication": selected["publication_id"] if selected else "",
            "expected_space": view["space_id"],
        }

        def run(cancel):
            with self._active_lock:
                if operation_id in self._active:
                    raise SourceConflictError("build operation already active")
                self._active.add(operation_id)
            try:
                return self._run(fixed, config, parse_fp, segment_fp, embedding, cancel)
            finally:
                with self._active_lock:
                    self._active.discard(operation_id)

        handle = self._kb.submit(
            run, kind="build_documents", cost_bytes=estimate, phase="build"
        )
        handle.operation_id = operation_id
        return handle

    def get(self, operation_id):
        self._kb._require_open()
        value = self._store.required("KGBuild", operation_id)
        receipt = self._store.get("KGPublicationReceipt", operation_id)
        return BuildRecord(
            operation_id,
            value["attempt_id"],
            value["source_id"],
            value["revision_id"],
            value["state"],
            value["phase"],
            build_result(receipt) if receipt else None,
            value.get("error_code", ""),
        )

    def projection_writes(self, operation_id, *, limit=100, cursor=None):
        """Writes owned by this attempt; reused projections belong to prior attempts."""
        self._kb._require_open()
        record = self._store.required("KGBuild", operation_id)
        items, next_cursor = self._store.page(
            "KGProjection", record["attempt_id"], limit, cursor
        )
        return Page(items, next_cursor)

    def segments(self, operation_id, *, limit=100, cursor=None):
        self._kb._require_open()
        if type(limit) is not int or not 1 <= limit <= 1000:
            raise InvalidInputError("segment limit must be between 1 and 1000")
        record = self._store.required("KGBuild", operation_id)
        owner = stable_digest(
            [record["revision_id"], record["configuration"]["segment"]]
        )
        units, next_cursor = self._store.page("KGSegment", owner, limit, cursor)
        return Page(tuple(Segment(**u) for u in units), next_cursor)

    def precomputed(self, operation_id):
        """Read the durable caller-supplied vectors; no provider replay."""
        self._kb._require_open()
        record = self._store.required("KGBuild", operation_id)
        if not record.get("precomputed_id"):
            raise CapabilityNotConfiguredError(
                "operation has no frozen precomputed input"
            )
        value = self._artifacts.get(record["precomputed_id"])
        return PrecomputedEmbeddings(
            EmbeddingSpace(**value["space"]),
            tuple(
                EmbeddedVector(v["unit_id"], v["input_digest"], tuple(v["vector"]))
                for v in value["values"]
            ),
        )

    def _space(self, conn, source_id, target):
        view = fetch(conn, "KGPublicationView", "current")
        if target and view["space_id"] and target != view["space_id"]:
            others = conn.execute(
                "MATCH (n:KGSourceSelection) WHERE n.id<>$id RETURN n.payload",
                {"id": source_id},
            ).fetchall()
            if any(json.loads(row[0]).get("vector_ready") for row in others):
                raise SourceConflictError(
                    "multi-source embedding migration requires M2"
                )
        return view

    def _progress(self, record, *, phase=None, state=None):
        if phase:
            record["phase"] = phase
        if state:
            record["state"] = state

        def progress(conn):
            current = fetch(conn, "KGBuild", record["operation_id"])
            if (
                current is None
                or current["attempt_id"] != record["attempt_id"]
                or current["state"] in {"committed", "completed"}
            ):
                raise SourceConflictError("stale build attempt")
            put(
                conn,
                "KGBuild",
                record["operation_id"],
                record,
                owner=record["source_id"],
                state=record["state"],
            )
            put(
                conn,
                "KGBuildAttempt",
                record["attempt_id"],
                record,
                owner=record["operation_id"],
                state=record["state"],
            )

        progress._zkg_cleanup = state in {
            "failed",
            "cancelled",
            "provider_unknown",
            "not_committed",
        }
        self._kb._graph.write_txn(progress)

    def _resources(self, config, extra=0):
        self._kb._pool.reserve_current(extra)
        used = 0
        pending = [self._kb.root]
        while pending:
            # DirEntry reuses directory type information and avoids constructing
            # Paths or issuing two stat calls per retained artifact. Still count
            # every existing file at each checkpoint, including failed/old data.
            with os.scandir(pending.pop()) as entries:
                for entry in entries:
                    try:
                        if entry.is_dir(follow_symlinks=False):
                            pending.append(entry.path)
                        elif entry.is_file():
                            used += entry.stat().st_size
                    except FileNotFoundError:
                        continue  # native atomic renames can race with accounting
        if (
            used + extra > self._kb._config.admission.candidate_space_bytes
            or shutil.disk_usage(self._kb.root).free
            < config.min_free_disk_bytes + extra
        ):
            raise ResourceExhaustedError(
                "build candidate/retained storage budget exhausted"
            )

    def _cache_get(self, ident):
        value = self._store.get("KGStageArtifact", ident)
        return self._artifacts.get(value["artifact_id"]) if value else None

    def _cache_put(self, ident, value, owner, *, accept_existing=False):
        artifact = self._artifacts.put(value)

        def install(conn):
            current = fetch(conn, "KGStageArtifact", ident)
            if current and accept_existing:
                return current["artifact_id"]
            immutable(
                conn, "KGStageArtifact", ident, {"artifact_id": artifact}, owner=owner
            )
            return artifact

        chosen = self._kb._graph.write_txn(install)
        return self._artifacts.get(chosen)

    def _documents(self, record, config, parse_fp, segment_fp, snapshot, context):
        reused = []
        key = stable_digest(
            ["parse", snapshot.revision_id, config.media_type, parse_fp.digest]
        )
        cached = self._cache_get(key)
        if cached is not None:
            parsed = parse_document(
                _Cached(config.parser.describe(), _parsed(cached)), snapshot, context
            )
            reused.append("parse")
        else:
            parsed = parse_document(config.parser, snapshot, context)
            if parsed.status != "complete":
                raise ProviderError("incomplete parse cannot be published")
            self._resources(config, len(snapshot.data) * 8 + len(parsed.blocks) * 512)
            self._cache_put(key, asdict(parsed), record["revision_id"])
        key = stable_digest(
            ["segment", snapshot.revision_id, config.media_type, segment_fp.digest]
        )
        cached = self._cache_get(key)
        if cached is not None:
            units = segment_document(
                _Cached(
                    config.segmenter.describe(), tuple(Segment(**u) for u in cached)
                ),
                parsed,
                snapshot,
                context,
                parse_fingerprint=parse_fp,
            )
            reused.append("segment")
        else:
            units = segment_document(
                config.segmenter, parsed, snapshot, context, parse_fingerprint=parse_fp
            )
            self._resources(config, len(snapshot.data) * 8 + len(units) * 4096)
            self._cache_put(key, [asdict(u) for u in units], record["revision_id"])
        if (
            config.parser.describe() != record["parser_descriptor"]
            or config.segmenter.describe() != record["segment_descriptor"]
        ):
            raise ProviderError("document provider descriptor changed during execution")
        return units, reused

    def _vectors(self, record, config, embedding, units, snapshot, context, reused):
        if embedding is None:
            return None
        provider = config.embedding
        if isinstance(provider, PrecomputedEmbeddings) and {
            v.unit_id for v in provider.values
        } != {u.id for u in units}:
            raise ProviderError(
                "precomputed input must exactly cover the segment manifest"
            )
        values = []
        for offset, batch in enumerate(_chunks(units, config.batch_size)):
            context.check()
            key = stable_digest(
                [
                    "embed",
                    embedding.fingerprint,
                    [(u.id, u.input_digest) for u in batch],
                ]
            )
            cached = self._cache_get(key)
            if cached is not None:
                result = tuple(
                    EmbeddedVector(v["unit_id"], v["input_digest"], tuple(v["vector"]))
                    for v in cached
                )
                # Revalidate cached results using the same framework boundary.
                frozen = PrecomputedEmbeddings(embedding.space, result)
                result = embed_batch(
                    frozen,
                    [
                        EmbeddingInput(
                            u.id, u.input_digest, u.read(snapshot).decode("utf-8")
                        )
                        for u in batch
                    ],
                    context,
                )
                if "embedding" not in reused:
                    reused.append("embedding")
            else:
                record["call"] = {"batch": offset, "input_id": key, "state": "running"}
                self._progress(record, phase="embedding")
                inputs = tuple(
                    EmbeddingInput(
                        u.id, u.input_digest, u.read(snapshot).decode("utf-8")
                    )
                    for u in batch
                )
                try:
                    result = embed_batch(provider, inputs, context)
                except KnowledgeGraphError:
                    record["call"]["state"] = "failed"
                    self._progress(record)
                    raise
                if provider.describe() != embedding:
                    raise ProviderError("embedding configuration changed")
                self._cache_put(key, [asdict(v) for v in result], record["revision_id"])
                record["call"]["state"] = "complete"
                self._progress(record)
            values.extend(result)
        return {v.unit_id: v.vector for v in values}

    @staticmethod
    def _matches(doc, expected):
        if doc.fields != expected["fields"]:
            return False
        vector = expected.get("vector")
        return (
            not doc.vectors
            if vector is None
            else list(doc.vectors.get("embedding", ())) == list(vector)
        )

    def _write_batch(self, handle, expected, config):
        import zvec

        remaining = {value["id"]: value for value in expected}
        statuses = []
        for retry in range(config.write_retries + 1):
            found = handle.fetch(list(remaining))
            for ident, doc in found.items():
                if not self._matches(doc, remaining[ident]):
                    raise StorageError(
                        "immutable projection content mismatch", retryable=False
                    )
                del remaining[ident]
            if not remaining:
                return statuses
            docs = [
                zvec.Doc(
                    id=v["id"],
                    fields=v["fields"],
                    vectors={"embedding": list(v["vector"])}
                    if v.get("vector") is not None
                    else None,
                )
                for v in remaining.values()
            ]
            try:
                written = handle.write_items(docs, upsert=retry > 0)
            except StorageError:
                # The native response can be lost after applying some/all items.
                written = ()
            statuses.extend(
                {"id": s.id, "ok": s.ok, "code": s.code, "retryable": s.retryable}
                for s in written
            )
            verified = handle.fetch(list(remaining))
            for ident, doc in verified.items():
                if not self._matches(doc, remaining[ident]):
                    raise StorageError(
                        "index verification content mismatch", retryable=False
                    )
                del remaining[ident]
            if not remaining:
                return statuses
            if any(not s.ok and not s.retryable and s.id in remaining for s in written):
                raise StorageError("index item permanently rejected", retryable=False)
        raise StorageError("index retry budget exhausted")

    def _projections(
        self, record, config, units, snapshot, space, vectors, reused, context
    ):
        entries = []
        channels = [("text", None)] + (
            [("vector", space)] if vectors is not None else []
        )
        for channel, channel_space in channels:
            value = index_descriptor(
                channel,
                asdict(channel_space) if channel_space else None,
                owner=self._kb.manifest.kb_id,
            )
            if value["id"] not in self._kb._index._entries:
                self._resources(
                    config, 8 << 20
                )  # conservative native creation allowance
            if value["id"] not in record["collections"]:
                record["collections"].append(value["id"])
                self._progress(record, phase="index")
            handle = self._kb._index.ensure(value)
            key = stable_digest(
                [
                    "projection",
                    record["revision_id"],
                    record["configuration"]["segment"],
                    record["configuration"]["media_type"],
                    value["id"],
                    record["configuration"]["embedding"] if channel == "vector" else "",
                ]
            )
            cached = self._cache_get(key)
            if cached is not None:
                self._verify_entries(cached, config.batch_size)
                entries.extend(cached)
                reused.append(channel + "_projection")
                continue
            current = []
            for batch in _chunks(units, config.batch_size):
                context.check()
                self._resources(
                    config,
                    sum(u.end - u.start for u in batch) * 8
                    + ((8 << 20) if channel == "vector" else (1 << 20))
                    + (
                        len(batch) * space.dimensions * 64 if channel == "vector" else 0
                    ),
                )
                expected = []
                for unit in batch:
                    body = unit.read(snapshot).decode("utf-8")
                    fields = {
                        "business_id": unit.id,
                        "source_id": unit.source_id,
                        "revision_id": unit.revision_id,
                        "build_version": record["build_id"],
                        "space_id": space.id if channel == "vector" else "",
                        "content_digest": unit.content_digest,
                        "input_digest": unit.input_digest,
                        "body": body,
                    }
                    ident = stable_digest([record["attempt_id"], channel, unit.id])
                    expected.append(
                        {
                            "id": ident,
                            "collection": value["id"],
                            "channel": channel,
                            "fields": fields,
                            "vector": list(vectors[unit.id])
                            if channel == "vector"
                            else None,
                        }
                    )
                written = self._write_batch(handle, expected, config)
                record["batches"].append({"channel": channel, "items": written})
                self._progress(record)

                def candidate(conn):
                    operation = fetch(conn, "KGBuild", record["operation_id"])
                    if operation["attempt_id"] != record["attempt_id"]:
                        raise SourceConflictError("stale candidate attempt")
                    for item in expected:
                        meta = {
                            "id": item["id"],
                            "collection": item["collection"],
                            "channel": channel,
                            "revision_id": record["revision_id"],
                            "build_id": record["build_id"],
                            "unit_id": item["fields"]["business_id"],
                            "digest": stable_digest(item),
                        }
                        immutable(
                            conn,
                            "KGProjection",
                            item["id"],
                            meta,
                            owner=record["attempt_id"],
                            state="candidate",
                        )

                self._kb._graph.write_txn(candidate)
                current.extend(expected)
            temporary = handle.compaction_reservation()
            if temporary:
                self._resources(config, temporary)
            handle.flush()
            self._verify_entries(current, config.batch_size)
            chosen = self._cache_put(
                key, current, record["revision_id"], accept_existing=True
            )
            if chosen != current:
                # Another builder may have installed a different immutable
                # projection list. Our own list was verified just above.
                self._verify_entries(chosen, config.batch_size)
            entries.extend(chosen)
        return entries

    def _verify_entries(self, entries, batch_size=32):
        for batch in _chunks(entries, batch_size):
            by_collection = {}
            for item in batch:
                by_collection.setdefault(item["collection"], []).append(item)
            for ident, group in by_collection.items():
                handle = self._kb._index.get(ident)
                found = handle.fetch([item["id"] for item in group])
                if len(found) != len(group):
                    raise StorageError(
                        "published/candidate index items missing", retryable=False
                    )
                with self._kb._graph.read_txn() as conn:
                    for item in group:
                        if not self._matches(found[item["id"]], item):
                            raise StorageError(
                                "projection integrity mismatch", retryable=False
                            )
                        meta = fetch(conn, "KGProjection", item["id"])
                        if meta is None or meta["digest"] != stable_digest(item):
                            raise StorageError(
                                "graph projection metadata mismatch", retryable=False
                            )

    def _verify_manifest(self, manifest_id):
        manifest = self._artifacts.get(manifest_id)
        snapshot = self._snapshot(manifest["revision_id"])
        expected_units = {unit["id"]: unit for unit in manifest["units"]}
        if len(expected_units) != len(manifest["units"]):
            raise StorageError("duplicate manifest unit", retryable=False)
        for unit in manifest["units"]:
            Segment(**unit).read(snapshot)
        seen = {"text": set(), "vector": set()}
        ids = set()
        for entry in manifest["projections"]:
            channel = entry["channel"]
            fields = entry["fields"]
            ident = fields["business_id"]
            if (
                channel not in seen
                or ident not in expected_units
                or ident in seen[channel]
                or entry["id"] in ids
            ):
                raise StorageError("invalid projection coverage", retryable=False)
            unit = expected_units[ident]
            if (
                fields["source_id"] != snapshot.source_id
                or fields["revision_id"] != snapshot.revision_id
                or fields["content_digest"] != unit["content_digest"]
                or fields["input_digest"] != unit["input_digest"]
                or fields["body"].encode("utf-8") != Segment(**unit).read(snapshot)
            ):
                raise StorageError(
                    "projection source mapping mismatch", retryable=False
                )
            expected_space = (
                EmbeddingSpace(**manifest["configuration"]["space"]).id
                if channel == "vector"
                else ""
            )
            if fields["space_id"] != expected_space:
                raise StorageError(
                    "projection embedding space mismatch", retryable=False
                )
            seen[channel].add(ident)
            ids.add(entry["id"])
        if seen["text"] != set(expected_units) or seen["vector"] != (
            set(expected_units) if manifest["vector_ready"] else set()
        ):
            raise StorageError(
                "required projection coverage is incomplete", retryable=False
            )
        self._verify_entries(manifest["projections"])
        # Actual FTS/ANN execution with version/space filters, not just fetch.
        import zvec

        for channel in ("text", "vector"):
            first = next(
                (e for e in manifest["projections"] if e["channel"] == channel), None
            )
            if first is None:
                continue
            f = first["fields"]
            expr = " AND ".join(
                f"{name} = '{f[name]}'"
                for name in ("business_id", "revision_id", "build_version", "space_id")
            )
            if channel == "text":
                words = re.findall(r"[\w]+", f["body"])
                if not words:
                    continue
                query = zvec.Query(
                    field_name="body", fts=zvec.Fts(match_string=words[0])
                )
            else:
                query = zvec.Query(field_name="embedding", vector=first["vector"])
            self._kb._index.get(first["collection"]).filtered_query(
                query, topk=1, filter=expr
            )
        return manifest

    def _confirm(self, result):
        with self._kb._graph.read_txn() as conn:
            receipt = fetch(conn, "KGPublicationReceipt", result.operation_id)
            publication = fetch(conn, "KGPublication", result.publication_id)
            if (
                receipt is None
                or build_result(receipt) != result
                or publication is None
                or publication["manifest_id"] != result.manifest_id
                or publication["revision_id"] != result.revision_id
                or publication["build_id"] != result.build_id
            ):
                raise StorageError("publication receipt not visible or inconsistent")
            # A later publication is valid: current selection need not equal this one.
        self._verify_manifest(result.manifest_id)

    def _record_confirmation(self, result):
        def confirm(conn):
            value = fetch(conn, "KGBuild", result.operation_id)
            if (
                value is None
                or value["attempt_id"] != result.attempt_id
                or value["state"] not in {"committed", "completed"}
            ):
                raise StorageError("publication task confirmation mismatch")
            if value["phase"] != "confirmed":
                value["phase"] = "confirmed"
                value["state"] = "completed"
                put(
                    conn,
                    "KGBuild",
                    result.operation_id,
                    value,
                    owner=result.source_id,
                    state="completed",
                )
                put(
                    conn,
                    "KGBuildAttempt",
                    result.attempt_id,
                    value,
                    owner=result.operation_id,
                    state="completed",
                )

        confirm._zkg_cleanup = True
        self._kb._graph.write_txn(confirm)

    def _run(self, fixed, config, parse_fp, segment_fp, embedding, cancel):
        record, committed, prepared = None, False, False
        context = ParseContext(
            ProcessingBudget(
                self._kb._config.admission.candidate_space_bytes // 4, config.max_units
            ),
            cancel,
            time.monotonic() + config.deadline_seconds,
        )
        try:
            context.check()
            previous = self._store.get("KGBuild", fixed["operation_id"])
            if previous and (
                previous["revision_id"] != fixed["revision_id"]
                or previous["fingerprint"] != fixed["fingerprint"]
            ):
                raise SourceConflictError(
                    "build operation is bound to another input/configuration"
                )
            receipt = self._store.get("KGPublicationReceipt", fixed["operation_id"])
            if receipt:
                result = build_result(receipt)
                committed = True
                self._confirm(result)
                self._record_confirmation(result)
                return _CommittedResult(result)
            if previous and previous["state"] not in {
                "failed",
                "cancelled",
                "not_committed",
            }:
                raise RecoveryRequiredError(
                    "build needs explicit reconciliation before retry"
                )
            self._resources(config)
            precomputed_id = ""
            if isinstance(config.embedding, PrecomputedEmbeddings):
                frozen = config.embedding.frozen_manifest()
                self._resources(config, len(json.dumps(frozen).encode()) * 2)
                precomputed_id = self._artifacts.put(frozen)
            record = {
                **(previous or fixed),
                "attempt_id": uuid.uuid4().hex,
                "build_id": stable_digest([fixed["revision_id"], fixed["fingerprint"]]),
                "precomputed_id": precomputed_id,
                "state": "preparing",
                "phase": "prepare",
                "collections": [],
                "batches": [],
                "manifest_id": "",
                "call": {},
                "error_code": "",
            }
            if self._configuration(config)[0] != record["configuration"]:
                raise ProviderError("provider configuration changed since submission")
            # Descriptors are transient guards, never passed to graph JSON encoding.
            parser_descriptor, segment_descriptor = (
                config.parser.describe(),
                config.segmenter.describe(),
            )

            def prepare(conn):
                old = fetch(conn, "KGBuild", fixed["operation_id"])
                if old and (
                    old["fingerprint"] != record["fingerprint"]
                    or old["state"] not in {"failed", "cancelled", "not_committed"}
                ):
                    raise SourceConflictError("build state changed during admission")
                self._space(
                    conn, record["source_id"], embedding.space.id if embedding else ""
                )
                put(
                    conn,
                    "KGBuild",
                    fixed["operation_id"],
                    record,
                    owner=record["source_id"],
                    state="preparing",
                )
                put(
                    conn,
                    "KGBuildAttempt",
                    record["attempt_id"],
                    record,
                    owner=fixed["operation_id"],
                    state="preparing",
                )

            self._kb._graph.write_txn(prepare)
            prepared = True
            snapshot = self._snapshot(record["revision_id"])
            snapshot = replace(snapshot, media_type=config.media_type)
            if len(snapshot.data) > context.budget.max_input_bytes:
                raise ResourceExhaustedError("build input budget exceeded")
            self._progress(record, phase="parse")
            # Keep guards out of durable intent.
            guard = {
                **record,
                "parser_descriptor": parser_descriptor,
                "segment_descriptor": segment_descriptor,
            }
            units, reused = self._documents(
                guard, config, parse_fp, segment_fp, snapshot, context
            )
            self._resources(
                config,
                sum(u.end - u.start for u in units) * 8
                + len(units)
                * (4096 + (embedding.space.dimensions * 64 if embedding else 0)),
            )
            for batch in _chunks(units, config.batch_size):
                context.check()

                def save_units(conn):
                    for unit in batch:
                        immutable(
                            conn,
                            "KGSegment",
                            unit.id,
                            asdict(unit),
                            owner=stable_digest(
                                [record["revision_id"], segment_fp.digest]
                            ),
                            state="prepared",
                        )

                self._kb._graph.write_txn(save_units)
            diagnostics = []
            try:
                vectors = self._vectors(
                    record, config, embedding, units, snapshot, context, reused
                )
            except ProviderError:
                if config.vector != "optional":
                    raise
                record["call"]["state"] = "failed"
                self._progress(record)
                vectors = None
                diagnostics.append("optional_embedding_unavailable")
            if embedding is None and config.vector == "optional":
                diagnostics.append("embedding_not_configured")
            context.check()
            entries = self._projections(
                record,
                config,
                units,
                snapshot,
                embedding.space if embedding else None,
                vectors,
                reused,
                context,
            )
            manifest = {
                "revision_id": snapshot.revision_id,
                "snapshot_id": snapshot.snapshot_id,
                "configuration": record["configuration"],
                "units": [asdict(u) for u in units],
                "projections": entries,
                "collections": record["collections"],
                "vector_ready": vectors is not None,
            }
            self._resources(
                config, len(json.dumps(manifest).encode()) * 2 + len(units) * 4096
            )
            record["manifest_id"] = self._artifacts.put(manifest)
            self._progress(record, phase="validate", state="validated")
            self._verify_manifest(record["manifest_id"])
            context.check()
            vector_ready = vectors is not None
            selected_before = self._store.get("KGSourceSelection", record["source_id"])
            if (
                selected_before
                and selected_before["fingerprint"] == record["fingerprint"]
            ):
                self._confirm(build_result(selected_before))

            def publish(conn):
                context.check()
                current = fetch(conn, "KGBuild", record["operation_id"])
                if (
                    current["attempt_id"] != record["attempt_id"]
                    or current["state"] != "validated"
                ):
                    raise SourceConflictError("stale build cannot publish")
                source = source_fetch(conn, "KGSource", record["source_id"])
                capture = source_fetch(
                    conn, "KGIngestReceipt", source["latest_ingestion_id"]
                )
                selected = fetch(conn, "KGSourceSelection", record["source_id"])
                if (
                    source["latest_ingestion_id"] != record["expected_capture"]
                    or capture["revision_id"] != record["revision_id"]
                ):
                    raise SourceConflictError(
                        "source capture changed before publication"
                    )
                same = bool(
                    selected
                    and selected["fingerprint"] == record["fingerprint"]
                    and selected["vector_ready"] == vector_ready
                )
                if (selected["publication_id"] if selected else "") != record[
                    "expected_publication"
                ] and not same:
                    raise SourceConflictError(
                        "source publication changed before publication"
                    )
                view = self._space(
                    conn,
                    record["source_id"],
                    embedding.space.id if vector_ready else "",
                )
                if (
                    vector_ready
                    and view["space_id"] != record["expected_space"]
                    and not (vector_ready and view["space_id"] == embedding.space.id)
                ):
                    raise SourceConflictError(
                        "embedding coverage changed before publication"
                    )
                if same:
                    original = build_result(selected)
                    result = replace(
                        original,
                        operation_id=record["operation_id"],
                        attempt_id=record["attempt_id"],
                        outcome="unchanged",
                        reason="current_complete_build_matches",
                        reused_stages=tuple(sorted(set(reused))),
                    )
                else:
                    version = view["version"] + 1
                    text_collection = index_descriptor(
                        "text", owner=self._kb.manifest.kb_id
                    )["id"]
                    vector_collection = (
                        index_descriptor(
                            "vector",
                            asdict(embedding.space),
                            owner=self._kb.manifest.kb_id,
                        )["id"]
                        if vector_ready
                        else ""
                    )
                    result = BuildResult(
                        record["operation_id"],
                        record["attempt_id"],
                        record["build_id"],
                        stable_digest(["publication", record["operation_id"]]),
                        record["source_id"],
                        record["revision_id"],
                        record["fingerprint"],
                        record["manifest_id"],
                        version,
                        "partial_processing" if reused else "full_rebuild",
                        "compatible_stage_reuse"
                        if reused
                        else "first_or_changed_document_build",
                        len(units),
                        tuple(sorted(set(reused))),
                        True,
                        vector_ready,
                        embedding.space.id if vector_ready else "",
                        text_collection,
                        vector_collection,
                        not units,
                        True,
                        tuple(diagnostics),
                    )
                    for unit in units:
                        if create_immutable(
                            conn,
                            "KGContentUnit",
                            ContentUnit(
                                unit.id,
                                unit.source_id,
                                unit.revision_id,
                                unit.snapshot_id,
                                unit.processing_fingerprint,
                                unit.start,
                                unit.end,
                                "segment",
                            ),
                            owner=unit.revision_id,
                        ):
                            conn.execute(
                                "MATCH (r:KGRevision) WHERE r.id=$r MATCH (u:KGContentUnit) WHERE u.id=$u CREATE (r)-[:KG_HAS_UNIT]->(u)",
                                {"r": unit.revision_id, "u": unit.id},
                            )
                    immutable(
                        conn,
                        "KGPublication",
                        result.publication_id,
                        {
                            "operation_id": result.operation_id,
                            "manifest_id": result.manifest_id,
                            "revision_id": result.revision_id,
                            "build_id": result.build_id,
                        },
                        owner=result.source_id,
                        version=version,
                    )
                    put(
                        conn,
                        "KGSourceSelection",
                        record["source_id"],
                        asdict(result),
                        owner=self._kb.manifest.kb_id,
                        version=version,
                    )
                    view["version"] = version
                    if vector_ready:
                        view.update(
                            space_id=result.space_id,
                            generation=result.vector_collection,
                        )
                    put(conn, "KGPublicationView", "current", view, version=version)
                immutable(
                    conn,
                    "KGPublicationReceipt",
                    record["operation_id"],
                    asdict(result),
                    owner=record["source_id"],
                    state="committed",
                    version=result.view_version,
                )
                record.update(
                    state="committed", phase="confirm", manifest_id=result.manifest_id
                )
                put(
                    conn,
                    "KGBuild",
                    record["operation_id"],
                    record,
                    owner=record["source_id"],
                    state="committed",
                )
                put(
                    conn,
                    "KGBuildAttempt",
                    record["attempt_id"],
                    record,
                    owner=record["operation_id"],
                    state="committed",
                )
                return result

            with self._kb._publish_lock:
                result = self._kb._graph.write_txn(publish)
                committed = True
            self._confirm(result)
            self._record_confirmation(result)
            return _CommittedResult(result)
        except BaseException as exc:
            if committed or self._kb._graph.recovery_required:
                self._kb._graph.quarantine()
                raise RecoveryRequiredError(
                    "build outcome requires writable reopen and receipt reconciliation",
                    detail={"operation_id": fixed["operation_id"]},
                ) from exc
            if prepared and record is not None:
                record["error_code"] = (
                    exc.code if isinstance(exc, KnowledgeGraphError) else "unexpected"
                )
                state = (
                    "provider_unknown"
                    if record.get("call", {}).get("state") == "running"
                    else (
                        "cancelled"
                        if isinstance(exc, OperationCancelledError)
                        else "failed"
                    )
                )
                try:
                    self._progress(record, state=state)
                except SourceConflictError:
                    pass  # a newer attempt owns the record
            raise

    def reconcile(self, operation_id):
        self._kb._require_writable()
        with self._active_lock:
            if operation_id in self._active:
                raise SourceConflictError("cannot reconcile active build")
        with self._kb._publish_lock:
            record = self._store.required("KGBuild", operation_id)
            self._kb._index.reconcile(record.get("collections", ()))
            receipt = self._store.get("KGPublicationReceipt", operation_id)
            if receipt:
                result = build_result(receipt)
                try:
                    self._confirm(result)
                    self._record_confirmation(result)
                except BaseException:
                    self._kb._graph.quarantine()
                    raise
                return BuildReconciliation(operation_id, "committed", result)
            if record.get("call", {}).get("state") == "running":
                saved = self._cache_get(record["call"]["input_id"])
                if saved is None:
                    self._progress(record, state="provider_unknown")
                    return BuildReconciliation(operation_id, "provider_unknown")
                PrecomputedEmbeddings(
                    EmbeddingSpace(**record["configuration"]["space"]),
                    tuple(
                        EmbeddedVector(
                            v["unit_id"], v["input_digest"], tuple(v["vector"])
                        )
                        for v in saved
                    ),
                )
                record["call"]["state"] = "complete"
            state = "not_committed"
            if record.get("manifest_id"):
                try:
                    self._verify_manifest(record["manifest_id"])
                except StorageError:
                    state = "candidate_incomplete"
            self._progress(record, state="not_committed")
            return BuildReconciliation(operation_id, state)

    def health(self):
        try:
            with self._kb._graph.read_txn() as conn:
                pending = conn.execute(
                    "MATCH (n:KGBuild) WHERE n.state='preparing' OR n.state='validated' OR n.state='provider_unknown' OR n.state='committed' RETURN count(n)"
                ).fetchall()[0][0]
            with self._active_lock:
                active = len(self._active)
            return {"pending_reconciliation": pending, "active": active}
        except KnowledgeGraphError:
            return {
                "pending_reconciliation": None,
                "active": len(self._active),
                "inspection_unavailable": True,
            }


class Publications:
    def __init__(self, kb):
        self._kb = kb

    def get(self, publication_id):
        self._kb._require_open()
        with self._kb._graph.read_txn() as conn:
            publication = fetch(conn, "KGPublication", publication_id)
            if publication is None:
                from .errors import NotFoundError

                raise NotFoundError("publication not found")
            result = build_result(
                fetch(conn, "KGPublicationReceipt", publication["operation_id"])
            )
        return Publication(publication_id, result)

    def current(self, source_id):
        self._kb._require_open()
        value = self._kb.builds._store.get("KGSourceSelection", source_id)
        if not value:
            return None
        return PublishedSelection(
            value["source_id"],
            value["revision_id"],
            value["publication_id"],
            value["view_version"],
            value["text_ready"],
            value["vector_ready"],
            value["space_id"],
        )
