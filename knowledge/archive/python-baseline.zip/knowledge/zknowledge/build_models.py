"""Document build API values. Capture receipts remain unchanged."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .documents import MarkdownParser, SectionSegmenter
from .errors import InvalidInputError


@dataclass(frozen=True)
class BuildConfig:
    parser: Any = field(default_factory=MarkdownParser)
    segmenter: Any = field(default_factory=SectionSegmenter)
    embedding: Any = None
    vector: str = "optional"
    media_type: str = "text/markdown"
    batch_size: int = 32
    max_units: int = 20000
    deadline_seconds: float = 60.0
    min_free_disk_bytes: int = 16 << 20
    write_retries: int = 2

    def __post_init__(self):
        if self.vector not in {
            "disabled",
            "optional",
            "required",
        } or self.media_type not in {"text/markdown", "text/plain"}:
            raise InvalidInputError("invalid document build target")
        if (
            type(self.batch_size) is not int
            or not 1 <= self.batch_size <= 256
            or type(self.max_units) is not int
            or self.max_units < 1
            or not 0 < self.deadline_seconds <= 3600
            or type(self.min_free_disk_bytes) is not int
            or self.min_free_disk_bytes < 0
            or type(self.write_retries) is not int
            or not 0 <= self.write_retries <= 5
        ):
            raise InvalidInputError("invalid build budgets")


@dataclass(frozen=True)
class BuildResult:
    operation_id: str
    attempt_id: str
    build_id: str
    publication_id: str
    source_id: str
    revision_id: str
    fingerprint: str
    manifest_id: str
    view_version: int
    outcome: str
    reason: str
    unit_count: int
    reused_stages: tuple[str, ...]
    text_ready: bool
    vector_ready: bool
    space_id: str
    text_collection: str
    vector_collection: str
    indexed_empty: bool = False
    search_ready: bool = True
    diagnostics: tuple[str, ...] = ()


def build_result(payload):
    return BuildResult(
        **{
            **payload,
            "reused_stages": tuple(payload["reused_stages"]),
            "diagnostics": tuple(payload.get("diagnostics", ())),
        }
    )


@dataclass(frozen=True)
class BuildRecord:
    operation_id: str
    attempt_id: str
    source_id: str
    revision_id: str
    state: str
    phase: str
    result: BuildResult | None = None
    error_code: str = ""


@dataclass(frozen=True)
class BuildReconciliation:
    operation_id: str
    state: str
    result: BuildResult | None = None


@dataclass(frozen=True)
class Publication:
    id: str
    result: BuildResult


@dataclass(frozen=True)
class PublishedSelection:
    source_id: str
    revision_id: str
    publication_id: str
    view_version: int
    text_ready: bool
    vector_ready: bool
    space_id: str
