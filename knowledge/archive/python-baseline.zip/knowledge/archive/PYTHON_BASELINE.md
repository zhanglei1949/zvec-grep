# 冻结 Python 基线

本页保留 Python Phase 1–3 的运行说明和历史结论；命令仍从仓库的 `knowledge/` 目录执行。当前开发入口见 [Rust 组件](../../rust/crates/zg-knowledge/README.md)。

本目录是迁入 zvec-grep 的 Python 基线，设计、SDK、测试和 Spike 保留原有结构，独立于 TypeScript/Rust 搜索流程运行。以下命令均从 `knowledge/` 执行。迁移范围、环境准备和新目录验收见 [迁移记录](../MIGRATION.md)。

面向应用开发者的嵌入式知识构建、维护与检索框架。

当前已实现 Phase 1 生命周期/适配层、Phase 2 来源摄入，以及 Phase 3 文档构建与发布：Markdown/纯文本解析、独立分段、预计算向量或显式测试提供者、全文/向量候选、图内原子发布、独立只读确认与显式回执核对。公共 search、RRF、证据查询由 Phase 4 交付；实体关系抽取、真实模型和 CLI 按后续阶段实现。

Spike-1/2 在确认的本地开发档位下判定阶段 A 为 Go；该代理 Schema 结论与 Phase 3 实际 SDK 的测量分别记录，详见 [底座实测报告](../spikes/validation/BASE_REPORT.md) 与 [Phase 3 验收报告](../spikes/phase3/PHASE3_REPORT.md)。能力边界、物理映射、资源配置和已发现的原生限制见 [Phase 3 契约](../spikes/phase3/CONTRACTS.md)。

复用 Spike-0 已构建并安装到 `.venv` 的固定来源 graphdb/zvec wheel，不自动升级或重编译底座。Phase 3 新增纯 Python/MIT 依赖 `markdown-it-py==4.0.0` 与 `mdurl==0.1.2`，版本固定在 pyproject.toml；模型及权重由调用方准备。原生依赖见 [Spike-0 报告](../spikes/spike_0/SPIKE0_REPORT.md)。

```bash
.venv/bin/python -m examples.phase2_ingest
.venv/bin/python -m examples.phase3_build
.venv/bin/python -m spikes.spike_1.source_probe
.venv/bin/python -m unittest discover -s tests -t . -v
```

示例默认使用临时目录，也可通过 `--root NEW_DIRECTORY` 保留新建库；非空目录不会被覆盖。保持 `schema_version=1`，Phase 3 以 CREATE 追加表并采用双 collection 布局；当前开发期假定没有历史业务库，旧开发库显式重建，不在 open 中迁移或补表。来源捕获的 `IngestResult.search_ready` 继续为 false；构建的 `BuildResult.search_ready` 只表示该发布的必需索引已确认，`capabilities.search_api_available=false`。

固定原生索引的只读打开可能改写向量文件；正常只读实例使用受预算限制的临时字节副本，关闭后清理，原库不被修改。异常退出后需可写重开并显式核对，此前只读实例仅检查图/任务元数据。已有 ID 的补写先 fetch 并复用相同内容，拒绝覆盖不同内容，详见上述契约及报告。

- [Phase 2 验收记录与边界](../spikes/spike_1/PHASE2_REPORT.md)
- [Phase 3 示例](../examples/phase3_build.py) 与 [验收报告](../spikes/phase3/PHASE3_REPORT.md)
- [总体设计与核心接口](../knowledge-system-design.md)
- [交付计划](../knowledge-delivery-plan.md)
- [项目边界](../knowledge-project-boundary.md)

底座试验复现（需已有 Spike-0 原生测试构建缓存，输出使用新目录）：

```bash
.venv/bin/python -m spikes.validation.native --build
.venv/bin/python -m spikes.validation.run --output .artifacts/spikes/new-validation-run
```

原生测试按 14 并发编译目标及其所需静态库，不重建或安装 wheel；不传 `--build` 可直接执行已构建测试。
