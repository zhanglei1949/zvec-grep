"""Synthetic multi-kind KG with current/candidate/retained physical versions."""

from __future__ import annotations

import time
from pathlib import Path

from spikes.spike_1.contracts import open_graph
from spikes.validation.common import (
    csv_copy,
    disk_bytes,
    parallel_timings,
    peak_rss,
    timings,
)


def rows(n, p, *, revisions=None, include_base=True):
    chunks = p["chunks_per_source_revision"]
    versions = p["retained_revisions"]
    body = "knowledge " + "x" * (p["chunk_bytes"] - 10)
    for source in range(n):
        owner = f"s{source}"
        if include_base:
            yield (owner, "source", owner, -1, "selected-r0", "")
            yield (f"e{source}", "entity", owner, -1, "shared", "Atlas")
            if source % 10 == 0:
                yield (
                    f"c{source}",
                    "correction",
                    owner,
                    -1,
                    "active",
                    "replacement with manual support",
                )
        for rev in range(versions) if revisions is None else revisions:
            state = p["revision_roles"][rev]
            yield (f"{owner}r{rev}", "revision", owner, rev, state, "")
            for chunk in range(chunks):
                stem = f"{owner}r{rev}u{chunk}"
                yield (stem, "chunk", owner, rev, state, body)
                yield (
                    stem + "e",
                    "evidence",
                    owner,
                    rev,
                    state,
                    f"bytes:{chunk * p['chunk_bytes']}:{(chunk + 1) * p['chunk_bytes']}",
                )
                yield (
                    stem + "a",
                    "assertion",
                    owner,
                    rev,
                    state,
                    "supports;version=2.0;polarity=positive",
                )
                yield (
                    stem + "p",
                    "support",
                    owner,
                    rev,
                    state,
                    "independent primary support",
                )
                yield (
                    stem + "q",
                    "support",
                    f"s{(source + 1) % n}",
                    rev,
                    state,
                    "independent secondary support",
                )


def edges(n, p, *, revisions=None, include_base=True):
    for source in range(n):
        owner = f"s{source}"
        if include_base:
            yield owner, f"e{source}", "describes"
            if source % 10 == 0:
                yield f"c{source}", f"e{source}", "corrects"
        for rev in range(p["retained_revisions"]) if revisions is None else revisions:
            r = f"{owner}r{rev}"
            yield owner, r, "has_revision"
            for chunk in range(p["chunks_per_source_revision"]):
                stem = f"{r}u{chunk}"
                for a, b, kind in (
                    (r, stem, "has_unit"),
                    (stem, stem + "e", "has_evidence"),
                    (stem + "a", f"e{source}", "subject"),
                    (stem + "p", stem + "a", "supports"),
                    (stem + "q", stem + "a", "supports"),
                    (stem + "p", stem + "e", "cites"),
                    (stem + "q", stem + "e", "cites"),
                    (stem + "p", owner, "from_source"),
                    (stem + "q", f"s{(source + 1) % n}", "from_source"),
                ):
                    yield a, b, kind


def run(root, p, n):
    root = Path(root)
    path = root / "graph"
    build_start = time.perf_counter()
    c = open_graph(path)
    try:
        c.execute(
            "CREATE NODE TABLE KG(id STRING PRIMARY KEY, kind STRING, source STRING, revision INT64, state STRING, body STRING)"
        )
        c.execute("CREATE REL TABLE LINK(FROM KG TO KG, kind STRING)")
        node_count, node_csv = csv_copy(
            c,
            root,
            "KG",
            ("id", "kind", "source", "revision", "state", "body"),
            rows(n, p),
        )
        edge_count, edge_csv = csv_copy(
            c, root, "LINK", ("from", "to", "kind"), edges(n, p)
        )
        build_seconds = time.perf_counter() - build_start
        assert c.execute("MATCH (n:KG) RETURN count(n)").fetchall()[0][0] == node_count
        assert (
            c.execute("MATCH (:KG)-[r:LINK]->(:KG) RETURN count(r)").fetchall()[0][0]
            == edge_count
        )
        kinds = dict(c.execute("MATCH (n:KG) RETURN n.kind,count(n)").fetchall())
        assert (
            kinds["source"] == n
            and kinds["chunk"]
            == n * p["retained_revisions"] * p["chunks_per_source_revision"]
        )
        query = "MATCH (s:KG)-[:LINK]->(r:KG)-[:LINK]->(u:KG) WHERE s.id=$id AND r.kind='revision' AND r.state='current' RETURN u.id,u.state LIMIT 10"
        result = c.execute(query, {"id": "s0"}).fetchall()
        assert len(result) == p["chunks_per_source_revision"]
        latency = timings(lambda: c.execute(query, {"id": "s0"}).fetchall(), p)

        def reader_factory():
            reader = c.cursor()
            return (
                lambda: reader.execute(query, {"id": "s0"}).fetchall(),
                reader.close,
            )

        concurrent = parallel_timings(reader_factory, p)
        metrics = c.storage_metrics
    finally:
        c.close()
    start = time.perf_counter()
    c = open_graph(path, True)
    try:
        assert c.execute("MATCH (n:KG) RETURN count(n)").fetchall()[0][0] == node_count
        reopen = time.perf_counter() - start
    finally:
        c.close()
    measured = {
        "sources": n,
        "nodes": node_count,
        "edges": edge_count,
        "kind_counts": kinds,
        "logical_input_bytes": n
        * p["retained_revisions"]
        * p["chunks_per_source_revision"]
        * p["chunk_bytes"],
        "fixture_csv_bytes": node_csv + edge_csv,
        "native_disk_bytes": disk_bytes(path),
        "peak_rss_bytes": peak_rss(),
        "build_seconds": build_seconds,
        "readonly_reopen_seconds": reopen,
        "bounded_graph_query": latency,
        "two_reader_graph_query": concurrent,
        "storage_metrics": metrics,
        "held_native_readers_during_build": 0,
    }
    failures = []
    for key, actual, limit in (
        ("rss", measured["peak_rss_bytes"], p["rss_limit_bytes"]),
        ("build", build_seconds, p["build_limit_seconds"]),
        ("reopen", reopen, p["reopen_limit_seconds"]),
        ("p95", latency["p95_ms"], p["query_p95_limit_ms"]),
        ("concurrent_p95", concurrent["p95_ms"], p["query_p95_limit_ms"]),
    ):
        if actual > limit:
            failures.append({"metric": key, "actual": actual, "limit": limit})
    return {
        "passed": not failures,
        "measurements": measured,
        "threshold_failures": failures,
        "boundary": "synthetic quiescent graph; reader pin tested separately; no capacity extrapolation",
    }


def reader_overlap(root, p, n):
    """Build candidate INSERTs while two native readers retain populated roots."""
    import threading

    root = Path(root)
    path = root / "graph"
    c = open_graph(path)
    start = time.perf_counter()
    readers = []
    started = threading.Event()
    done = threading.Event()
    errors = []
    counts = {}
    try:
        c.execute(
            "CREATE NODE TABLE KG(id STRING PRIMARY KEY, kind STRING, source STRING, revision INT64, state STRING, body STRING)"
        )
        c.execute("CREATE REL TABLE LINK(FROM KG TO KG, kind STRING)")
        initial = [0, 2]
        base_nodes, _ = csv_copy(
            c,
            root,
            "KG",
            ("id", "kind", "source", "revision", "state", "body"),
            rows(n, p, revisions=initial),
            tag="-base",
        )
        base_edges, _ = csv_copy(
            c,
            root,
            "LINK",
            ("from", "to", "kind"),
            edges(n, p, revisions=initial),
            tag="-base",
        )
        for _ in range(p["concurrent_readers"]):
            r = c.cursor()
            r.execute("BEGIN TRANSACTION READ ONLY")
            assert (
                r.execute("MATCH (n:KG) RETURN count(n)").fetchall()[0][0] == base_nodes
            )
            readers.append(r)
        before_rss = peak_rss()

        def append():
            try:
                counts["nodes"], _ = csv_copy(
                    c,
                    root,
                    "KG",
                    ("id", "kind", "source", "revision", "state", "body"),
                    rows(n, p, revisions=[1], include_base=False),
                    tag="-candidate",
                    before_execute=started.set,
                )
                counts["edges"], _ = csv_copy(
                    c,
                    root,
                    "LINK",
                    ("from", "to", "kind"),
                    edges(n, p, revisions=[1], include_base=False),
                    tag="-candidate",
                )
            except BaseException as exc:
                errors.append(type(exc).__name__ + ": " + str(exc))
            finally:
                done.set()
                started.set()

        thread = threading.Thread(target=append, daemon=True)
        thread.start()
        assert started.wait(10)
        time.sleep(0.05)
        overlapped = not done.is_set()
        for r in readers:
            assert (
                r.execute("MATCH (n:KG) RETURN count(n)").fetchall()[0][0] == base_nodes
            )
        thread.join(p["build_limit_seconds"])
        assert done.is_set() and not errors, errors
        # Publish a selection update while both old Read snapshots remain held.
        with c.transaction():
            c.execute("MATCH (n:KG) WHERE n.id='s0' SET n.state='selected-r1'")
        for r in readers:
            assert (
                r.execute("MATCH (n:KG) RETURN count(n)").fetchall()[0][0] == base_nodes
            )
            assert r.execute(
                "MATCH (n:KG) WHERE n.id='s0' RETURN n.state"
            ).fetchall() == [("selected-r0",)]
        assert c.execute("MATCH (n:KG) WHERE n.id='s0' RETURN n.state").fetchall() == [
            ("selected-r1",)
        ]
        held_rss = peak_rss()
        for r in readers:
            r.rollback()
            r.close()
        readers = []
        build = time.perf_counter() - start
        assert (
            c.execute("MATCH (n:KG) RETURN count(n)").fetchall()[0][0]
            == base_nodes + counts["nodes"]
        )
        assert (
            c.execute("MATCH (:KG)-[r:LINK]->(:KG) RETURN count(r)").fetchall()[0][0]
            == base_edges + counts["edges"]
        )
    finally:
        for r in readers:
            r.rollback()
            r.close()
        c.close()
    begin = time.perf_counter()
    c = open_graph(path, True)
    try:
        assert (
            c.execute("MATCH (n:KG) RETURN count(n)").fetchall()[0][0]
            == base_nodes + counts["nodes"]
        )
    finally:
        c.close()
    reopen = time.perf_counter() - begin
    metrics = {
        "sources": n,
        "initial_current_and_retained_nodes": base_nodes,
        "candidate_nodes": counts["nodes"],
        "total_nodes": base_nodes + counts["nodes"],
        "total_edges": base_edges + counts["edges"],
        "retained_native_readers": p["concurrent_readers"],
        "candidate_started_while_readers_alive": True,
        "candidate_still_running_at_sample": overlapped,
        "old_read_counts_stable": True,
        "rss_peak_before_candidate": before_rss,
        "rss_peak_before_reader_release": held_rss,
        "peak_rss_bytes": peak_rss(),
        "build_seconds": build,
        "readonly_reopen_seconds": reopen,
        "disk_bytes": disk_bytes(path),
    }
    failures = []
    for key, value, limit in (
        ("rss", metrics["peak_rss_bytes"], p["rss_limit_bytes"]),
        ("build", build, p["build_limit_seconds"]),
        ("reopen", reopen, p["reopen_limit_seconds"]),
    ):
        if value > limit:
            failures.append({"metric": key, "actual": value, "limit": limit})
    return {
        "passed": not failures,
        "measurements": metrics,
        "threshold_failures": failures,
        "boundary": "candidate bulk construction and selection Update overlap with explicit old READ ONLY snapshots",
    }
