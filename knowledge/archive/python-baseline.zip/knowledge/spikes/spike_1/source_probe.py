"""Minimal source-write gate, not full Spike-1 or Stage A Go.

Run: .venv/bin/python -m spikes.spike_1.source_probe
No dependency download or rebuild; only temporary native databases are written.
"""

from __future__ import annotations

import json
import platform
import tempfile
from pathlib import Path

from zknowledge.adapters import GraphStoreAdapter
from zknowledge.errors import RecoveryRequiredError, StorageError
from zknowledge.manifest import default_base_compat
from zknowledge.preflight import check_base_provenance


def run() -> dict:
    import graphdb

    provenance = check_base_provenance()
    if not provenance.ok:
        raise RuntimeError(provenance.reason())
    checks = []
    with tempfile.TemporaryDirectory(prefix="zkg-source-probe-") as d:
        path = Path(d) / "graph"
        graph = GraphStoreAdapter(path).open()
        try:
            graph.initialize_schema(
                (
                    "CREATE NODE TABLE Probe(id STRING PRIMARY KEY, value STRING)",
                    "CREATE NODE TABLE Receipt(id STRING PRIMARY KEY, value STRING)",
                )
            )

            def insert(conn):
                if not conn.execute(
                    "MATCH (n:Probe) WHERE n.id=$id RETURN n.id", {"id": "source"}
                ).fetchall():
                    conn.execute(
                        "CREATE (:Probe {id:$id, value:$value})",
                        {"id": "source", "value": "v1"},
                    )

            graph.write_txn(insert)
            graph.write_txn(insert)
            assert graph.read("MATCH (n:Probe) RETURN count(n)")[0][0] == 1
            assert (
                graph.read("MATCH (n:Probe) WHERE n.id='source' RETURN n.value")[0][0]
                == "v1"
            )
            checks.append(
                {
                    "name": "stable_id_and_same_connection_read_visibility",
                    "kind": "real_base",
                    "passed": True,
                }
            )

            def rollback(conn):
                conn.execute("MATCH (n:Probe) WHERE n.id='source' SET n.value='bad'")
                conn.execute("CREATE (:Receipt {id:'rollback', value:'bad'})")
                raise ValueError("injected transaction-body failure")

            try:
                graph.write_txn(rollback)
            except StorageError:
                pass
            else:
                raise AssertionError("rollback did not raise")
            assert (
                graph.read("MATCH (n:Probe) WHERE n.id='source' RETURN n.value")[0][0]
                == "v1"
            )
            assert graph.read("MATCH (n:Receipt) RETURN count(n)")[0][0] == 0
            checks.append(
                {
                    "name": "atomic_data_transaction_rollback",
                    "kind": "real_base_with_body_failure",
                    "passed": True,
                }
            )

            def commit(conn):
                conn.execute("MATCH (n:Probe) WHERE n.id='source' SET n.value='v2'")
                conn.execute("CREATE (:Receipt {id:'op-1', value:'attempt-1'})")

            graph.write_txn(commit)
            # Actual commit; only acknowledgement loss is injected.
            failure = graph._map(graphdb.CommitOutcomeUnknown("injected response loss"))
            assert isinstance(failure, RecoveryRequiredError)
            try:
                graph.read("RETURN 1")
            except RecoveryRequiredError:
                pass
            else:
                raise AssertionError("quarantined graph remained usable")
            graph.close()
            graph = GraphStoreAdapter(path).open()
            assert (
                graph.read("MATCH (n:Probe) WHERE n.id='source' RETURN n.value")[0][0]
                == "v2"
            )
            assert (
                graph.read("MATCH (n:Receipt) WHERE n.id='op-1' RETURN n.value")[0][0]
                == "attempt-1"
            )
            checks.append(
                {
                    "name": "receipt_reconciliation_after_reopen",
                    "kind": "injected_response_loss_real_commit_and_reopen",
                    "passed": True,
                }
            )
            graph.close()
            graph = GraphStoreAdapter(path, read_only=True).open()
            assert graph.read("MATCH (n:Receipt) RETURN count(n)")[0][0] == 1
            checks.append(
                {"name": "readonly_reopen", "kind": "real_base", "passed": True}
            )
        finally:
            graph.close()
    return {
        "scope": "Phase 2 minimum source-write gate",
        "passed": True,
        "platform": platform.platform(),
        "python": platform.python_version(),
        "base_compat": default_base_compat().to_dict(),
        "checks": checks,
        "not_verified": [
            "real CommitOutcomeUnknown fault window",
            "process-kill or power-loss recovery",
            "independent concurrent reader visibility",
            "scale/RSS ceiling",
            "cross-process admission",
            "zvec/effective-view performance",
        ],
        "stage_a_go": False,
    }


if __name__ == "__main__":
    print(json.dumps(run(), ensure_ascii=False, indent=2))
