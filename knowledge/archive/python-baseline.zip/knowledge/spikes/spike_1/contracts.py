"""Native graphdb contracts and deterministic kill/reopen children."""

from __future__ import annotations

import json
import subprocess
import sys
import time
from contextlib import contextmanager
from pathlib import Path

from spikes.validation.common import ROOT, tree_digest


def config():
    from spikes.validation.common import profile

    return profile().get("graph_config", {"transaction_mode": "tp"})


def open_graph(path, readonly=False):
    import graphdb

    return graphdb.connect(str(path), read_only=readonly, config=config())


@contextmanager
def read_transaction(c):
    c.execute("BEGIN TRANSACTION READ ONLY")
    try:
        yield c
    except BaseException:
        if c.in_transaction:
            c.rollback()
        raise
    else:
        c.commit()


def control_schema(c):
    c.execute(
        "CREATE NODE TABLE Control(id STRING PRIMARY KEY, version INT64, selected STRING, invalid STRING)"
    )
    c.execute(
        "CREATE NODE TABLE Receipt(id STRING PRIMARY KEY, version INT64, selected STRING)"
    )
    c.execute("CREATE NODE TABLE SupportEpoch(id STRING PRIMARY KEY, version INT64)")
    c.execute("CREATE (:SupportEpoch {id:'support',version:0})")
    c.execute("CREATE NODE TABLE FactVersion(id STRING PRIMARY KEY, body STRING)")
    with c.transaction():
        for version in range(20):
            c.execute(
                "CREATE (:FactVersion {id:$id,body:$body})",
                {"id": f"v{version}", "body": f"knowledge-v{version}"},
            )
    c.execute("CREATE (:Control {id:'root',version:0,selected:'v0',invalid:'none'})")


def publish(
    c, operation, expected, target, *, cancelled=False, fail=False, expected_support=0
):
    # Experimental coordinator, not a production SDK publish interface.
    with c.transaction():
        current = c.execute(
            "MATCH (n:Control) WHERE n.id='root' RETURN n.version", {}
        ).fetchall()[0][0]
        support_epoch = c.execute("MATCH (n:SupportEpoch) RETURN n.version").fetchall()[
            0
        ][0]
        if current != expected or support_epoch != expected_support:
            raise ValueError("read_set_conflict")
        if cancelled:
            raise ValueError("cancelled_before_publish")
        c.execute(
            "MATCH (n:Control) WHERE n.id='root' SET n.version=$v,n.selected=$s,n.invalid='old-description'",
            {"v": expected + 1, "s": target},
        )
        c.execute(
            "CREATE (:Receipt {id:$op,version:$v,selected:$s})",
            {"op": operation, "v": expected + 1, "s": target},
        )
        if fail:
            raise ValueError("injected_transaction_body_failure")


def state(c):
    root = c.execute(
        "MATCH (n:Control) WHERE n.id='root' RETURN n.version,n.selected,n.invalid"
    ).fetchall()[0]
    receipts = c.execute(
        "MATCH (n:Receipt) RETURN n.id,n.version,n.selected ORDER BY n.id"
    ).fetchall()
    return {"root": list(root), "receipts": [list(r) for r in receipts]}


def open_attempt(path, readonly):
    try:
        c = open_graph(path, readonly)
        try:
            c.execute("RETURN 1").fetchall()
        finally:
            c.close()
        return {"opened": True}
    except Exception as exc:
        return {"opened": False, "error_type": type(exc).__name__, "error": str(exc)}


def child_attempt(path, readonly):
    cp = subprocess.run(
        [
            sys.executable,
            "-m",
            "spikes.spike_1.contracts",
            "open",
            str(path),
            str(int(readonly)),
        ],
        cwd=ROOT,
        text=True,
        capture_output=True,
        timeout=5,
    )
    if cp.returncode:
        raise RuntimeError(cp.stderr)
    return json.loads(cp.stdout)


def run(root):
    import graphdb

    root = Path(root)
    path = root / "contracts"
    c = open_graph(path)
    try:
        control_schema(c)
        denied = False
        with c.cursor() as read_guard:
            try:
                with read_transaction(read_guard):
                    read_guard.execute("MATCH (n:Control) SET n.version=99")
            except graphdb.Error:
                denied = True
        assert denied and state(c)["root"][0] == 0
        reader = c.cursor()
        try:
            publish(c, "op1", 0, "v1")
            begin = time.perf_counter()
            independent = state(reader)
            latency = (time.perf_counter() - begin) * 1000
            assert independent["root"] == [1, "v1", "old-description"]
            original = state(c)
            for kwargs in (
                {"expected": 0},
                {"expected": 1, "cancelled": True},
                {"expected": 1, "fail": True},
            ):
                try:
                    publish(c, "not-committed", target="bad", **kwargs)
                except ValueError:
                    pass
                else:
                    raise AssertionError(
                        "conflict/cancel/failure unexpectedly published"
                    )
                assert state(c) == original
            # An independently changed support read-set must also conflict.
            with c.transaction():
                c.execute("MATCH (n:SupportEpoch) SET n.version=1")
            try:
                publish(c, "stale-support-read-set", 1, "bad", expected_support=0)
            except ValueError:
                pass
            else:
                raise AssertionError("new support was ignored by read-set check")
            assert state(c) == original
            publish(c, "op2", 1, "v2", expected_support=1)
            assert len(state(reader)["receipts"]) == 2
            # Earlier receipt survives a later publication.
            assert c.execute(
                "MATCH (n:Receipt) WHERE n.id='op1' RETURN n.selected"
            ).fetchall() == [("v1",)]
        finally:
            reader.close()
        # Logical view retention does not keep a native Read open.
        with c.cursor() as lease:
            with read_transaction(lease):
                logical_selection = state(lease)["root"][1]
        publish(c, "logical-switch", 2, "v3", expected_support=1)
        old_fact = c.execute(
            "MATCH (n:FactVersion) WHERE n.id=$id RETURN n.body",
            {"id": logical_selection},
        ).fetchall()
        assert old_fact == [("knowledge-v2",)]
        assert state(c)["root"][1] == "v3"
        import threading
        from concurrent.futures import ThreadPoolExecutor

        start_reads = threading.Barrier(3)

        def read_loop():
            child = c.cursor()
            observations = []
            try:
                start_reads.wait(timeout=3)
                for _ in range(30):
                    with read_transaction(child):
                        observed = state(child)
                        assert observed["root"][0] == len(observed["receipts"])
                        assert (
                            observed["root"][1]
                            == max(
                                observed["receipts"], key=lambda receipt: receipt[1]
                            )[2]
                        )
                        observations.append(observed["root"][0])
                    time.sleep(0.001)
            finally:
                child.close()
            return observations

        with ThreadPoolExecutor(max_workers=2) as readers:
            tasks = [readers.submit(read_loop) for _ in range(2)]
            start_reads.wait(timeout=3)
            for version in range(3, 13):
                publish(
                    c,
                    f"parallel-{version}",
                    version,
                    f"v{version + 1}",
                    expected_support=1,
                )
            observations = [task.result(timeout=5) for task in tasks]
        assert all(observations)
        mixed = open_attempt(path, True)
        writer_child = child_attempt(path, False)
        readonly_child = child_attempt(path, True)
        assert (
            not mixed["opened"]
            and not writer_child["opened"]
            and not readonly_child["opened"]
        )
        before_close = state(c)
    finally:
        c.close()
    c = open_graph(path, True)
    try:
        before = tree_digest(path)
        ro_children = [child_attempt(path, True) for _ in range(2)]
        # Read-only children are opened sequentially while this read holder remains alive.
        writer_during_read = child_attempt(path, False)
        assert (
            all(x["opened"] for x in ro_children) and not writer_during_read["opened"]
        )
        assert state(c) == before_close
        assert tree_digest(path) == before
        write_rejected = False
        try:
            c.execute("MATCH (n:Control) SET n.selected='illegal'")
        except graphdb.Error:
            write_rejected = True
        assert write_rejected
    finally:
        c.close()
    return {
        "passed": True,
        "independent_cursor_read_visibility_ms": latency,
        "atomic_control_model": [
            "root selection",
            "associated invalidation",
            "view version",
            "operation receipt",
        ],
        "checks": [
            "explicit_readonly_transaction_rejects_write",
            "read_set_conflict",
            "new_support_read_set_conflict",
            "cancel_before_commit",
            "body_failure_rollback",
            "receipt_history",
            "logical_view_retains_immutable_old_facts_without_native_read_pin",
            "two_concurrent_readers_atomic_visibility",
        ],
        "concurrent_reader_observations": observations,
        "same_process_mixed_mode": mixed,
        "writer_plus_writer_process": writer_child,
        "writer_plus_readonly_process": readonly_child,
        "readonly_holders": ro_children,
        "readonly_plus_writer_process": writer_during_read,
        "readonly_tree_unchanged": True,
    }


def held_reader(path):
    import threading

    c = open_graph(path)
    control_schema(c)
    reader = c.cursor()
    reader.execute("BEGIN TRANSACTION READ ONLY")
    old = state(reader)
    print(json.dumps({"phase": "old_read_transaction_held"}), flush=True)
    started = threading.Event()
    done = threading.Event()
    errors = []

    def writer():
        started.set()
        try:
            publish(c, "after-release", 0, "v1")
        except BaseException as exc:
            errors.append(type(exc).__name__ + ": " + str(exc))
        finally:
            done.set()

    thread = threading.Thread(target=writer, daemon=True)
    begin = time.perf_counter()
    thread.start()
    assert started.wait(1)
    time.sleep(0.05)
    blocked = not done.is_set()
    assert state(reader) == old
    print(
        json.dumps({"phase": "releasing_old_read", "writer_blocked": blocked}),
        flush=True,
    )
    assert done.wait(2), "Update failed to complete with an old Read pinned"
    assert state(reader) == old
    assert state(c)["root"][0] == 1
    reader.rollback()
    reader.close()
    thread.join(2)
    assert done.is_set() and not errors, errors
    assert state(c)["root"] == [1, "v1", "old-description"]
    elapsed = time.perf_counter() - begin
    c.close()
    return {
        "passed": True,
        "contract": "explicit READ ONLY retains old view while independent Update publishes a new view",
        "writer_complete_by_first_sample": not blocked,
        "writer_finished_before_read_release": True,
        "elapsed_seconds": elapsed,
        "required_sdk_rule": "explicit READ ONLY for readers; bound snapshot retention; begin()/transaction() on writable connections are Update",
    }


def crash_child(path, marker, stage):
    c = open_graph(path)
    if stage == "before_commit":
        c.begin()
        c.execute(
            "MATCH (n:Control) WHERE n.id='root' SET n.version=1,n.selected='v1',n.invalid='old-description'"
        )
        c.execute("CREATE (:Receipt {id:'crash-op',version:1,selected:'v1'})")
    else:
        publish(c, "crash-op", 0, "v1")
    Path(marker).write_text(stage)
    # Parent kills only this child, without close/checkpoint.
    while True:
        time.sleep(0.05)


def run_crash(root, stage):
    path = Path(root) / ("crash-" + stage)
    c = open_graph(path)
    control_schema(c)
    c.close()
    marker = Path(root) / (stage + ".ready")
    child = subprocess.Popen(
        [
            sys.executable,
            "-m",
            "spikes.spike_1.contracts",
            "crash",
            str(path),
            str(marker),
            stage,
        ],
        cwd=ROOT,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
    )
    try:
        deadline = time.monotonic() + 8
        while not marker.exists():
            if child.poll() is not None:
                raise RuntimeError(child.stderr.read().decode())
            if time.monotonic() >= deadline:
                raise TimeoutError("crash child did not reach boundary")
            time.sleep(0.01)
        child.kill()
        child.wait(timeout=5)
    finally:
        if child.poll() is None:
            child.kill()
            child.wait(timeout=5)
        child.stderr.close()
    before = tree_digest(path)
    ro = open_attempt(path, True)
    readonly_unchanged = tree_digest(path) == before
    assert readonly_unchanged
    c = open_graph(path)
    try:
        actual = state(c)
        expected = (
            [0, "v0", "none"]
            if stage == "before_commit"
            else [1, "v1", "old-description"]
        )
        assert actual["root"] == expected, actual
        assert len(actual["receipts"]) == (0 if stage == "before_commit" else 1)
    finally:
        c.close()
    return {
        "passed": True,
        "stage": stage,
        "kind": "real_SIGKILL_at_python_boundary",
        "readonly_open": ro,
        "readonly_tree_unchanged": readonly_unchanged,
        "recovered": actual,
        "not_covered": "mid-WAL syscall, hardware power loss",
    }


if __name__ == "__main__":
    if sys.argv[1] == "open":
        print(json.dumps(open_attempt(sys.argv[2], bool(int(sys.argv[3])))))
    elif sys.argv[1] == "held":
        print(json.dumps(held_reader(sys.argv[2])))
    elif sys.argv[1] == "crash":
        crash_child(*sys.argv[2:])
