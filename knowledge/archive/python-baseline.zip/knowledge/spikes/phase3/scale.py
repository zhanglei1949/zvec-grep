"""Isolated actual SDK workload, pinned old readers and retained failed candidates."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import time
from contextlib import ExitStack
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch

from spikes.validation.common import environment, peak_rss, percentile
from zknowledge import (
    BuildConfig,
    DocumentInput,
    JobStatus,
    KnowledgeBase,
    SectionSegmenter,
    SourceSpec,
    SyntheticEmbeddingProvider,
)
from zknowledge.errors import StorageError
from zknowledge.publication_store import fetch

PROFILE = Path(__file__).with_name("profile.json")


def run(root, count, p):
    start = time.perf_counter()
    kb = KnowledgeBase.create(root / "kb")
    config = BuildConfig(
        embedding=SyntheticEmbeddingProvider(p["dimensions"]),
        vector="required",
        batch_size=32,
    )
    sources = [kb.sources.register(SourceSpec(f"source-{i}")) for i in range(count)]
    latest = {}
    inputs = 0

    def capture_and_build(source, revision, options=config):
        nonlocal inputs
        sections = []
        for section in range(p["sections"]):
            header = f"# Source {source.source_key} revision {revision} section {section}\nquasar ".encode()
            sections.append(
                header + b"x" * (p["section_bytes"] - len(header) - 1) + b"\n"
            )
        data = b"".join(sections)
        inputs += len(data)
        captured = kb.ingest_documents(source.id, DocumentInput.from_bytes(data)).wait(
            60
        )
        assert captured.status == JobStatus.COMPLETED, captured.error
        built = kb.build_documents(captured.result.revision_id, config=options).wait(60)
        return built

    try:
        for revision in range(2):
            for source in sources:
                result = capture_and_build(source, revision)
                assert result.status == JobStatus.COMPLETED, result.error
                assert result.result.unit_count == p["sections"]
                latest[source.id] = result.result
        old_first = latest[sources[0].id]
        with ExitStack() as pins:
            readers = [
                pins.enter_context(kb._graph.read_txn())
                for _ in range(p["retained_readers"])
            ]
            for conn in readers:
                assert (
                    fetch(conn, "KGSourceSelection", sources[0].id)["publication_id"]
                    == old_first.publication_id
                )
            for source in sources[:1]:
                result = capture_and_build(source, 2)
                assert result.status == JobStatus.COMPLETED, result.error
                latest[source.id] = result.result
            for conn in readers:
                assert (
                    fetch(conn, "KGSourceSelection", sources[0].id)["publication_id"]
                    == old_first.publication_id
                )
            assert (
                kb.publications.current(sources[0].id).publication_id
                == latest[sources[0].id].publication_id
            )
        for source in sources[1:]:
            result = capture_and_build(source, 2)
            assert result.status == JobStatus.COMPLETED, result.error
            latest[source.id] = result.result
        failures = []
        original = kb._graph.write_txn

        def failed_publish(fn):
            if fn.__name__ == "publish":

                def body(conn):
                    fn(conn)
                    raise StorageError(
                        "injected rollback for retained-candidate accounting"
                    )

                return original(body)
            return original(fn)

        with patch.object(kb._graph, "write_txn", failed_publish):
            for i in range(p["failure_attempts"]):
                result = capture_and_build(
                    sources[0],
                    3 + i,
                    replace(config, segmenter=SectionSegmenter(2048 + i)),
                )
                assert result.status == JobStatus.FAILED, result.error
                failures.append(result.error["code"])
        build_seconds = time.perf_counter() - start
        samples = []
        for _ in range(5):
            kb.builds._confirm(latest[sources[0].id])
        for _ in range(p["query_samples"]):
            t = time.perf_counter()
            kb.builds._confirm(latest[sources[0].id])
            samples.append((time.perf_counter() - t) * 1000)
        with kb._graph.read_txn() as conn:
            counts = {
                table: conn.execute(f"MATCH (n:{table}) RETURN count(n)").fetchall()[0][
                    0
                ]
                for table in (
                    "KGSource",
                    "KGRevision",
                    "KGContentUnit",
                    "KGSegment",
                    "KGProjection",
                    "KGPublication",
                    "KGBuild",
                )
            }
        kb.close()
        t = time.perf_counter()
        kb = KnowledgeBase.open(root / "kb", read_only=True)
        reopen = time.perf_counter() - t
        for source in sources:
            assert (
                kb.publications.current(source.id).publication_id
                == latest[source.id].publication_id
            )
        kb.builds._confirm(old_first)
        kb.builds._confirm(latest[sources[0].id])
        disk = sum(f.stat().st_size for f in (root / "kb").rglob("*") if f.is_file())
        measure = {
            "sources": count,
            "main_revisions": 3,
            "failure_attempts": len(failures),
            "physical_counts": counts,
            "input_bytes_including_failure_fixtures": inputs,
            "retained_readers": len(readers),
            "reader_pin_scope": p["reader_pin_scope"],
            "capture_and_build_seconds": build_seconds,
            "readonly_reopen_seconds": reopen,
            "readonly_copy_bytes": kb.health()["index"]["readonly_copy_bytes"],
            "peak_rss_bytes": peak_rss(),
            "disk_bytes": disk,
            "validation_p50_ms": percentile(samples, 0.5),
            "validation_p95_ms": percentile(samples, 0.95),
            "logical_vector_dimensions": p["dimensions"],
        }
        failed = []
        for field, limit in [
            ("peak_rss_bytes", "peak_rss_limit_bytes"),
            ("capture_and_build_seconds", "capture_and_build_limit_seconds"),
            ("readonly_reopen_seconds", "readonly_reopen_limit_seconds"),
            ("validation_p95_ms", "validation_p95_limit_ms"),
        ]:
            if measure[field] > p[limit]:
                failed.append(field)
        return {
            "passed": not failed,
            "measurements": measure,
            "threshold_failures": failed,
        }
    finally:
        kb.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--worker", type=int)
    args = ap.parse_args()
    p = json.loads(PROFILE.read_bytes())
    if args.worker:
        result = run(args.output, args.worker, p)
        (args.output / "result.json").write_text(json.dumps(result, indent=2))
        return 0 if result["passed"] else 2
    if args.output.exists():
        raise FileExistsError("output must be a new directory")
    args.output.mkdir(parents=True)
    profile_hash = hashlib.sha256(PROFILE.read_bytes()).hexdigest()
    sdk_hashes = {
        str(f): hashlib.sha256(f.read_bytes()).hexdigest()
        for f in sorted(Path("zknowledge").rglob("*.py"))
    }
    result = {
        "profile": p,
        "profile_sha256": profile_hash,
        "environment": environment(),
        "sdk_sha256": sdk_hashes,
        "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "cases": [],
    }
    for n in p["source_counts"]:
        directory = args.output / str(n)
        directory.mkdir()
        with (directory / "worker.log").open("w") as log:
            child = subprocess.Popen(
                [
                    sys.executable,
                    "-m",
                    "spikes.phase3.scale",
                    "--worker",
                    str(n),
                    "--output",
                    str(directory),
                ],
                stdout=log,
                stderr=subprocess.STDOUT,
            )
            try:
                code = child.wait(timeout=300)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait()
                code = -1
        value = (
            json.loads((directory / "result.json").read_bytes())
            if (directory / "result.json").exists()
            else {"passed": False, "reason": "worker failed or timed out"}
        )
        value["passed"] = bool(value["passed"] and code == 0)
        result["cases"].append(value)
        print(json.dumps({"sources": n, "passed": value["passed"]}), flush=True)
    result["unchanged"] = profile_hash == hashlib.sha256(
        PROFILE.read_bytes()
    ).hexdigest() and all(
        hashlib.sha256(Path(f).read_bytes()).hexdigest() == h
        for f, h in sdk_hashes.items()
    )
    result["passed"] = all(c["passed"] for c in result["cases"]) and result["unchanged"]
    (args.output / "results.json").write_text(json.dumps(result, indent=2))
    return 0 if result["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
