"""Read-only physical inventory of a cleanly closed Phase 3 SDK workload."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from spikes.validation.common import tree_digest
from zknowledge import KnowledgeBase
from zknowledge.publication_store import TABLES as BUILD_TABLES
from zknowledge.source_store import TABLES as SOURCE_TABLES


def inspect(root):
    before = tree_digest(root)
    with KnowledgeBase.open(root, read_only=True) as kb:
        with kb._graph.read_txn() as conn:
            nodes = {
                table: conn.execute(f"MATCH (n:{table}) RETURN count(n)").fetchall()[0][
                    0
                ]
                for table in SOURCE_TABLES + BUILD_TABLES
            }
            relations = {
                rel: conn.execute(f"MATCH ()-[r:{rel}]->() RETURN count(r)").fetchall()[
                    0
                ][0]
                for rel in ("KG_HAS_REVISION", "KG_HAS_UNIT")
            }
        indices = {
            key: {
                "channel": value["descriptor"]["channel"],
                "doc_count": kb._index.get(key)._collection.stats.doc_count,
            }
            for key, value in kb._index._entries.items()
        }
        files = {
            group: sum(
                p.stat().st_size for p in (root / group).rglob("*") if p.is_file()
            )
            for group in ("graph", "index", "snapshots", "artifacts", "stores")
        }
    assert before == tree_digest(root), "read-only inventory changed the workload"
    return {
        "root": str(root),
        "node_counts": nodes,
        "relation_counts": relations,
        "collection_counts": indices,
        "retained_file_bytes": files,
        "readonly_files_unchanged": True,
        "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    value = inspect(args.root)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(value, indent=2))
    print(json.dumps(value, indent=2))
