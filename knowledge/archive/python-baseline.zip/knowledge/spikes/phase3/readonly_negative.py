"""Negative control: pinned native readonly mmap can modify a clean vector index."""

from __future__ import annotations

import argparse
import gc
import json
import tempfile
import time
from dataclasses import replace
from pathlib import Path

from spikes.validation.common import environment, tree_digest
from zknowledge import (
    BuildConfig,
    DocumentInput,
    JobStatus,
    KnowledgeBase,
    KnowledgeBaseConfig,
    SourceSpec,
    StoreConfig,
    SyntheticEmbeddingProvider,
)


def run():
    import zvec

    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary) / "kb"
        options = replace(
            KnowledgeBaseConfig.default(),
            store=StoreConfig(index_compact_threshold=2),
        )
        with KnowledgeBase.create(root, config=options) as kb:
            source = kb.sources.register(SourceSpec("native-readonly-negative"))
            for revision in range(3):
                capture = kb.ingest_documents(
                    source.id,
                    DocumentInput.from_bytes(
                        f"# Revision {revision}\nquasar\n".encode()
                    ),
                ).wait(10)
                assert capture.status == JobStatus.COMPLETED, capture.error
                built = kb.build_documents(
                    capture.result.revision_id,
                    config=BuildConfig(
                        embedding=SyntheticEmbeddingProvider(3), vector="required"
                    ),
                ).wait(10)
                assert built.status == JobStatus.COMPLETED, built.error
            vector_path = (
                root / "index" / "collections" / built.result.vector_collection
            )
        before = tree_digest(vector_path)
        # Metadata timestamps can otherwise remain equal within one second.
        time.sleep(1.05)
        collection = zvec.open(str(vector_path), zvec.CollectionOption(read_only=True))
        count = collection.stats.doc_count
        del collection
        gc.collect()
        after = tree_digest(vector_path)
        changed = {
            key: {"before": before.get(key), "after": after.get(key)}
            for key in before.keys() | after.keys()
            if before.get(key) != after.get(key)
        }
        assert changed, "native readonly mutation was not reproduced"
        original = tree_digest(root)
        with KnowledgeBase.open(root, read_only=True) as kb:
            kb.builds._confirm(built.result)
            copied_bytes = kb.health()["index"]["readonly_copy_bytes"]
        assert original == tree_digest(root), "SDK isolation modified original files"
    return {
        "environment": environment(),
        "kind": "unsupported_native_readonly_negative_control",
        "native_mutation_reproduced": bool(changed),
        "changed_files": changed,
        "native_doc_count": count,
        "sdk_original_files_unchanged": True,
        "sdk_readonly_copy_bytes": copied_bytes,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = run()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
