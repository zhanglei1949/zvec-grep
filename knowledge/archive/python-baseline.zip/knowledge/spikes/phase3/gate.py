"""Phase 3 prerequisite gate: pinned graphdb, dual zvec collections, Markdown mapping."""

from __future__ import annotations

import argparse
import importlib.metadata
import json
import tempfile
from pathlib import Path

from spikes.validation.common import environment
from zknowledge.document_processing import (
    ParseContext,
    ProcessingBudget,
    SourceSnapshot,
    parse_document,
)
from zknowledge.documents import MarkdownParser
from zknowledge.index_catalog import descriptor, native_schema


def run():
    import gc
    import hashlib

    import graphdb
    import zvec

    result = {"environment": environment(), "checks": {}, "dependencies": {}}
    with tempfile.TemporaryDirectory(prefix="zkg-phase3-gate-") as tmp:
        root = Path(tmp)
        c = graphdb.connect(
            str(root / "g"),
            config={"transaction_mode": "tp", "max_intermediate_rows": 1000000},
        )
        c.execute("CREATE NODE TABLE N(id STRING PRIMARY KEY, owner STRING)")
        c.execute("CREATE REL TABLE R(FROM N TO N)")
        with c.transaction():
            for i in range(128):
                c.execute(
                    "CREATE (:N {id:$id,owner:$owner})",
                    {"id": str(i), "owner": str(i % 8)},
                )
            c.execute(
                "MATCH (a:N),(b:N) WHERE a.id='0' AND b.id='1' CREATE (a)-[:R]->(b)"
            )
        result["access_plans"] = {
            name: c.explain(q)
            for name, q in {
                "primary_key": "MATCH (n:N) WHERE n.id='0' RETURN n.owner",
                "typed_filter": "MATCH (n:N) WHERE n.owner='0' RETURN n.id",
                "relation": "MATCH (a:N)-[:R]->(b:N) WHERE a.id='0' RETURN b.id",
            }.items()
        }
        assert c.execute(
            "MATCH (a:N)-[:R]->(b:N) WHERE a.id='0' RETURN b.id"
        ).fetchall() == [("1",)]
        try:
            c.execute("CREATE INDEX owner_index ON N(owner)")
        except graphdb.Error:
            result["checks"]["secondary_index_ddl"] = (
                "unsupported; do not assume typed filters are indexed"
            )
        else:
            result["checks"]["secondary_index_ddl"] = "accepted"
        c.execute(
            "CREATE NODE TABLE IF NOT EXISTS N(id STRING PRIMARY KEY, owner STRING)"
        )
        c.close()
        for readonly in (False, True):
            c = graphdb.connect(
                str(root / "g"),
                read_only=readonly,
                config={"transaction_mode": "tp", "max_intermediate_rows": 1000000},
            )
            c.execute("BEGIN TRANSACTION READ ONLY")
            assert c.execute(
                "MATCH (n:N) WHERE n.id='0' RETURN n.owner"
            ).fetchall() == [("0",)]
            c.commit()
            c.close()
            result["checks"]["read_txn_readonly_" + str(readonly)] = True
        for channel in ("text", "vector"):
            from zknowledge import EmbeddingSpace

            space = EmbeddingSpace("synthetic/storage-test", "1", 3)
            value = descriptor(channel, vars(space) if channel == "vector" else None)
            schema = native_schema(value)
            col = zvec.create_and_open(str(root / channel), schema)
            fields = {
                n: ""
                for n in (
                    "business_id",
                    "source_id",
                    "revision_id",
                    "build_version",
                    "space_id",
                    "content_digest",
                    "input_digest",
                )
            }
            fields.update(
                body="quasar body",
                business_id="unit",
                space_id=space.id if channel == "vector" else "",
            )
            doc = zvec.Doc(
                id="projection",
                fields=fields,
                vectors={"embedding": [1.0, 0.0, 0.0]} if channel == "vector" else None,
            )
            assert all(s.ok() for s in col.insert([doc]))
            assert not col.insert([doc])[0].ok()
            repaired_fields = {**fields, "business_id": "repaired-unit"}
            repaired = zvec.Doc(
                id="repaired",
                fields=repaired_fields,
                vectors={"embedding": [1.0, 0.0, 0.0]} if channel == "vector" else None,
            )
            assert col.upsert([repaired])[
                0
            ].ok()  # only missing IDs are SDK repair targets
            col.flush()
            assert col.fetch(["projection"])["projection"].fields == fields
            q = (
                zvec.Query(field_name="body", fts=zvec.Fts(match_string="quasar"))
                if channel == "text"
                else zvec.Query(field_name="embedding", vector=[1.0, 0.0, 0.0])
            )
            assert (
                col.query(q, filter="business_id = 'unit'", topk=1)[0].id
                == "projection"
            )
            schema_json = json.loads(str(col.schema))
            if channel == "vector":
                old_ids = ["projection", "repaired"]
                for i in range(15):
                    ident = "extra-" + str(i)
                    assert col.insert(
                        [
                            zvec.Doc(
                                id=ident,
                                fields=fields,
                                vectors={"embedding": [1.0, 0.0, 0.0]},
                            )
                        ]
                    )[0].ok()
                    old_ids.append(ident)
                    col.flush()
                before_bytes = sum(
                    p.stat().st_size for p in (root / channel).rglob("*") if p.is_file()
                )
                col.optimize(zvec.OptimizeOption(concurrency=1))
                col.flush()
                assert set(col.fetch(old_ids)) == set(old_ids)
                result["checks"]["native_compaction_all_projection_ids_retained"] = True
                result["compaction_bytes"] = {
                    "before": before_bytes,
                    "after": sum(
                        p.stat().st_size
                        for p in (root / channel).rglob("*")
                        if p.is_file()
                    ),
                }
            del col
            gc.collect()
            reopened = zvec.open(
                str(root / channel), zvec.CollectionOption(read_only=True)
            )
            assert json.loads(str(reopened.schema)) == schema_json
            assert reopened.fetch(["projection"])["projection"].fields == fields
            del reopened
            gc.collect()
            result["checks"][channel + "_collection_write_filter_reopen"] = True
        raw = "\ufeff前言\r\n\r\n# 标题\r\n\r\n```\r\n# fake\r\n```\r\n".encode()
        snapshot = SourceSnapshot("s", "r", hashlib.sha256(raw).hexdigest(), raw)
        parsed = parse_document(
            MarkdownParser(), snapshot, ParseContext(ProcessingBudget(10000, 1000))
        )
        section = [b for b in parsed.blocks if b.kind == "section"]
        assert len(section) == 1 and section[0].span.start == raw.index(
            "# 标题".encode()
        )
        result["checks"]["raw_utf8_bom_crlf_mapping"] = True
    for name in ("markdown-it-py", "mdurl"):
        dist = importlib.metadata.distribution(name)
        classifiers = dist.metadata.get_all("Classifier", [])
        licenses = {
            str(p): hashlib.sha256(dist.locate_file(p).read_bytes()).hexdigest()
            for p in dist.files or ()
            if "LICENSE" in str(p).upper()
        }
        result["dependencies"][name] = {
            "version": dist.version,
            "license": dist.metadata.get("License-Expression")
            or dist.metadata.get("License")
            or next((v for v in classifiers if v.startswith("License ::")), "unknown"),
            "license_files_sha256": licenses,
            "pure_python_files": not any(
                str(p).endswith((".so", ".dylib", ".pyd")) for p in dist.files or ()
            ),
            "requires": dist.requires,
        }
    result["passed"] = True
    result["sdk_sha256"] = {
        str(p): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(Path("zknowledge").rglob("*.py"))
    }
    result["runner_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output", type=Path, default=Path(".artifacts/phase3/gate.json")
    )
    args = parser.parse_args()
    result = run()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
