"""Real SIGKILL at SDK boundaries; each owned child uses its own temporary KB."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import signal
import subprocess
import sys
import threading
import time
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch

from spikes.validation.common import environment, tree_digest
from zknowledge import (
    BuildConfig,
    DocumentInput,
    JobStatus,
    KnowledgeBase,
    KnowledgeBaseConfig,
    SourceSpec,
    StoreConfig,
    SyntheticEmbeddingProvider,
)


def child(root, stage):
    options = (
        replace(
            KnowledgeBaseConfig.default(), store=StoreConfig(index_compact_threshold=2)
        )
        if stage == "optimize"
        else KnowledgeBaseConfig.default()
    )
    with KnowledgeBase.create(root / "kb", config=options) as kb:
        source = kb.sources.register(SourceSpec("crash-fixture"))
        config = BuildConfig(embedding=SyntheticEmbeddingProvider(3), vector="required")

        def capture(raw):
            value = kb.ingest_documents(source.id, DocumentInput.from_bytes(raw)).wait(
                10
            )
            assert value.status == JobStatus.COMPLETED, value.error
            return value.result

        first = capture(b"# A\nquasar old\n")
        initial = kb.build_documents(first.revision_id, config=config).wait(10)
        assert initial.status == JobStatus.COMPLETED, initial.error
        second = capture(b"# B\nquasar new\n")
        (root / "fixture.json").write_text(
            json.dumps(
                {
                    "source_id": source.id,
                    "revision_id": second.revision_id,
                    "old_publication": initial.result.publication_id,
                    "dimensions": 5 if stage == "creation" else 3,
                }
            )
        )

        def hold():
            (root / "ready").write_text(stage)
            threading.Event().wait()  # parent owns this child and sends SIGKILL

        original = kb._graph.write_txn

        def interrupted(fn):
            if fn.__name__ == "publish":
                if stage == "before_commit":

                    def in_body(conn):
                        value = fn(conn)
                        hold()
                        return value

                    return original(in_body)
                value = original(fn)
                if stage == "after_commit":
                    hold()
                return value
            return original(fn)

        original_embed = SyntheticEmbeddingProvider.embed

        def embedding(provider, items, context):
            if stage == "provider":
                hold()
            return original_embed(provider, items, context)

        original_save = kb._index._save
        from zknowledge.adapters.search_index import SearchIndexAdapter

        original_flush = SearchIndexAdapter.flush

        def flush(adapter):
            original_flush(adapter)
            if stage == "optimize" and adapter._collection.schema.vectors:
                hold()

        def registration():
            if stage == "creation" and any(
                e["state"] == "ready"
                and e["descriptor"].get("space", {}).get("dimensions") == 5
                for e in kb._index._entries.values()
                if e["descriptor"].get("space")
            ):
                hold()
            return original_save()

        with (
            patch.object(kb._graph, "write_txn", interrupted),
            patch.object(SyntheticEmbeddingProvider, "embed", embedding),
            patch.object(kb._index, "_save", registration),
            patch.object(SearchIndexAdapter, "flush", flush),
        ):
            if stage == "creation":
                config = BuildConfig(
                    embedding=SyntheticEmbeddingProvider(5), vector="required"
                )
            job = kb.build_documents(
                second.revision_id, config=config, operation_id="crash-build"
            )
            result = job.wait(60)
            raise AssertionError(f"child did not reach boundary: {result.error}")


def case(root, stage):
    root.mkdir()
    with (root / "child.log").open("w") as log:
        process = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "spikes.phase3.crash",
                "--child",
                stage,
                "--output",
                str(root),
            ],
            stdout=log,
            stderr=subprocess.STDOUT,
        )
        try:
            deadline = time.monotonic() + 30
            while not (root / "ready").exists():
                if process.poll() is not None:
                    raise RuntimeError((root / "child.log").read_text())
                if time.monotonic() > deadline:
                    raise TimeoutError("child boundary timeout")
                time.sleep(0.02)
            os.kill(process.pid, signal.SIGKILL)
            process.wait(timeout=5)
        finally:
            if process.poll() is None:
                process.kill()
                process.wait(timeout=5)
    fixture = json.loads((root / "fixture.json").read_bytes())
    before = tree_digest(root / "kb")
    with KnowledgeBase.open(root / "kb", read_only=True) as kb:
        record = kb.builds.get("crash-build")
        current = kb.publications.current(fixture["source_id"])
        if stage == "after_commit":
            assert record.result is not None
            assert current.publication_id == record.result.publication_id
        else:
            assert record.result is None
            assert current.publication_id == fixture["old_publication"]
    after = tree_digest(root / "kb")
    differences = [
        name
        for name in before.keys() | after.keys()
        if before.get(name) != after.get(name)
    ]
    (root / "readonly-check.json").write_text(
        json.dumps({"before": before, "after": after, "changed": differences}, indent=2)
    )
    assert not differences, differences
    with KnowledgeBase.open(root / "kb") as kb:
        kb.builds._confirm(kb.publications.get(fixture["old_publication"]).result)
        reconciled = kb.builds.reconcile("crash-build")
        expected = (
            "committed"
            if stage == "after_commit"
            else ("provider_unknown" if stage == "provider" else "not_committed")
        )
        assert reconciled.state == expected, reconciled
        if stage == "provider":
            attempted = kb.build_documents(
                fixture["revision_id"],
                config=BuildConfig(
                    embedding=SyntheticEmbeddingProvider(3), vector="required"
                ),
                operation_id="crash-build",
            ).wait(10)
            assert attempted.status == JobStatus.RECOVERY_REQUIRED
        elif stage != "after_commit":
            retried = kb.build_documents(
                fixture["revision_id"],
                config=BuildConfig(
                    embedding=SyntheticEmbeddingProvider(fixture["dimensions"]),
                    vector="required",
                ),
                operation_id="crash-build",
            ).wait(15)
            assert retried.status == JobStatus.COMPLETED, retried.error
    return {
        "stage": stage,
        "passed": True,
        "termination": "real_SIGKILL_at_SDK_boundary",
        "readonly_files_unchanged": True,
        "reconciliation": expected,
        "not_covered": [
            "hardware power loss",
            "mid-native-WAL syscall with SDK publication receipt",
        ],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--child")
    args = parser.parse_args()
    if args.child:
        child(args.output, args.child)
        return
    if args.output.exists():
        raise FileExistsError("output must be a new directory")
    args.output.mkdir(parents=True)
    result = {
        "environment": environment(),
        "cases": [
            case(args.output / stage, stage)
            for stage in (
                "before_commit",
                "after_commit",
                "provider",
                "creation",
                "optimize",
            )
        ],
    }
    result["passed"] = all(c["passed"] for c in result["cases"])
    result["sdk_sha256"] = {
        str(p): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(Path("zknowledge").rglob("*.py"))
    }
    result["runner_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (args.output / "results.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
