"""Negative control: existing-ID native upsert + optimize is excluded by the SDK."""

from __future__ import annotations

import argparse
import json
import tempfile
from dataclasses import asdict
from pathlib import Path

from spikes.validation.common import environment
from zknowledge import EmbeddingSpace
from zknowledge.index_catalog import descriptor, native_schema


def run():
    import zvec

    with tempfile.TemporaryDirectory() as directory:
        value = descriptor("vector", asdict(EmbeddingSpace("negative-test", "1", 3)))
        collection = zvec.create_and_open(
            str(Path(directory) / "index"), native_schema(value)
        )
        fields = {
            name: ""
            for name in (
                "business_id",
                "source_id",
                "revision_id",
                "build_version",
                "space_id",
                "content_digest",
                "input_digest",
                "body",
            )
        }
        vector = {"embedding": [1.0, 0.0, 0.0]}
        original = zvec.Doc(id="original", fields=fields, vectors=vector)
        assert collection.insert([original])[0].ok()
        assert collection.upsert([original])[0].ok()  # deliberately excluded SDK path
        collection.flush()
        ids = ["original"]
        for number in range(15):
            ident = "next-" + str(number)
            assert collection.insert(
                [zvec.Doc(id=ident, fields=fields, vectors=vector)]
            )[0].ok()
            collection.flush()
            ids.append(ident)
        before = set(collection.fetch(ids))
        collection.optimize(zvec.OptimizeOption(concurrency=1))
        collection.flush()
        missing = sorted(set(ids) - set(collection.fetch(ids)))
        count = collection.stats.doc_count
        del collection
    return {
        "environment": environment(),
        "kind": "unsupported_native_path_negative_control",
        "expected_unsupported_case_reproduced": len(before) == len(ids)
        and bool(missing),
        "reported_doc_count_after": count,
        "expected_ids": len(ids),
        "missing_after_compaction": missing,
        "sdk_policy": "fetch and reuse identical existing IDs; reject differing content; native upsert only missing IDs",
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output", type=Path, default=Path(".artifacts/phase3/upsert-negative.json")
    )
    args = parser.parse_args()
    result = run()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["expected_unsupported_case_reproduced"] else 2)
