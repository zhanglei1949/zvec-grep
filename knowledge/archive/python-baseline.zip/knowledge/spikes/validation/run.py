"""Isolated Spike-1/2 runner. Only owned subprocesses are killed on timeout.

Usage: python -m spikes.validation.run [--only CASE] [--output DIRECTORY]
Each case preserves profile hash, stdout/stderr and machine-readable result.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
import traceback
import uuid
from datetime import datetime, timezone
from pathlib import Path

from spikes.validation.common import PROFILE, ROOT, environment, peak_rss, profile


def worker(case, directory):
    directory.mkdir(parents=True, exist_ok=True)
    p = profile()
    if case == "graph-contracts":
        from spikes.spike_1.contracts import run

        return run(directory)
    if case.startswith("graph-crash-"):
        from spikes.spike_1.contracts import run_crash

        return run_crash(directory, case.removeprefix("graph-crash-"))
    if case == "graph-held-reader":
        from spikes.spike_1.contracts import held_reader

        return held_reader(directory / "graph")
    if case.startswith("graph-candidate-readers-"):
        from spikes.spike_1.scale import reader_overlap

        return reader_overlap(directory, p, int(case.rsplit("-", 1)[1]))
    if case.startswith("graph-scale-"):
        from spikes.spike_1.scale import run

        return run(directory, p, int(case.rsplit("-", 1)[1]))
    if case == "search-contracts":
        from spikes.spike_2.index_probe import contracts

        return contracts(directory, p)
    if case.startswith("search-scale-"):
        from spikes.spike_2.index_probe import scale

        return scale(directory, p, int(case.rsplit("-", 1)[1]))
    if case.startswith("view-"):
        from spikes.spike_2.effective_view import run

        return run(directory, p, int(case.rsplit("-", 1)[1]), case.split("-")[1])
    raise ValueError("unknown case " + case)


def execute(case, output, timeout):
    directory = output / case
    directory.mkdir(parents=True, exist_ok=False)
    command = [
        sys.executable,
        "-u",
        "-m",
        "spikes.validation.run",
        "--worker",
        case,
        "--output",
        str(directory),
    ]
    start = time.perf_counter()
    with (
        (directory / "stdout.log").open("wb") as stdout,
        (directory / "stderr.log").open("wb") as stderr,
    ):
        child = subprocess.Popen(command, cwd=ROOT, stdout=stdout, stderr=stderr)
        try:
            child.wait(timeout=timeout)
            timed_out = False
        except subprocess.TimeoutExpired:
            child.kill()
            child.wait(timeout=10)
            timed_out = True
    path = directory / "result.json"
    if path.exists():
        result = json.loads(path.read_bytes())
    else:
        result = {
            "passed": False,
            "reason": "timeout" if timed_out else "worker_terminated",
            "returncode": child.returncode,
            "timeout_seconds": timeout,
        }
    if child.returncode != 0:
        result["passed"] = False
        result["returncode"] = child.returncode
    result.update(case=case, wall_seconds=time.perf_counter() - start)
    if case == "graph-held-reader" and timed_out:
        result["contract"] = (
            "probe timed out; no Read/Update concurrency conclusion established"
        )
        result["phase_log"] = (directory / "stdout.log").read_text()
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--only", action="append")
    parser.add_argument("--worker")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.worker:
        result = None
        try:
            result = worker(args.worker, args.output)
        except BaseException as exc:
            result = {
                "passed": False,
                "error_type": type(exc).__name__,
                "error": str(exc),
            }
            traceback.print_exc()
        result["peak_rss_bytes"] = peak_rss()
        (args.output / "result.json").write_text(
            json.dumps(result, indent=2, default=str)
        )
        return 0 if result["passed"] else 1
    p = profile()
    env = environment()
    output = args.output or ROOT / ".artifacts/spikes" / (
        datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        + "-"
        + uuid.uuid4().hex[:6]
    )
    output = output.resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError("output must be a new/empty run directory")
    output.mkdir(parents=True, exist_ok=True)
    (output / "profile.json").write_bytes(PROFILE.read_bytes())
    (output / "environment.json").write_text(json.dumps(env, indent=2))
    cases = args.only or [
        "graph-contracts",
        "graph-held-reader",
        "graph-crash-before_commit",
        "graph-crash-after_commit",
        f"graph-candidate-readers-{p['target_sources']}",
    ] + [f"graph-scale-{n}" for n in p["source_counts"]] + ["search-contracts"] + [
        f"search-scale-{n}" for n in p["source_counts"]
    ] + [
        f"view-{strategy}-{n}"
        for n in p["source_counts"]
        for strategy in ("live", "materialized")
    ]
    results = []
    for case in cases:
        timeout = (
            5
            if case == "graph-held-reader"
            else (
                p["build_limit_seconds"] + p["reopen_limit_seconds"] + 60
                if "-scale-" in case
                or case.startswith(("view-", "graph-candidate-readers-"))
                else p["contract_timeout_seconds"]
            )
        )
        result = execute(case, output, timeout)
        results.append(result)
        print(
            json.dumps(
                {
                    "case": case,
                    "passed": result["passed"],
                    "seconds": round(result["wall_seconds"], 3),
                    "output": str(output),
                },
                ensure_ascii=False,
            ),
            flush=True,
        )
        (output / "results.json").write_text(
            json.dumps(
                {
                    "profile_id": p["profile_id"],
                    "environment": env,
                    "results": results,
                    "stage_a_go": False,
                    "note": "Consolidated decision requires all correctness/thresholds and explicit remaining-window audit.",
                },
                indent=2,
            )
        )
    native_path = ROOT / ".artifacts/spikes/native/native-results.json"
    native = (
        json.loads(native_path.read_bytes())
        if native_path.exists()
        else {"passed": False}
    )
    required_count = 6 + 4 * len(p["source_counts"])
    complete = (
        not args.only
        and len(results) == required_count
        and all(r["passed"] for r in results)
    )
    fresh = environment()
    unchanged = (
        fresh["profile_sha256"] == env["profile_sha256"]
        and fresh["experiment_source_sha256"] == env["experiment_source_sha256"]
    )
    native_matches = (
        native.get("passed")
        and native.get("environment", {}).get("profile_sha256") == env["profile_sha256"]
        and native.get("environment", {}).get("bases") == env["bases"]
    )
    decision = {
        "profile_id": p["profile_id"],
        "environment": env,
        "results": results,
        "native_fault_suites": native,
        "stage_a_go": bool(complete and unchanged and native_matches),
        "scope": "tested local profile only; not Phase 3 implementation or production readiness",
        "required_contracts": [
            "single writer process; independent cursors share writable instance",
            "explicit READ ONLY transactions; bound retained snapshots or pin logical immutable views",
            "graph-authority validation after index recall; refill within budgets",
            "retain operation receipts; reopen writable after unknown outcomes",
        ],
        "not_claimed": [
            "hardware power-loss recovery",
            "unmeasured graph capacity ceiling",
            "real model/ANN recall quality",
            "cross-process live reader+writer",
            "arbitrary domain inference",
            "SDK production publish implementation",
        ],
    }
    (output / "results.json").write_text(json.dumps(decision, indent=2))
    print("RESULTS " + str(output / "results.json"), flush=True)
    return (
        0
        if (all(r["passed"] for r in results) and (args.only or decision["stage_a_go"]))
        else 2
    )


if __name__ == "__main__":
    raise SystemExit(main())
