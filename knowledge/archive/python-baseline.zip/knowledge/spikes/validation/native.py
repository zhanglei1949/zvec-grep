"""Build/run two pinned-source native fault suites using Spike-0 build cache.

python -m spikes.validation.native --build
Only native test targets are requested; no wheel is rebuilt or installed.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import time
from pathlib import Path

from spikes.validation.common import ROOT, environment

TARGETS = ("graphdb_durable_memory_tests", "graphdb_tp_wal_tests")


def run(output, build=False):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    receipt = json.loads((ROOT / ".artifacts/spike-0/build/graphdb.json").read_bytes())
    source = ROOT / receipt["build_source"]
    directory = next((source / "build").glob("temp.*/graphdb"))
    commands = []
    if build:
        for name, command, timeout in (
            (
                "configure",
                [
                    str(ROOT / ".venv/bin/cmake"),
                    "-S",
                    str(source),
                    "-B",
                    str(directory),
                    "-DBUILD_TESTING=ON",
                ],
                60,
            ),
            (
                "build",
                [
                    str(ROOT / ".venv/bin/cmake"),
                    "--build",
                    str(directory),
                    "--target",
                    *TARGETS,
                    "--parallel",
                    "14",
                ],
                180,
            ),
        ):
            commands.append(command)
            with (output / (name + ".log")).open("w") as stream:
                cp = subprocess.run(
                    command, stdout=stream, stderr=subprocess.STDOUT, timeout=timeout
                )
            if cp.returncode:
                raise RuntimeError(name + " failed; inspect log")
    results = []
    for target in TARGETS:
        command = [str(directory / "tests" / target)]
        commands.append(command)
        start = time.perf_counter()
        cp = subprocess.run(command, capture_output=True, text=True, timeout=60)
        results.append(
            {
                "target": target,
                "returncode": cp.returncode,
                "passed": cp.returncode == 0,
                "wall_seconds": time.perf_counter() - start,
                "stdout": cp.stdout,
                "stderr": cp.stderr,
            }
        )
    files = ["tests/storage/durable_memory_test.cc", "tests/storage/tp_wal_test.cc"]
    result = {
        "passed": all(x["passed"] for x in results),
        "environment": environment(),
        "source_variant": receipt["source_variant"],
        "commands": commands,
        "test_source_sha256": {
            name: hashlib.sha256((source / name).read_bytes()).hexdigest()
            for name in files
        },
        "results": results,
        "evidence_kind": "native deterministic fault injection and crash/reopen at internal boundaries",
        "not_claimed": ["hardware power failure", "unmodified graphdb build variant"],
    }
    (output / "native-results.json").write_text(json.dumps(result, indent=2))
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build", action="store_true")
    parser.add_argument(
        "--output", type=Path, default=ROOT / ".artifacts/spikes/native"
    )
    args = parser.parse_args()
    print(json.dumps(run(args.output, args.build), indent=2))
