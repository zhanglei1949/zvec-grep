"""Shared evidence/measurement helpers, with no external dependencies."""

from __future__ import annotations

import csv
import hashlib
import json
import math
import platform
import resource
import time
from pathlib import Path

from zknowledge.manifest import default_base_compat
from zknowledge.preflight import check_base_provenance

ROOT = Path(__file__).resolve().parents[2]
PROFILE = ROOT / "spikes/validation/profile.json"


def profile():
    return json.loads(PROFILE.read_bytes())


def peak_rss():
    value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return int(value if platform.system() == "Darwin" else value * 1024)


def environment():
    report = check_base_provenance()
    if not report.ok:
        raise RuntimeError(report.reason())
    return {
        "platform": platform.platform(),
        "python": platform.python_version(),
        "bases": default_base_compat().to_dict(),
        "profile_sha256": hashlib.sha256(PROFILE.read_bytes()).hexdigest(),
        "native_provenance": report.entries,
        "experiment_source_sha256": {
            str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
            for folder in ("spikes/validation", "spikes/spike_1", "spikes/spike_2")
            for path in sorted((ROOT / folder).glob("*.py"))
        },
    }


def percentile(values, fraction):
    ordered = sorted(values)
    return ordered[max(0, math.ceil(fraction * len(ordered)) - 1)]


def timings(fn, p):
    for _ in range(p["query_warmups"]):
        fn()
    values = []
    for _ in range(p["queries_per_case"]):
        begin = time.perf_counter()
        fn()
        values.append((time.perf_counter() - begin) * 1000)
    return {
        "samples": len(values),
        "p50_ms": percentile(values, 0.5),
        "p95_ms": percentile(values, 0.95),
        "max_ms": max(values),
    }


def disk_bytes(root):
    return sum(p.stat().st_size for p in Path(root).rglob("*") if p.is_file())


def tree_digest(root):
    result = {}
    for p in sorted(Path(root).rglob("*")):
        if p.is_file():
            result[str(p.relative_to(root))] = hashlib.sha256(
                p.read_bytes()
            ).hexdigest()
    return result


def csv_copy(conn, root, table, header, rows, *, tag="", before_execute=None):
    path = Path(root) / (table + tag + ".csv")
    count = 0
    with path.open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(header)
        for row in rows:
            writer.writerow(row)
            count += 1
    if before_execute is not None:
        before_execute()
    conn.execute(f"COPY {table} FROM $path (HEADER=true)", {"path": str(path)})
    return count, path.stat().st_size


def parallel_timings(factory, p):
    from concurrent.futures import ThreadPoolExecutor

    def read_worker():
        fn, close = factory()
        values = []
        try:
            for _ in range(p["query_warmups"]):
                fn()
            for _ in range(p["queries_per_case"]):
                start = time.perf_counter()
                fn()
                values.append((time.perf_counter() - start) * 1000)
        finally:
            close()
        return values

    with ThreadPoolExecutor(max_workers=p["concurrent_readers"]) as pool:
        tasks = [pool.submit(read_worker) for _ in range(p["concurrent_readers"])]
        values = [value for task in tasks for value in task.result()]
    return {
        "workers": p["concurrent_readers"],
        "samples": len(values),
        "p50_ms": percentile(values, 0.5),
        "p95_ms": percentile(values, 0.95),
        "max_ms": max(values),
    }
