"""Actual zvec contracts; synthetic embeddings isolate storage from model quality."""

from __future__ import annotations

import gc
import time
from pathlib import Path

from spikes.validation.common import disk_bytes, peak_rss, timings


def schema(dim):
    import zvec

    return zvec.CollectionSchema(
        name="spike2",
        fields=[
            zvec.FieldSchema(
                "body",
                zvec.DataType.STRING,
                nullable=False,
                index_param=zvec.FtsIndexParam(
                    tokenizer_name="standard", filters=["lowercase"]
                ),
            ),
            zvec.FieldSchema("business_id", zvec.DataType.STRING, nullable=False),
            zvec.FieldSchema("revision", zvec.DataType.STRING, nullable=False),
            zvec.FieldSchema("build", zvec.DataType.STRING, nullable=False),
            zvec.FieldSchema("space", zvec.DataType.STRING, nullable=False),
        ],
        vectors=[
            zvec.VectorSchema(
                "embedding",
                zvec.DataType.VECTOR_FP32,
                dimension=dim,
                index_param=zvec.HnswIndexParam(),
            )
        ],
    )


def doc(
    ident,
    vector,
    *,
    business="b0",
    revision="r1",
    build="build1",
    space="synthetic-v1",
    body="quasar knowledge graph",
):
    import zvec

    return zvec.Doc(
        id=ident,
        fields={
            "body": body,
            "business_id": business,
            "revision": revision,
            "build": build,
            "space": space,
        },
        vectors={"embedding": vector},
    )


def vector_query(vector):
    from zvec import Query

    return Query(field_name="embedding", vector=vector)


def text_query():
    from zvec import Fts, Query

    return Query(field_name="body", fts=Fts(match_string="quasar"))


def confirmed(candidates, selected, space):
    # Experimental graph-authority check, not a native zvec feature.
    result = []
    for item in candidates:
        fields = item.fields
        expected = selected.get(fields["business_id"])
        if (
            fields["revision"],
            fields["build"],
            fields["space"],
        ) == expected and fields["space"] == space:
            result.append(item)
    return result


def space_checked_query(collection, vector, requested, configured, **kwargs):
    if requested != configured:
        raise ValueError("embedding_space_mismatch")
    return collection.query(vector_query(vector), **kwargs)


def contracts(root, p):
    import zvec

    dim = p["vector_dimensions"]
    vector = [1.0] + [0.0] * (dim - 1)
    root = Path(root)
    path = root / "index"
    collection = zvec.create_and_open(str(path), schema(dim))
    initial = collection.insert([doc("duplicate", vector)])
    assert initial[0].ok()
    # Duplicate PK reaches native insertion, exposing per-item partial status.
    statuses = collection.insert(
        [doc("first", vector), doc("duplicate", vector), doc("last", vector)]
    )
    flags = [bool(s.ok()) for s in statuses]
    assert flags == [True, False, True], flags
    retried = collection.upsert([doc("duplicate", vector)])
    assert retried[0].ok()
    assert collection.stats.doc_count == 3
    old = [
        doc(f"old-{i}", vector, business="target", revision="old", build="old-build")
        for i in range(24)
    ]
    current = doc("current", [0.8, 0.6] + [0.0] * (dim - 2), business="target")
    assert all(s.ok() for s in collection.insert(old + [current]))
    collection.flush()
    from spikes.spike_1.contracts import open_graph

    graph = open_graph(root / "authority")
    graph.execute(
        "CREATE NODE TABLE Selection(id STRING PRIMARY KEY, revision STRING, build STRING, space STRING)"
    )
    graph.execute(
        "CREATE (:Selection {id:'target',revision:'r1',build:'build1',space:'synthetic-v1'})"
    )

    def selection():
        return {
            row[0]: tuple(row[1:])
            for row in graph.execute(
                "MATCH (s:Selection) RETURN s.id,s.revision,s.build,s.space"
            ).fetchall()
        }

    selected = selection()
    unfiltered = collection.query(vector_query(vector), topk=10)
    assert confirmed(unfiltered, selected, "synthetic-v1") == []
    attempts = []
    accepted = []
    for k in (10, 20, 40):
        begin = time.perf_counter()
        candidates = collection.query(vector_query(vector), topk=k)
        graph_start = time.perf_counter()
        accepted = confirmed(candidates, selection(), "synthetic-v1")
        graph_ms = (time.perf_counter() - graph_start) * 1000
        elapsed_ms = (time.perf_counter() - begin) * 1000
        attempts.append(
            {
                "top_k": k,
                "returned": len(candidates),
                "accepted": len(accepted),
                "query_and_validation_ms": elapsed_ms,
                "graph_validation_ms": graph_ms,
            }
        )
        if accepted:
            break
    assert [x.id for x in accepted] == ["current"], attempts
    filter_expr = "business_id = 'target' AND revision = 'r1' AND build = 'build1' AND space = 'synthetic-v1'"
    pushed = collection.query(vector_query(vector), topk=10, filter=filter_expr)
    assert [x.id for x in pushed] == ["current"]
    with graph.transaction():
        graph.execute("MATCH (s:Selection) WHERE s.id='target' SET s.revision='r2'")
    assert confirmed(pushed, selection(), "synthetic-v1") == []
    with graph.transaction():
        graph.execute("MATCH (s:Selection) WHERE s.id='target' SET s.revision='r1'")
    graph.close()
    fts = collection.query(text_query(), topk=10, filter=filter_expr)
    assert [x.id for x in fts] == ["current"]
    mismatch = False
    try:
        space_checked_query(
            collection, vector, "other-same-dimension", "synthetic-v1", topk=10
        )
    except ValueError:
        mismatch = True
    assert mismatch
    old_count = collection.stats.doc_count
    # Release all Python owners before native reopen. No public close exists.
    del collection
    gc.collect()
    collection = zvec.open(
        str(path), option=zvec.CollectionOption(read_only=1, enable_mmap=1)
    )
    assert collection.stats.doc_count == old_count
    assert [
        x.id
        for x in collection.query(vector_query(vector), topk=10, filter=filter_expr)
    ] == ["current"]
    assert [
        x.id for x in collection.query(text_query(), topk=10, filter=filter_expr)
    ] == ["current"]
    del collection
    gc.collect()
    return {
        "passed": True,
        "partial_insert_statuses": flags,
        "retry": "upsert only failed stable projection ID",
        "doc_count_after_retry": 3,
        "old_candidate_refill": attempts,
        "scalar_filter_pushdown": ["business_id", "revision", "build", "space"],
        "same_dimension_space_guard": "experimental adapter check; zvec alone does not identify model spaces",
        "readonly_reopen": True,
        "authority": "real graphdb selection; stale native-filter hits rejected after graph revision changes",
        "ann_quality": "not measured",
        "disk_bytes": disk_bytes(path),
    }


def scale(root, p, n):
    import zvec

    dim = p["vector_dimensions"]
    root = Path(root)
    path = root / "index"
    start = time.perf_counter()
    collection = zvec.create_and_open(str(path), schema(dim))
    chunks = p["chunks_per_source_revision"]
    versions = p["retained_revisions"]
    count = 0
    base = [1.0] + [0.0] * (dim - 1)
    batch = []
    for source in range(n):
        for revision in range(versions):
            for chunk in range(chunks):
                # Unit basis identifies a reproducible query group, not semantics.
                vector = [0.0] * dim
                vector[(source * chunks + chunk) % dim] = 1.0
                batch.append(
                    doc(
                        f"s{source}r{revision}u{chunk}",
                        vector,
                        business=f"s{source}u{chunk}",
                        revision=f"r{revision}",
                        build=f"build{revision}",
                        body="quasar " + ("x" * (p["chunk_bytes"] - 7)),
                    )
                )
                if len(batch) == 128:
                    statuses = collection.insert(batch)
                    assert all(s.ok() for s in statuses)
                    count += len(batch)
                    batch = []
    if batch:
        assert all(s.ok() for s in collection.insert(batch))
        count += len(batch)
    collection.flush()
    build = time.perf_counter() - start
    assert collection.stats.doc_count == n * versions * chunks == count
    expr = "revision = 'r0' AND build = 'build0' AND space = 'synthetic-v1'"
    vec = timings(
        lambda current=collection: current.query(
            vector_query(base), topk=p["top_k"], filter=expr
        ),
        p,
    )
    fts = timings(
        lambda current=collection: current.query(
            text_query(), topk=p["top_k"], filter=expr
        ),
        p,
    )
    result = collection.query(vector_query(base), topk=p["top_k"], filter=expr)
    assert result and all(d.fields["revision"] == "r0" for d in result)
    del collection
    gc.collect()
    start = time.perf_counter()
    collection = zvec.open(
        str(path), option=zvec.CollectionOption(read_only=1, enable_mmap=1)
    )
    assert collection.stats.doc_count == count
    assert collection.query(vector_query(base), topk=1, filter=expr)
    reopen = time.perf_counter() - start
    del collection
    gc.collect()
    metrics = {
        "sources": n,
        "documents": count,
        "dimensions": dim,
        "logical_input_bytes": count * p["chunk_bytes"],
        "build_seconds": build,
        "readonly_reopen_seconds": reopen,
        "peak_rss_bytes": peak_rss(),
        "disk_bytes": disk_bytes(path),
        "filtered_vector_query": vec,
        "filtered_fts_query": fts,
    }
    failed = []
    for key, value, limit in (
        ("rss", metrics["peak_rss_bytes"], p["rss_limit_bytes"]),
        ("build", build, p["build_limit_seconds"]),
        ("reopen", reopen, p["reopen_limit_seconds"]),
        ("vector_p95", vec["p95_ms"], p["query_p95_limit_ms"]),
        ("fts_p95", fts["p95_ms"], p["query_p95_limit_ms"]),
    ):
        if value > limit:
            failed.append({"metric": key, "actual": value, "limit": limit})
    return {
        "passed": not failed,
        "measurements": metrics,
        "threshold_failures": failed,
        "boundary": "synthetic vectors; fixed filter; approximate recall quality not measured",
    }
