"""Experimental effective-view comparison with an independent semantic oracle.

Both strategies persist the same raw claims/supports/corrections/dependencies.
Materialization is additional graph state; live evaluation reads raw graph rows.
This is not the production M1 domain model or a general-purpose rule engine.
"""

from __future__ import annotations

import json
import time
from pathlib import Path

from spikes.spike_1.contracts import open_graph
from spikes.validation.common import csv_copy, disk_bytes, peak_rss, timings

CLAIMS = (
    {"id": "p", "predicate": "supports", "version": "2.0", "value": True},
    {"id": "n1", "predicate": "supports", "version": "1.0", "value": False},
    {"id": "t", "predicate": "default_logging", "version": "2.0", "value": True},
    {"id": "f", "predicate": "default_logging", "version": "2.0", "value": False},
    {
        "id": "r",
        "predicate": "supports",
        "version": "2.0",
        "value": False,
        "manual": True,
    },
    {
        "id": "i",
        "predicate": "derived_capability",
        "version": "2.0",
        "value": True,
        "requires_claim": "p",
        "requires_support": "pB",
    },
)
SUPPORTS = (
    {"id": "pA", "claim": "p", "source": "A"},
    {"id": "pB", "claim": "p", "source": "B"},
    {"id": "nA", "claim": "n1", "source": "A"},
    {"id": "tA", "claim": "t", "source": "A"},
    {"id": "fB", "claim": "f", "source": "B"},
    {"id": "rM", "claim": "r", "source": "manual", "correction_only": True},
    {"id": "iA", "claim": "i", "source": "A"},
)
BASE_FLAGS = {"A": True, "B": True, "correction": False}
SCENARIOS = (
    (
        "baseline",
        BASE_FLAGS,
        {
            "selected": ["i", "n1", "p"],
            "disputed": ["f", "t"],
            "derived": ["description"],
        },
    ),
    (
        "delete_A",
        {"A": False, "B": True, "correction": False},
        {"selected": ["f", "p"], "disputed": [], "derived": ["description"]},
    ),
    (
        "delete_B",
        {"A": True, "B": False, "correction": False},
        {"selected": ["n1", "p", "t"], "disputed": [], "derived": []},
    ),
    (
        "delete_both",
        {"A": False, "B": False, "correction": False},
        {"selected": [], "disputed": [], "derived": []},
    ),
    (
        "correct",
        {"A": True, "B": True, "correction": True},
        {"selected": ["n1", "r"], "disputed": ["f", "t"], "derived": []},
    ),
    (
        "manual_survives_source_deletion",
        {"A": False, "B": False, "correction": True},
        {"selected": ["r"], "disputed": [], "derived": []},
    ),
    (
        "revoke",
        BASE_FLAGS,
        {
            "selected": ["i", "n1", "p"],
            "disputed": ["f", "t"],
            "derived": ["description"],
        },
    ),
)


def fixture(owner, flags=None):
    for claim in CLAIMS:
        yield {"kind": "claim", **claim}
    for support in SUPPORTS:
        yield {"kind": "support", **support}
    yield {"kind": "correction", "id": "replace", "target": "p", "replacement": "r"}
    yield {
        "kind": "derived",
        "id": "description",
        "requires_claim": "p",
        "requires_support": "pB",
    }
    yield {"kind": "flags", "id": "flags", **(flags or BASE_FLAGS)}


def evaluate(records):
    flags = next(x for x in records if x["kind"] == "flags")
    claims = {x["id"]: x for x in records if x["kind"] == "claim"}
    all_supports = {x["id"]: x for x in records if x["kind"] == "support"}
    active = {
        key: s
        for key, s in all_supports.items()
        if (
            (s["source"] == "manual" and flags["correction"])
            or flags.get(s["source"], False)
        )
        and (not s.get("correction_only") or flags["correction"])
    }
    origins = {
        key: sorted({s["source"] for s in active.values() if s["claim"] == key})
        for key in claims
    }
    selected = {key for key in claims if origins[key]}
    excluded = {}
    if flags["correction"]:
        selected.discard("p")
        excluded["p"] = "manual_replacement"
        # Replacement metadata follows the in-scope target association.
        origins["r"] = sorted(set(origins["r"]) | set(origins["p"]))
    disputed = set()
    groups = {}
    for key in selected:
        claim = claims[key]
        groups.setdefault((claim["predicate"], claim["version"]), []).append(key)
    for keys in groups.values():
        if len({claims[k]["value"] for k in keys}) > 1:
            disputed.update(keys)
    selected -= disputed
    for key in tuple(selected):
        claim = claims[key]
        if (
            claim.get("requires_claim") and claim["requires_claim"] not in selected
        ) or (
            claim.get("requires_support") and claim["requires_support"] not in active
        ):
            selected.remove(key)
            excluded[key] = "premise_or_support_invalid"
    derived = []
    for artifact in (x for x in records if x["kind"] == "derived"):
        if (
            artifact["requires_claim"] in selected
            and artifact["requires_support"] in active
        ):
            derived.append(artifact["id"])
    return {
        "selected": sorted(selected),
        "disputed": sorted(disputed),
        "derived": sorted(derived),
        "origins": origins,
        "excluded": excluded,
        "correction_active": flags["correction"],
        "active_supports": {
            k: {"claim": v["claim"], "source": v["source"]} for k, v in active.items()
        },
    }


def scoped(view, allowed):
    allowed = set(allowed)
    result = {
        "selected": [],
        "disputed": [],
        "derived": [],
        "citations": {},
        "manual_metadata": [],
    }
    for channel in ("selected", "disputed"):
        for claim in view[channel]:
            if not set(view["origins"][claim]) & allowed:
                continue
            if claim == "i" and not {"A", "B"} <= allowed:
                continue
            result[channel].append(claim)
            evidence = sorted(
                {
                    s["source"]
                    for s in view["active_supports"].values()
                    if s["claim"] == claim and s["source"] in allowed
                }
            )
            if claim == "r" and view["correction_active"]:
                evidence = sorted(set(evidence) | {"manual"})
                result["manual_metadata"].append("replace")
            result["citations"][claim] = evidence
    if "B" in allowed:
        result["derived"] = view["derived"]
    return result


def assert_oracle(view, expected):
    for key in ("selected", "disputed", "derived"):
        assert view[key] == expected[key], (key, view[key], expected[key])


def raw(c, owner):
    return [
        json.loads(row[0])
        for row in c.execute(
            "MATCH (r:Raw) WHERE r.owner=$id RETURN r.payload", {"id": owner}
        ).fetchall()
    ]


def read(c, owner, strategy, allowed):
    if strategy == "live":
        view = evaluate(raw(c, owner))
    else:
        view = json.loads(
            c.execute(
                "MATCH (v:View) WHERE v.id=$id RETURN v.payload", {"id": owner}
            ).fetchall()[0][0]
        )
    return scoped(view, allowed)


def change(c, owner, flags, strategy):
    rows = list(fixture(owner, flags))
    payload = next(row for row in rows if row["kind"] == "flags")
    c.execute(
        "MATCH (r:Raw) WHERE r.id=$id SET r.payload=$payload",
        {"id": owner + ":flags", "payload": json.dumps(payload, sort_keys=True)},
    )
    if strategy == "materialized":
        # Evaluate actual transaction-local raw rows, then atomically replace view.
        view = evaluate(raw(c, owner))
        c.execute(
            "MATCH (v:View) WHERE v.id=$id SET v.payload=$payload",
            {"id": owner, "payload": json.dumps(view, sort_keys=True)},
        )


def run(root, p, n, strategy):
    root = Path(root)
    path = root / "graph"
    c = open_graph(path)
    start = time.perf_counter()
    try:
        c.execute(
            "CREATE NODE TABLE Raw(id STRING PRIMARY KEY, owner STRING, kind STRING, payload STRING)"
        )
        c.execute("CREATE NODE TABLE View(id STRING PRIMARY KEY, payload STRING)")
        count, _ = csv_copy(
            c,
            root,
            "Raw",
            ("id", "owner", "kind", "payload"),
            (
                (
                    f"e{i}:" + row["id"],
                    f"e{i}",
                    row["kind"],
                    json.dumps(row, sort_keys=True),
                )
                for i in range(n)
                for row in fixture(f"e{i}")
            ),
        )
        view_count = 0
        if strategy == "materialized":
            view_count, _ = csv_copy(
                c,
                root,
                "View",
                ("id", "payload"),
                (
                    (
                        f"e{i}",
                        json.dumps(evaluate(list(fixture(f"e{i}"))), sort_keys=True),
                    )
                    for i in range(n)
                ),
            )
        build = time.perf_counter() - start
        semantic_checks = []
        for label, flags, expected in SCENARIOS:
            with c.transaction():
                change(c, "e0", flags, strategy)
            view = (
                evaluate(raw(c, "e0"))
                if strategy == "live"
                else json.loads(
                    c.execute(
                        "MATCH (v:View) WHERE v.id='e0' RETURN v.payload"
                    ).fetchall()[0][0]
                )
            )
            assert_oracle(view, expected)
            semantic_checks.append(label)
        base = read(c, "e0", strategy, ("A",))
        assert (
            base["selected"] == ["n1", "p"]
            and base["disputed"] == ["t"]
            and not base["derived"]
        ), base
        assert base["citations"]["p"] == ["A"]
        with c.transaction():
            change(c, "e0", {"A": True, "B": True, "correction": True}, strategy)
        scoped_correct = read(c, "e0", strategy, ("A",))
        assert scoped_correct["selected"] == ["n1", "r"] and scoped_correct[
            "manual_metadata"
        ] == ["replace"]
        assert scoped_correct["citations"]["r"] == ["manual"]
        with c.transaction():
            change(c, "e0", BASE_FLAGS, strategy)
        semantic_checks += [
            "scope_does_not_resolve_global_dispute",
            "scope_filters_supports_and_description",
            "manual_metadata_follows_target",
        ]
        counter = iter(range(10**9))

        def query():
            owner = f"e{next(counter) % n}"
            result = read(c, owner, strategy, ("A", "B", "manual"))
            assert result["selected"] == ["i", "n1", "p"] and result["disputed"] == [
                "f",
                "t",
            ]
            return result

        latency = timings(query, p)
        metrics_before = c.storage_metrics
        update_start = time.perf_counter()
        writes = 0
        for flags in (
            {"A": True, "B": True, "correction": True},
            BASE_FLAGS,
            {"A": True, "B": False, "correction": False},
            BASE_FLAGS,
        ):
            # Chunked publication transactions limit native write-set size.
            for begin in range(0, n, 100):
                with c.transaction():
                    for i in range(begin, min(begin + 100, n)):
                        change(c, f"e{i}", flags, strategy)
                        writes += 1 + (strategy == "materialized")
        update_seconds = time.perf_counter() - update_start
        after = c.storage_metrics
        assert query()["selected"] == ["i", "n1", "p"]
    finally:
        c.close()
    begin = time.perf_counter()
    c = open_graph(path, True)
    try:
        assert read(c, "e0", strategy, ("A", "B", "manual"))["selected"] == [
            "i",
            "n1",
            "p",
        ]
        reopen = time.perf_counter() - begin
    finally:
        c.close()
    metrics = {
        "entities": n,
        "strategy": strategy,
        "raw_nodes": count,
        "extra_materialized_nodes": view_count,
        "build_seconds": build,
        "update_seconds": update_seconds,
        "logical_update_record_writes": writes,
        "peak_rss_bytes": peak_rss(),
        "disk_bytes": disk_bytes(path),
        "readonly_reopen_seconds": reopen,
        "query": latency,
        "storage_metrics_before_updates": metrics_before,
        "storage_metrics_after_updates": after,
    }
    failures = []
    for key, value, limit in (
        ("rss", metrics["peak_rss_bytes"], p["rss_limit_bytes"]),
        ("build", build, p["build_limit_seconds"]),
        ("update", update_seconds, p["build_limit_seconds"]),
        ("reopen", reopen, p["reopen_limit_seconds"]),
        ("p95", latency["p95_ms"], p["query_p95_limit_ms"]),
    ):
        if value > limit:
            failures.append({"metric": key, "actual": value, "limit": limit})
    return {
        "passed": not failures,
        "semantic_oracle_cases": semantic_checks,
        "measurements": metrics,
        "threshold_failures": failures,
        "boundary": "experimental single-entity domain; serial query/update; no general inference or concurrent throughput claim",
    }
