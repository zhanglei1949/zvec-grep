"""Fetch/register pinned sources; never mutate the caller's source mirrors."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCK = Path(__file__).with_name("dependencies.json")


def run(*args: str, cwd: Path | None = None, capture: bool = False) -> str:
    print("+", *args, flush=True)
    result = subprocess.run(
        args,
        cwd=ROOT if cwd is None else cwd,
        env={**os.environ, "GIT_TERMINAL_PROMPT": "0"},
        check=True,
        text=True,
        stdout=subprocess.PIPE if capture else None,
    )
    return result.stdout.strip() if capture else ""


def dependencies() -> list[dict]:
    return json.loads(LOCK.read_text())["dependencies"]


def build_sources() -> list[dict]:
    return json.loads(LOCK.read_text()).get("build_sources", [])


def excluded_paths(dep: dict) -> set[str]:
    return {
        f"{parent}/{relative}"
        for parent, paths in dep.get("excluded_submodules", {}).items()
        for relative in paths
    }


def exclude_submodules(parent: Path, exclusions: dict) -> None:
    """Skip explicitly listed test data; do not change upstream .gitmodules."""
    for repository, paths in exclusions.items():
        source = parent / repository
        mappings = run(
            "git",
            "config",
            "-f",
            ".gitmodules",
            "--get-regexp",
            r"^submodule\..*\.path$",
            cwd=source,
            capture=True,
        )
        by_path = {line.split()[1]: line.split()[0] for line in mappings.splitlines()}
        for relative in paths:
            key = by_path[relative].removesuffix(".path") + ".update"
            run("git", "config", key, "none", cwd=source)


def sparse_submodules(parent: Path, selections: dict) -> None:
    """Fetch only required blobs, retaining Git identity and top-level notices."""
    for relative, directories in selections.items():
        target = parent / relative
        expected = run("git", "rev-parse", "HEAD:" + relative, cwd=parent, capture=True)
        mappings = run(
            "git",
            "config",
            "-f",
            ".gitmodules",
            "--get-regexp",
            r"^submodule\..*\.path$",
            cwd=parent,
            capture=True,
        )
        key = next(
            line.split()[0]
            for line in mappings.splitlines()
            if line.split()[1] == relative
        )
        url = run(
            "git",
            "config",
            "-f",
            ".gitmodules",
            "--get",
            key.removesuffix(".path") + ".url",
            cwd=parent,
            capture=True,
        )
        if not (target / ".git").exists():
            if target.exists() and any(target.iterdir()):
                raise RuntimeError(
                    f"Refusing nonempty unregistered submodule: {target}"
                )
            target.mkdir(parents=True, exist_ok=True)
            run("git", "init", str(target))
            run("git", "remote", "add", "origin", url, cwd=target)
        run("git", "config", "remote.origin.promisor", "true", cwd=target)
        run(
            "git", "config", "remote.origin.partialclonefilter", "blob:none", cwd=target
        )
        run(
            "git",
            "fetch",
            "--depth=1",
            "--filter=blob:none",
            "origin",
            expected,
            cwd=target,
        )
        run("git", "sparse-checkout", "init", "--cone", cwd=target)
        run("git", "sparse-checkout", "set", "--cone", *directories, cwd=target)
        run("git", "checkout", "--detach", expected, cwd=target)
        run("git", "submodule", "init", "--", relative, cwd=parent)
        run("git", "submodule", "absorbgitdirs", "--", relative, cwd=parent)


def register_source(dep: dict) -> None:
    """Register a pinned checkout relative to its containing Git repository."""
    repository = Path(
        run("git", "rev-parse", "--show-toplevel", capture=True)
    ).resolve()
    target = ROOT / dep["path"]
    relative = target.resolve().relative_to(repository).as_posix()
    prefix = ROOT.resolve().relative_to(repository).parts
    name = "-".join((*prefix, dep["name"]))
    entry = run(
        "git", "ls-files", "--stage", "--", relative, cwd=repository, capture=True
    )
    if not entry:
        run(
            "git",
            "submodule",
            "add",
            "--name",
            name,
            dep["url"],
            relative,
            cwd=repository,
        )
    elif not entry.startswith("160000 " + dep["commit"] + " "):
        raise RuntimeError(f"Existing gitlink disagrees with lock: {entry}")
    if (target / ".git").is_dir():
        run("git", "submodule", "absorbgitdirs", "--", relative, cwd=repository)


def prepare(dep: dict, mirror_dir: Path | None, jobs: int) -> None:
    target = ROOT / dep["path"]
    # A clone without initialized submodules can leave an empty checkout directory.
    if target.is_dir() and not any(target.iterdir()):
        target.rmdir()
    if not target.exists():
        mirror = mirror_dir / dep["name"] if mirror_dir else None
        if mirror and (mirror / ".git").exists():
            # A standalone object database, with no alternates or shared worktree.
            run(
                "git",
                "clone",
                "--no-hardlinks",
                "--no-checkout",
                str(mirror),
                str(target),
            )
            run("git", "remote", "set-url", "origin", dep["url"], cwd=target)
        else:
            target.mkdir(parents=True)
            run("git", "init", str(target))
            run("git", "remote", "add", "origin", dep["url"], cwd=target)
    if not (target / ".git").exists():
        raise RuntimeError(f"Refusing non-Git directory: {target}")
    # clone --no-checkout has HEAD but no worktree/index yet; status reports
    # every tracked file as deleted. Only this entirely empty case is safe.
    empty_checkout = {p.name for p in target.iterdir()} == {".git"}
    dirty = run(
        "git",
        "status",
        "--porcelain",
        "--untracked-files=no",
        "--ignore-submodules=all",
        cwd=target,
        capture=True,
    )
    if dirty and not empty_checkout:
        raise RuntimeError(
            f"Refusing to reset modified dependency {target}: {dirty[:500]}"
        )
    fetch_filter = []
    if dep.get("sparse_checkout"):
        run("git", "config", "remote.origin.promisor", "true", cwd=target)
        run(
            "git", "config", "remote.origin.partialclonefilter", "blob:none", cwd=target
        )
        fetch_filter = ["--filter=blob:none"]
    available = (
        subprocess.run(
            ["git", "cat-file", "-e", dep["commit"] + "^{commit}"],
            cwd=target,
            capture_output=True,
            env={**os.environ, "GIT_NO_LAZY_FETCH": "1"},
        ).returncode
        == 0
    )
    if not available:
        run(
            "git",
            "fetch",
            "--depth=1",
            *fetch_filter,
            "origin",
            dep["commit"],
            cwd=target,
        )
    if dep.get("sparse_checkout"):
        run("git", "sparse-checkout", "init", "--cone", cwd=target)
        run(
            "git",
            "sparse-checkout",
            "set",
            "--cone",
            *dep["sparse_checkout"],
            cwd=target,
        )
    run("git", "checkout", "--detach", dep["commit"], cwd=target)
    actual = run("git", "rev-parse", "HEAD", cwd=target, capture=True)
    if actual != dep["commit"]:
        raise RuntimeError(f"Wrong revision for {dep['name']}: {actual}")
    register_source(dep)
    if (target / ".gitmodules").exists():
        sparse_submodules(target, dep.get("sparse_submodules", {}))
        exclude_submodules(target, dep.get("excluded_submodules", {}))
        run(
            "git",
            "submodule",
            "update",
            "--init",
            "--recursive",
            "--depth=1",
            f"--jobs={jobs}",
            cwd=target,
        )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--mirror-dir", type=Path, help="Optional existing local checkouts; read only"
    )
    parser.add_argument(
        "--only",
        nargs="+",
        choices=[d["name"] for d in dependencies() + build_sources()],
    )
    parser.add_argument("--jobs", type=int, default=2)
    args = parser.parse_args()
    if args.jobs < 1:
        parser.error("--jobs must be positive")
    (ROOT / "thirdparty").mkdir(exist_ok=True)
    for dep in dependencies() + build_sources():
        if not args.only or dep["name"] in args.only:
            prepare(dep, args.mirror_dir, args.jobs)


if __name__ == "__main__":
    main()
