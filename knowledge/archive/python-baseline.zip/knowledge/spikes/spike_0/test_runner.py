"""Guard against reporting success after blocked builds or native crashes."""

from __future__ import annotations

import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import run


class RunnerClassificationTests(unittest.TestCase):
    def test_unverified_dependency_blocks_without_running_native_code(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch.object(run.subprocess, "run") as process:
                result = run.run_case(
                    "graphdb_persistence",
                    Path(directory),
                    {"graphdb": {"status": "blocked"}},
                    1,
                )
            self.assertEqual(result["status"], "blocked")
            process.assert_not_called()

    def test_missing_result_is_failure_even_if_worker_returns_zero(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with (
                patch.object(run, "ROOT", root),
                patch.object(
                    run.subprocess,
                    "run",
                    return_value=subprocess.CompletedProcess([], 0),
                ),
            ):
                result = run.run_case(
                    "graphdb_persistence",
                    root,
                    {"graphdb": {"status": "verified"}},
                    1,
                )
            self.assertEqual(result["status"], "failed")
            self.assertEqual(len(result["phases"]), 1)

    def test_native_failure_cannot_reuse_successful_payload(self):
        def crash(command, **kwargs):
            result_path = Path(command[command.index("--result") + 1])
            result_path.write_text(json.dumps({"status": "passed"}))
            return subprocess.CompletedProcess(command, -6)

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with (
                patch.object(run, "ROOT", root),
                patch.object(run.subprocess, "run", side_effect=crash),
            ):
                result = run.run_case(
                    "graphdb_persistence",
                    root,
                    {"graphdb": {"status": "verified"}},
                    1,
                )
            self.assertEqual(result["status"], "failed")
            self.assertEqual(result["phases"][0]["returncode"], -6)


if __name__ == "__main__":
    unittest.main()
