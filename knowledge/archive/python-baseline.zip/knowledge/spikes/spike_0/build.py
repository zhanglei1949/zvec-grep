"""Build pinned native sources into wheels and install in this repo's venv."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from bootstrap import ROOT, build_sources, dependencies, excluded_paths

ARTIFACTS = ROOT / ".artifacts" / "spike-0"


def output(*command: str, cwd: Path = ROOT) -> str:
    return subprocess.check_output(command, cwd=cwd, text=True).strip()


def build(dep: dict, jobs: int, libcxx_fallback: bool = False) -> dict:
    source = ROOT / dep["path"]
    log_dir = ARTIFACTS / "build"
    wheel_dir = ARTIFACTS / "wheels" / dep["name"]
    log_dir.mkdir(parents=True, exist_ok=True)
    wheel_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / (dep["name"] + ".log")
    receipt_path = log_dir / (dep["name"] + ".json")
    receipt = {
        "dependency": dep["name"],
        "commit": dep["commit"],
        "started_at": datetime.now(timezone.utc).isoformat(),
        "python": sys.version,
        "executable": sys.executable,
        "top_level_build_jobs": jobs,
        "log": str(log_path.relative_to(ROOT)),
        "status": "failed",
        "source_variant": "unmodified",
    }
    started = time.monotonic()
    try:
        if output("git", "rev-parse", "HEAD", cwd=source) != dep["commit"]:
            raise RuntimeError("Source checkout does not match dependencies.json")
        subprocess.run(
            ["git", "diff", "--quiet", "--ignore-submodules=all", "HEAD"],
            cwd=source,
            check=True,
        )
        submodules = output("git", "submodule", "status", "--recursive", cwd=source)
        excluded = excluded_paths(dep)
        for line in submodules.splitlines():
            path = line[1:].split()[1]
            if line.startswith(("+", "U")) or (
                line.startswith("-") and path not in excluded
            ):
                raise RuntimeError(f"Missing or mismatched submodule: {path}")
        receipt["submodules_before"] = submodules
        receipt["excluded_test_data_submodules"] = sorted(excluded)
        build_source = source
        if dep["name"] == "graphdb" and libcxx_fallback:
            # Keep the pinned checkout intact; the opt-in variant is explicit.
            variant_parent = ARTIFACTS / "source-variants"
            variant_parent.mkdir(parents=True, exist_ok=True)
            build_source = variant_parent / (
                "graphdb-libcxx-"
                + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
            )
            shutil.copytree(
                source,
                build_source,
                symlinks=True,
                ignore=shutil.ignore_patterns(
                    ".git", "build", "__pycache__", "*.egg-info"
                ),
            )
            patch = ROOT / dep["optional_libcxx_patch"]
            subprocess.run(
                ["patch", "--batch", "--forward", "-p1", "-i", str(patch)],
                cwd=build_source,
                check=True,
            )
            receipt["source_variant"] = "libcxx-csv-fallback"
            receipt["patches"] = [
                {
                    "path": str(patch.relative_to(ROOT)),
                    "sha256": hashlib.sha256(patch.read_bytes()).hexdigest(),
                }
            ]
        receipt["build_source"] = str(build_source.relative_to(ROOT))
        environment = {
            **os.environ,
            "PATH": str(Path(sys.executable).parent)
            + os.pathsep
            + os.environ.get("PATH", ""),
            "CMAKE_BUILD_PARALLEL_LEVEL": str(jobs),
            "ZKG_BUILD_JOBS": str(jobs),
            "PIP_DISABLE_PIP_VERSION_CHECK": "1",
        }
        cmake_args = [os.environ.get("CMAKE_ARGS", "")]
        receipt["build_sources"] = []
        extra_sources = {item["name"]: item for item in build_sources()}
        for name in dep.get("required_build_sources", []):
            item = extra_sources[name]
            checkout = ROOT / item["path"]
            if output("git", "rev-parse", "HEAD", cwd=checkout) != item["commit"]:
                raise RuntimeError(f"Build source revision mismatch: {name}")
            subprocess.run(["git", "diff", "--quiet", "HEAD"], cwd=checkout, check=True)
            cmake_args.append(f"-D{item['cmake_override']}={checkout}")
            receipt["build_sources"].append(
                {
                    **item,
                    "license_sha256": hashlib.sha256(
                        (checkout / item["license_file"]).read_bytes()
                    ).hexdigest(),
                }
            )
        if dep["name"] == "zvec":
            cmake_args += [
                "-DBUILD_TOOLS=OFF",
                "-DBUILD_C_BINDINGS=OFF",
                f"-DCMAKE_MODULE_PATH={Path(__file__).parent / 'cmake'}",
            ]
        if dep["name"] == "graphdb":
            cmake_args += ["-DBUILD_TESTING=OFF"]
        environment["CMAKE_ARGS"] = " ".join(cmake_args).strip()
        receipt["cmake_args"] = environment["CMAKE_ARGS"]
        receipt["cmake_version"] = output(
            str(Path(sys.executable).parent / "cmake"), "--version"
        ).splitlines()[0]
        command = [
            sys.executable,
            "-m",
            "pip",
            "wheel",
            "--verbose",
            "--no-build-isolation",
            "--no-deps",
            "--no-index",
            "--wheel-dir",
            str(wheel_dir),
            str(build_source),
        ]
        if dep["name"] == "zvec":
            # The wheel installs only the python component; avoid unrelated SDK
            # targets. _zvec force_loads the core_* static libs by path without a
            # CMake target dependency, so they must be listed explicitly or the
            # final link fails with "libcore_knn_flat.a not found".
            zvec_targets = [
                "core_knn_flat_static",
                "core_knn_flat_sparse_static",
                "core_knn_hnsw_static",
                "core_knn_hnsw_rabitq_static",
                "core_knn_hnsw_sparse_static",
                "core_knn_ivf_static",
                "core_knn_vamana_static",
                "core_knn_cluster_static",
                "core_knn_diskann_static",
                "core_mix_reducer_static",
                "core_metric_static",
                "core_utility_static",
                "core_quantizer_static",
                "_zvec",
            ]
            for target in zvec_targets:
                command.append(f"--config-settings=build.targets={target}")
            receipt["build_target"] = zvec_targets
        print(
            f"Building {dep['name']} ({dep['commit'][:12]}), log: {log_path}",
            flush=True,
        )
        with log_path.open("w") as log:
            log.write(
                json.dumps(
                    {"command": command, "cmake_args": environment["CMAKE_ARGS"]}
                )
                + "\n"
            )
            log.flush()
            subprocess.run(
                command,
                cwd=ROOT,
                env=environment,
                stdout=log,
                stderr=subprocess.STDOUT,
                check=True,
            )
            wheels = list(wheel_dir.glob("*.whl"))
            if len(wheels) != 1:
                raise RuntimeError(
                    "Expected exactly one wheel; remove stale wheels explicitly"
                )
            wheel = wheels[0]
            subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "pip",
                    "install",
                    "--no-index",
                    "--no-deps",
                    "--force-reinstall",
                    str(wheel),
                ],
                cwd=ROOT,
                env=environment,
                stdout=log,
                stderr=subprocess.STDOUT,
                check=True,
            )
        receipt.update(
            {
                "status": "passed",
                "wheel": str(wheel.relative_to(ROOT)),
                "wheel_sha256": hashlib.sha256(wheel.read_bytes()).hexdigest(),
                "source_status_after": output(
                    "git",
                    "status",
                    "--porcelain",
                    "--untracked-files=no",
                    "--ignore-submodules=none",
                    cwd=source,
                ),
                "submodules_after": output(
                    "git", "submodule", "status", "--recursive", cwd=source
                ),
            }
        )
    except (OSError, RuntimeError, subprocess.CalledProcessError) as error:
        receipt["error"] = f"{type(error).__name__}: {str(error)[:1000]}"
        with log_path.open("a") as log:
            log.write("\nBuild driver failure: " + receipt["error"] + "\n")
        print(
            f"FAILED {dep['name']}: {receipt['error'][:500]}; see {log_path}",
            flush=True,
        )
    finally:
        receipt["duration_seconds"] = round(time.monotonic() - started, 3)
        receipt["finished_at"] = datetime.now(timezone.utc).isoformat()
        receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
    print(
        f"{dep['name']}: {receipt['status']} ({receipt['duration_seconds']}s)",
        flush=True,
    )
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--only", nargs="+", choices=[d["name"] for d in dependencies()]
    )
    parser.add_argument("--jobs", type=int, default=14)
    parser.add_argument(
        "--graphdb-libcxx-fallback",
        action="store_true",
        help="Opt in to a recorded CSV portability patch in an independent source copy",
    )
    args = parser.parse_args()
    if Path(sys.prefix).resolve() != (ROOT / ".venv").resolve():
        parser.error(
            "Run with .venv/bin/python; global environment installation is forbidden"
        )
    if args.jobs < 1:
        parser.error("--jobs must be positive")
    # Build small independent bindings before the larger zvec dependency tree.
    order = [
        "graphdb",
        "py-tree-sitter",
        "tree-sitter-python",
        "tree-sitter-cpp",
        "zvec",
    ]
    by_name = {dep["name"]: dep for dep in dependencies()}
    results = [
        build(by_name[name], args.jobs, args.graphdb_libcxx_fallback)
        for name in order
        if not args.only or name in args.only
    ]
    return 0 if all(r["status"] == "passed" for r in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
