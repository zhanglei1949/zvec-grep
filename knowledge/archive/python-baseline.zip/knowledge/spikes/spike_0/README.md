# Spike-0：固定源码与原生运行验证

目标是在同一 Python 环境构建并运行 graphdb、zvec、Tree-sitter Python 绑定及 Python/C++ grammar。验证真实图读写、全文/向量检索、正常关闭后的跨进程重开，以及 UTF-8 位置和语法错误诊断。这里的脚本是试验工具，不是正式 SDK。

## 准备

需要 Git、CPython 3.11+、C/C++ 编译工具链和首次获取依赖的网络。当前实测环境与结果见 [结果报告](SPIKE0_REPORT.md)，不能据此声称其他平台已经通过。

源码由 [dependencies.json](dependencies.json) 和根目录 gitlink 固定。graphdb/zvec 沿用设计提交；绑定与 grammar 选择明确 tag 对应的提交。bootstrap 只操作本项目下的依赖目录，拒绝覆盖已有修改，可使用本地 Git 仓库作为只读对象来源：

```sh
python3 spikes/spike_0/bootstrap.py --jobs 2
```

可选 `--mirror-dir /path/to/checkouts`，其中目录名与依赖名一致。使用独立 clone，不保留 alternates，也不复用镜像的工作区或编译产物。Kuzu 只稀疏检出 ANTLR runtime 与生成的解析器，Arrow 只检出 cpp 子树，cone 模式保留根目录文件及许可证；提交不变，不以其他版本源码替代。清单明确排除 Arrow 的两个测试数据 submodule，通过本地 Git 配置 `update=none` 跳过；生产构建不使用这些数据，原始 gitlink 不变。构建回执记录排除项，其他缺失或错版 submodule 仍拒绝构建。已有 checkout 也使用 bootstrap 准备，避免无条件递归拉取大型测试数据。

ARM 构建还需要 SIMDe。bootstrap 将上游 `v0.8.2` 固定为 `71fd833d9666141edcd1d3c109a80e228303d8d7`，主仓库稀疏检出头文件与根目录文件，递归 gitlink 另按固定提交准备；通过 `FETCHCONTENT_SOURCE_DIR_SIMDE` 交给 zvec，避免 CMake 再克隆完整历史。它是独立 gitlink，在清单的 `build_sources` 中记录，不是第六个 Python 包。

```sh
python3 -m venv .venv
.venv/bin/python -m pip install --require-hashes --no-deps -r spikes/spike_0/requirements.lock
.venv/bin/python spikes/spike_0/build.py --jobs 14
```

构建工具与 NumPy 使用带哈希锁文件；五个原生包都从本仓库固定源码构建 wheel，再安装到 `.venv`，不使用包索引中的同名二进制替代。默认 graphdb 保留完整 Cypher、IPC 与持久 TP 支持；zvec 关闭无关工具和 C binding，只构建 wheel 安装所需的 `_zvec` 目标及其依赖。本地 CMake ProcessorCount 适配将上游按 NPROC 发起的 ExternalProject 并行度限制在 `--jobs` 内，避免仅限制顶层构建。适配文件与实际 CMake 参数均可审查，不修改主依赖源码；这不等于全部进程合计的并行度或 RSS 硬限制。

本次 Apple Clang 16/libc++ 的未修改 graphdb 构建在浮点 `std::from_chars` 处失败。可显式选择本轮的 [兼容补丁](patches/graphdb-libcxx-csv-fallback.patch)，在独立源码副本中跳过 libc++ 浮点 CSV 解析优化，沿用已有 `ParseScalarTyped` 路径：

```sh
.venv/bin/python spikes/spike_0/build.py --only graphdb --jobs 14 --graphdb-libcxx-fallback
```

该选项保留固定 checkout，回执记录变体、补丁哈希及实际构建目录；默认构建不会自动应用补丁。使用补丁后，运行报告的 `unmodified_source_builds` 为 false，即使六项运行通过，也只表示该兼容变体通过，不能记为原始提交在此工具链直接通过。图侧用例额外验证 DOUBLE/FLOAT 的十进制、指数、符号输入与正常重开。

首次构建时，上游 zvec 的 CMake 还可能下载其 Arrow 等依赖并对嵌套源码应用已有补丁；本脚本不宣称首次构建已离线。构建后检查 receipt、嵌套 submodule 和修改状态；bootstrap 对修改的拒绝用于保护源码，不会自动 reset 构建产生的补丁。运行时验证使用预计算向量，无 LLM、模型下载或云端 API。

本次后续下载使用上游提供的 OSS 镜像选项，Arrow 仍按其构建脚本中的哈希验证归档。该选项和 SIMDe 源码覆盖参数都进入构建回执：

```sh
CMAKE_ARGS='-DUSE_OSS_MIRROR=ON' .venv/bin/python spikes/spike_0/build.py --only zvec --jobs 14
```

## 运行与结果

```sh
.venv/bin/python spikes/spike_0/run.py
.venv/bin/python -m unittest discover -s spikes/spike_0 -p 'test_*.py' -v
.venv/bin/ruff check spikes/spike_0
```

统一运行入口执行六个检查：

| 检查 | 判定 |
| --- | --- |
| 两种导入顺序 | graphdb、zvec、绑定与两种 grammar 在同一子进程导入并实际执行原生操作 |
| graphdb 持久 TP | 创建点边、参数化写入与 Cypher 查询；正常关闭后由另一个进程重开核对 |
| zvec 全文与向量 | 检查逐项插入状态、flush、全文词项与固定向量命中；另一个进程重开后重复查询 |
| Python/C++ 解析 | 分别校验函数名、左闭右开字节范围、UTF-8 偏移和错误输入诊断 |

每个检查保留独立进程日志和 JSON，进程崩溃、超时或缺少结果均不能判成功。依赖未构建或安装包不匹配构建 wheel 时标记 blocked。默认退出码为 0=全部所选检查通过、1=有失败、2=有阻塞；这不是未来正式 CLI 退出码设计。

`.artifacts/spike-0/build/` 保存构建日志和源码/wheel 回执，`runs/<run-id>/report.json` 保存每次实测，`latest.json` 指向最近结果。`--only` 仅运行指定子集，报告的 `complete_suite` 为 false 时不能宣称整套 Spike-0 通过。数据和原始产物被 Git 忽略，精简后的实际结果单独保存在本目录。

构建可通过 `--only graphdb` 等选项单独重试。所有安装限制在 `.venv`，构建不修改另外的 graphdb/zvec 检出。许可证按固定源码记录：graphdb 当前没有顶层项目许可证声明，不能用其第三方通知替代；技术检查通过不代表依赖许可和发布条件全部齐备。

## 验证边界

Spike-0 不验证崩溃恢复、并发隔离、提交可见性上限、资源规模或生产检索质量；正常关闭后的重开不能替代断电/进程中断验证。容量、有效视图与故障注入继续按 Spike-1/2 的 profile 和判定门开展。
