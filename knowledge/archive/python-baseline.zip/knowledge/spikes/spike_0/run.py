"""Run real Spike-0 checks in isolated processes, preserving JSON and logs."""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
import platform
import shutil
import subprocess
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path

from bootstrap import ROOT, build_sources, dependencies, excluded_paths

ARTIFACTS = ROOT / ".artifacts" / "spike-0"
ALL = [dep["name"] for dep in dependencies()]
CASES = {
    "combined_forward": (ALL, ["combined"]),
    "combined_reverse": (ALL, ["combined_reverse"]),
    "graphdb_persistence": (["graphdb"], ["graph_write", "graph_read"]),
    "zvec_fulltext_vector_persistence": (["zvec"], ["zvec_write", "zvec_read"]),
    "tree_sitter_python": (["py-tree-sitter", "tree-sitter-python"], ["python"]),
    "tree_sitter_cpp": (["py-tree-sitter", "tree-sitter-cpp"], ["cpp"]),
}


def provenance(dep: dict) -> dict:
    source = ROOT / dep["path"]
    receipt = ARTIFACTS / "build" / (dep["name"] + ".json")
    result = {
        "commit": dep["commit"],
        "license_spdx": dep["license_spdx"],
        "excluded_test_data_submodules": sorted(excluded_paths(dep)),
    }
    try:
        actual = subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=source, text=True
        ).strip()
        if actual != dep["commit"]:
            raise ValueError("source revision mismatch")
        record = json.loads(receipt.read_text())
        if record["status"] != "passed" or record["commit"] != actual:
            raise ValueError("no successful build receipt for pinned revision")
        for patch in record.get("patches", []):
            if (
                hashlib.sha256((ROOT / patch["path"]).read_bytes()).hexdigest()
                != patch["sha256"]
            ):
                raise ValueError("compatibility patch changed since wheel build")
        extra_sources = {item["name"]: item for item in build_sources()}
        recorded_sources = {
            item["name"]: item for item in record.get("build_sources", [])
        }
        for name in dep.get("required_build_sources", []):
            item = extra_sources[name]
            if recorded_sources.get(name, {}).get("commit") != item["commit"]:
                raise ValueError(f"missing pinned build-source receipt: {name}")
            actual_source = subprocess.check_output(
                ["git", "rev-parse", "HEAD"],
                cwd=ROOT / item["path"],
                text=True,
            ).strip()
            if actual_source != item["commit"]:
                raise ValueError(f"build source revision mismatch: {name}")
        wheel = ROOT / record["wheel"]
        if hashlib.sha256(wheel.read_bytes()).hexdigest() != record["wheel_sha256"]:
            raise ValueError("built wheel hash mismatch")
        distribution = importlib.metadata.distribution(dep["package"])
        direct = json.loads(distribution.read_text("direct_url.json") or "{}")
        installed_hash = direct.get("archive_info", {}).get("hashes", {}).get("sha256")
        if installed_hash != record["wheel_sha256"]:
            raise ValueError("installed distribution does not match the built wheel")
        result.update(
            {
                "status": "verified",
                "package_version": distribution.version,
                "wheel_sha256": installed_hash,
                "source_variant": record.get("source_variant", "unmodified"),
                "patches": record.get("patches", []),
                "build_sources": record.get("build_sources", []),
            }
        )
        if dep["license_file"]:
            license_path = source / dep["license_file"]
            result["license_sha256"] = hashlib.sha256(
                license_path.read_bytes()
            ).hexdigest()
        else:
            result["license_note"] = dep["license_note"]
    except (
        OSError,
        ValueError,
        KeyError,
        subprocess.CalledProcessError,
        importlib.metadata.PackageNotFoundError,
    ) as error:
        result.update({"status": "blocked", "reason": str(error)})
    return result


def run_case(name: str, folder: Path, sources: dict, timeout: float) -> dict:
    required, phases = CASES[name]
    missing = [dep for dep in required if sources[dep]["status"] != "verified"]
    if missing:
        return {"status": "blocked", "dependencies": missing}
    case_dir = folder / name
    case_dir.mkdir()
    results = []
    environment = {
        k: v for k, v in os.environ.items() if k not in {"PYTHONPATH", "PYTHONHOME"}
    }
    environment["PYTHONNOUSERSITE"] = "1"
    for phase in phases:
        result_path = case_dir / (phase + ".json")
        log_path = case_dir / (phase + ".log")
        command = [
            sys.executable,
            "-I",
            str(Path(__file__).with_name("worker.py")),
            "--case",
            phase,
            "--path",
            str(case_dir / "data"),
            "--result",
            str(result_path),
        ]
        try:
            with log_path.open("w") as log:
                process = subprocess.run(
                    command,
                    cwd=ROOT,
                    env=environment,
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    timeout=timeout,
                )
            details = (
                json.loads(result_path.read_text())
                if result_path.exists()
                else {"status": "failed", "error": "worker exited without a result"}
            )
            details.update(
                {
                    "phase": phase,
                    "returncode": process.returncode,
                    "log": str(log_path.relative_to(ROOT)),
                }
            )
            if process.returncode != 0:
                details["status"] = "failed"
        except subprocess.TimeoutExpired:
            details = {
                "phase": phase,
                "status": "failed",
                "error": f"worker exceeded {timeout}s",
                "log": str(log_path.relative_to(ROOT)),
            }
        results.append(details)
        if details["status"] != "passed":
            break
    return {
        "status": "passed"
        if all(r["status"] == "passed" for r in results)
        else "failed",
        "phases": results,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--only", nargs="+", choices=list(CASES))
    parser.add_argument("--timeout", type=float, default=60)
    args = parser.parse_args()
    if Path(sys.prefix).resolve() != (ROOT / ".venv").resolve():
        parser.error("Run with .venv/bin/python")
    if args.timeout <= 0:
        parser.error("--timeout must be positive")
    run_id = (
        datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        + "-"
        + uuid.uuid4().hex[:8]
    )
    folder = ARTIFACTS / "runs" / run_id
    folder.mkdir(parents=True)
    sources = {dep["name"]: provenance(dep) for dep in dependencies()}
    selected = args.only or list(CASES)
    report = {
        "run_id": run_id,
        "environment": {
            "platform": platform.platform(),
            "machine": platform.machine(),
            "python": sys.version,
            "executable": sys.executable,
            "disk": shutil.disk_usage(ROOT)._asdict(),
        },
        "scope": "Spike-0 only: pinned source builds, native coexistence, normal-close persistence and syntax parsing",
        "sources": sources,
        "cases": {},
    }
    for name in selected:
        report["cases"][name] = run_case(name, folder, sources, args.timeout)
        print(f"{name}: {report['cases'][name]['status']}", flush=True)
    statuses = [result["status"] for result in report["cases"].values()]
    report["status"] = (
        "failed"
        if "failed" in statuses
        else "blocked"
        if "blocked" in statuses
        else "passed"
    )
    report["complete_suite"] = set(selected) == set(CASES)
    report["unmodified_source_builds"] = all(
        source.get("source_variant") == "unmodified" for source in sources.values()
    )
    report["license_gaps"] = [
        dep["name"] for dep in dependencies() if dep["license_spdx"] is None
    ]
    report_path = folder / "report.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    (ARTIFACTS / "latest.json").write_text(
        json.dumps({"report": str(report_path.relative_to(ROOT))}) + "\n"
    )
    print(f"report: {report_path}")
    return {"passed": 0, "failed": 1, "blocked": 2}[report["status"]]


if __name__ == "__main__":
    raise SystemExit(main())
