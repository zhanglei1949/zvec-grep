"""Isolated native smoke operations; results are separate from native logs."""

from __future__ import annotations

import argparse
import importlib
import importlib.metadata
import json
import sys
import time
import traceback
from pathlib import Path


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def graph_read(path: Path) -> dict:
    import graphdb

    expected = [("source-a", "chunk-a", "knowledge graph evidence")]
    expected_numbers = [(1, 1.25, 0.5), (2, 25.0, -0.25), (3, 0.0, 3.5)]
    started = time.monotonic()
    with graphdb.connect(str(path), config={"transaction_mode": "tp"}) as connection:
        attempts = 0
        while True:
            attempts += 1
            rows = connection.execute(
                "MATCH (s:Source)-[:CONTAINS]->(c:Chunk) RETURN s.id, c.id, c.body"
            ).fetchall()
            numbers = connection.execute(
                "MATCH (n:NumericSample) RETURN n.nid,n.d_value,n.f_value ORDER BY n.nid"
            ).fetchall()
            if rows == expected and numbers == expected_numbers:
                break
            if time.monotonic() - started > 5:
                raise RuntimeError(
                    f"Graph rows did not become visible: {rows!r}; numeric={numbers!r}"
                )
            time.sleep(0.01)
    return {
        "rows": rows,
        "csv_float_rows": numbers,
        "read_attempts": attempts,
        "mode": "persistent_tp",
    }


def graph_write(path: Path) -> dict:
    import graphdb

    numeric_csv = path.parent / "numbers.csv"
    numeric_csv.write_text(
        "nid,d_value,f_value\n1,1.25,0.5\n2,+2.5e1,-0.25\n3,-0,3.5\n"
    )
    with graphdb.connect(str(path), config={"transaction_mode": "tp"}) as connection:
        connection.execute("CREATE NODE TABLE Source(id STRING PRIMARY KEY)")
        connection.execute(
            "CREATE NODE TABLE Chunk(id STRING PRIMARY KEY, body STRING)"
        )
        connection.execute("CREATE REL TABLE CONTAINS(FROM Source TO Chunk)")
        connection.execute(
            "CREATE NODE TABLE NumericSample(nid INT64 PRIMARY KEY,d_value DOUBLE,f_value FLOAT)"
        )
        with connection.transaction():
            connection.execute(
                "CREATE (s:Source {id:$source}), "
                "(c:Chunk {id:$chunk,body:$body}), (s)-[:CONTAINS]->(c)",
                {
                    "source": "source-a",
                    "chunk": "chunk-a",
                    "body": "knowledge graph evidence",
                },
            )
        connection.execute(
            "COPY NumericSample FROM $path (HEADER=true)", {"path": str(numeric_csv)}
        )
    # Normal close, followed by the public reopen/read path; no checkpoint barrier.
    return graph_read(path)


def zvec_read(path: Path) -> dict:
    import zvec
    from zvec.model.param.query import Fts, Query

    collection = zvec.open(path=str(path))
    fts = collection.query(
        queries=Query(field_name="body", fts=Fts(match_string="quasar")),
        topk=3,
    )
    vector = collection.query(
        queries=Query(field_name="embedding", vector=[1.0] + [0.0] * 15),
        topk=1,
    )
    fts_ids = [doc.id for doc in fts]
    vector_ids = [doc.id for doc in vector]
    require(fts_ids == ["chunk-a"], f"Unexpected FTS results: {fts_ids}")
    require(vector_ids == ["chunk-a"], f"Unexpected vector results: {vector_ids}")
    return {
        "fts_ids": fts_ids,
        "vector_ids": vector_ids,
        "document_count": collection.stats.doc_count,
    }


def zvec_write(path: Path) -> dict:
    import zvec
    from zvec.model.param.query import Fts, Query

    schema = zvec.CollectionSchema(
        name="spike_zero",
        fields=[
            zvec.FieldSchema(
                "body",
                zvec.DataType.STRING,
                nullable=False,
                index_param=zvec.FtsIndexParam(
                    tokenizer_name="standard", filters=["lowercase"]
                ),
            )
        ],
        vectors=[
            zvec.VectorSchema(
                "embedding",
                zvec.DataType.VECTOR_FP32,
                dimension=16,
                index_param=zvec.HnswIndexParam(),
            )
        ],
    )
    collection = zvec.create_and_open(path=str(path), schema=schema)
    statuses = collection.insert(
        [
            zvec.Doc(
                id="chunk-a",
                fields={"body": "quasar knowledge graph evidence"},
                vectors={"embedding": [1.0] + [0.0] * 15},
            ),
            zvec.Doc(
                id="chunk-b",
                fields={"body": "bread flour water"},
                vectors={"embedding": [0.0, 1.0] + [0.0] * 14},
            ),
        ]
    )
    require(len(statuses) == 2, f"Wrong number of insert statuses: {statuses}")
    require(
        all(status.ok() for status in statuses), f"Insert partial failure: {statuses}"
    )
    collection.flush()
    fts = collection.query(
        queries=Query(field_name="body", fts=Fts(match_string="quasar")), topk=3
    )
    vector = collection.query(
        queries=Query(field_name="embedding", vector=[1.0] + [0.0] * 15), topk=1
    )
    require([d.id for d in fts] == ["chunk-a"], "FTS did not find inserted document")
    require(
        [d.id for d in vector] == ["chunk-a"],
        "Vector query did not find inserted document",
    )
    # This API has no public close(): process exit releases the collection.
    return {"insert_statuses": [str(s) for s in statuses], "flush": "completed"}


def parse_language(language_name: str) -> dict:
    from tree_sitter import Language, Parser

    module = importlib.import_module("tree_sitter_" + language_name)
    language = Language(module.language())
    parser = Parser(language)
    if language_name == "python":
        source = "# 中文位置\n\ndef greet(name: str) -> str:\n    return '你好 ' + name\n".encode()
        kind = "function_definition"
        expected_name = b"greet"
        broken = b"def broken(:\n"
    else:
        source = "// 中文位置\nnamespace demo {\nint add(int a, int b) { return a + b; }\n}\n".encode()
        kind = "function_definition"
        expected_name = b"add"
        broken = b"int broken( {\n"
    tree = parser.parse(source)
    require(not tree.root_node.has_error, f"Unexpected parse error: {tree.root_node}")
    pending = [tree.root_node]
    definitions = []
    while pending:
        node = pending.pop()
        if node.type == kind:
            definitions.append(node)
        pending.extend(reversed(node.children))
    require(len(definitions) == 1, f"Expected one definition: {definitions}")
    node = definitions[0]
    if language_name == "python":
        name = node.child_by_field_name("name")
    else:
        declarator = node.child_by_field_name("declarator")
        name = declarator.child_by_field_name("declarator")
    require(name is not None, "No function name node")
    actual_name = source[name.start_byte : name.end_byte]
    require(actual_name == expected_name, f"Unexpected name span: {actual_name!r}")
    require(
        source[node.start_byte : node.end_byte].find(expected_name) >= 0,
        "Invalid definition byte span",
    )
    require(
        node.start_byte
        > source.decode().index("def " if language_name == "python" else "int "),
        "UTF-8 fixture did not exercise byte vs character offset",
    )
    require(
        parser.parse(broken).root_node.has_error,
        "Malformed fixture did not report parse errors",
    )
    return {
        "language": language_name,
        "abi_version": language.abi_version,
        "function": actual_name.decode(),
        "byte_range": [node.start_byte, node.end_byte],
        "source_slice": source[node.start_byte : node.end_byte].decode(),
        "malformed_input_detected": True,
    }


def combined(path: Path, reverse: bool) -> dict:
    modules = [
        "graphdb",
        "zvec",
        "tree_sitter",
        "tree_sitter_python",
        "tree_sitter_cpp",
    ]
    if reverse:
        modules.reverse()
    loaded = {}
    for name in modules:
        module = importlib.import_module(name)
        module_path = Path(module.__file__).resolve()
        require(
            module_path.is_relative_to(Path(sys.prefix).resolve()),
            f"Imported outside venv: {module_path}",
        )
        loaded[name] = str(module_path)
    natives = {}
    for name in ["graphdb._native", "zvec._zvec", "tree_sitter._binding"]:
        module = importlib.import_module(name)
        native_path = Path(module.__file__).resolve()
        require(
            native_path.is_relative_to(Path(sys.prefix).resolve()),
            f"Native extension imported outside venv: {native_path}",
        )
        natives[name] = str(native_path)
    return {
        "import_order": modules,
        "loaded_modules": loaded,
        "native_modules": natives,
        "graphdb": graph_write(path / "graphdb"),
        "zvec": zvec_write(path / "zvec"),
        "python": parse_language("python"),
        "cpp": parse_language("cpp"),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--case",
        required=True,
        choices=[
            "graph_write",
            "graph_read",
            "zvec_write",
            "zvec_read",
            "python",
            "cpp",
            "combined",
            "combined_reverse",
        ],
    )
    parser.add_argument("--path", type=Path, required=True)
    parser.add_argument("--result", type=Path, required=True)
    args = parser.parse_args()
    args.path.parent.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    try:
        if args.case in ("combined", "combined_reverse"):
            args.path.mkdir(exist_ok=True)
            details = combined(args.path, args.case == "combined_reverse")
        elif args.case in ("python", "cpp"):
            details = parse_language(args.case)
        else:
            details = globals()[args.case](args.path)
        result = {"status": "passed", "details": details}
    except Exception as error:
        traceback.print_exc()
        result = {"status": "failed", "error": f"{type(error).__name__}: {error}"}
    result["duration_seconds"] = round(time.monotonic() - started, 4)
    args.result.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
