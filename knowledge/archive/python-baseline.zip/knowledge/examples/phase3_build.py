"""Capture -> precomputed vectors -> publish -> fail/retry -> readonly reopen.

All vectors in this example are explicit synthetic fixtures, not model output.
Run: python -m examples.phase3_build [--root NEW_DIRECTORY]
"""

from __future__ import annotations

import argparse
import json
import tempfile
from pathlib import Path

from zknowledge import (
    BuildConfig,
    DocumentInput,
    EmbeddedVector,
    JobStatus,
    KnowledgeBase,
    PrecomputedEmbeddings,
    SourceSpec,
    SyntheticEmbeddingProvider,
    prepare_document,
)
from zknowledge.document_processing import ParseContext, ProcessingBudget
from zknowledge.errors import ProviderError


def completed(handle):
    value = handle.wait(30)
    if value.status != JobStatus.COMPLETED:
        raise RuntimeError(value.error)
    return value.result


class AvailableTestProvider:
    """An explicit transport-failure fixture for the synthetic algorithm."""

    def __init__(self):
        self.available = False
        self.delegate = SyntheticEmbeddingProvider(8)

    def describe(self):
        return self.delegate.describe()

    def embed(self, items, context):
        if not self.available:
            raise ProviderError("example provider is deliberately unavailable")
        return self.delegate.embed(items, context)


def run(root):
    with KnowledgeBase.create(root) as kb:
        source = kb.sources.register(SourceSpec("phase3-example", "example://manual"))
        first = completed(
            kb.ingest_documents(
                source.id,
                DocumentInput.from_bytes(
                    "\ufeff# 示例\r\n\r\nquasar 第一版正文\r\n\r\n## 使用\r\n保留原始证据。\r\n".encode()
                ),
            )
        )
        snapshot = kb.sources.snapshot(first.revision_id)
        units = prepare_document(
            snapshot, context=ParseContext(ProcessingBudget(1 << 20, 1000))
        )
        space = SyntheticEmbeddingProvider(8).describe().space
        supplied = PrecomputedEmbeddings(
            space,
            tuple(
                EmbeddedVector(
                    unit.id, unit.input_digest, (1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
                )
                for unit in units
            ),
        )
        config = BuildConfig(embedding=supplied, vector="required")
        published = completed(
            kb.build_documents(
                first.revision_id, config=config, operation_id="build-v1"
            )
        )
        repeated = completed(
            kb.build_documents(
                first.revision_id, config=config, operation_id="build-v1-repeat"
            )
        )
        assert repeated.outcome == "unchanged"
        assert not kb.ingestions.get(first.operation_id).result.search_ready
        second = completed(
            kb.ingest_documents(
                source.id,
                DocumentInput.from_bytes(
                    "# 示例\n\nquasar 第二版正文\n\n## 使用\n更新后重新发布。\n".encode()
                ),
            )
        )
        provider = AvailableTestProvider()
        config = BuildConfig(embedding=provider, vector="required")
        failed = kb.build_documents(
            second.revision_id, config=config, operation_id="build-v2"
        ).wait(30)
        assert failed.status == JobStatus.FAILED
        assert (
            kb.publications.current(source.id).publication_id
            == published.publication_id
        )
        provider.available = True
        latest = completed(
            kb.build_documents(
                second.revision_id, config=config, operation_id="build-v2"
            )
        )
        assert latest.revision_id == second.revision_id
        assert kb.builds.get("build-v2").phase == "confirmed"
    with KnowledgeBase.open(root, read_only=True) as kb:
        current = kb.publications.current(source.id)
        assert current.publication_id == latest.publication_id
        assert kb.builds.get("build-v1").result == published
        print(
            json.dumps(
                {
                    "root": str(root),
                    "capture_search_ready": False,
                    "v1_publication": published.publication_id,
                    "repeat_outcome": repeated.outcome,
                    "failed_v2_kept_v1": True,
                    "v2_publication": current.publication_id,
                    "text_ready": current.text_ready,
                    "vector_ready": current.vector_ready,
                    "unit_count": latest.unit_count,
                    "search_api_available": kb.capabilities()["search_api_available"],
                    "vectors": "synthetic fixtures; no semantic quality claim",
                },
                ensure_ascii=False,
                indent=2,
            )
        )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path)
    args = parser.parse_args()
    if args.root:
        run(args.root)
    else:
        with tempfile.TemporaryDirectory(prefix="zkg-phase3-example-") as temporary:
            run(Path(temporary) / "kb")


if __name__ == "__main__":
    main()
