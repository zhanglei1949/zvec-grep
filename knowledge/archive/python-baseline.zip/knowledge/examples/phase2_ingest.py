"""Run with: .venv/bin/python -m examples.phase2_ingest [--root NEW_DIRECTORY]."""

from __future__ import annotations

import argparse
import json
import tempfile
from dataclasses import asdict
from pathlib import Path

from zknowledge import DocumentInput, JobStatus, KnowledgeBase, SourceSpec


def demonstrate(root: Path) -> dict:
    v1 = "# Atlas\r\nAtlas 2.0 支持全文检索。\r\n".encode("utf-8")
    v2 = "# Atlas\r\nAtlas 2.1 支持全文与向量检索。\r\n".encode("utf-8")
    with KnowledgeBase.create(root) as kb:
        source = kb.sources.register(SourceSpec("atlas-manual", "atlas.md"))
        results = []
        for operation_id, data in (
            ("capture-v1", v1),
            ("repeat-v1", v1),
            ("capture-v2", v2),
        ):
            job = kb.ingest_documents(
                source.id, DocumentInput.from_bytes(data), operation_id=operation_id
            )
            snapshot = job.wait(10)
            if snapshot.status != JobStatus.COMPLETED:
                raise RuntimeError(snapshot.error or snapshot.status.value)
            results.append(snapshot.result)
        first_unit = results[0].content_unit_id
        second_unit = results[-1].content_unit_id
    with KnowledgeBase.open(root, read_only=True) as kb:
        assert kb.sources.read_content_unit(first_unit) == v1
        assert kb.sources.read_content_unit(second_unit) == v2
        assert len(kb.sources.revisions(source.id).items) == 2
        assert kb.ingestions.get("capture-v1").result == results[0]
        return {
            "source_id": source.id,
            "results": [asdict(r) for r in results],
            "readonly_reopen_verified": True,
            "old_snapshot_preserved": True,
            "parser_connected": False,
            "knowledge_extraction_connected": False,
            "search_ready": False,
        }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root", type=Path, help="new/empty KB directory; never overwritten"
    )
    args = parser.parse_args()
    if args.root is not None:
        result = demonstrate(args.root)
    else:
        with tempfile.TemporaryDirectory(prefix="zkg-phase2-example-") as directory:
            result = demonstrate(Path(directory) / "kb")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
